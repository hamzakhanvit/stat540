# seminar02c
hamzakhanvit  
Thursday, January 22, 2015  


####1) Generate some data from a different normal distribution


```r
rnorm(n = 20, mean = 45, sd = 2)
```

```
##  [1] 45.35888 39.33615 44.22919 42.85774 39.04356 47.23455 43.73511
##  [8] 45.67653 46.41383 48.19182 45.77918 46.68063 44.49897 41.97552
## [15] 43.15276 46.07710 42.99115 44.62295 44.15893 47.21903
```

```r
rnorm(20,45,2)
```

```
##  [1] 41.69083 44.65447 47.81724 43.47993 45.04137 46.42001 43.28121
##  [8] 43.21214 48.24563 42.01877 44.12469 46.59745 47.13531 46.90173
## [15] 47.45776 46.92732 45.78346 44.47963 45.12772 44.61474
```

The outcomes of resolve by position and name = value are same.

####2) Recall the claim that the expected value of the sample mean is the true mean. Compute the average of the 4 sample means we have. Is it (sort of) close the true mean? Feel free to change n or B at any point.

Defining the matrix

```r
n <- 10
B <- 5

x <- matrix(rnorm(n * B), nrow = n)
rownames(x) <- sprintf("obs%02d", 1:n)
colnames(x) <- sprintf("samp%02d", 1:B)
x
```

```
##            samp01      samp02     samp03      samp04     samp05
## obs01 -0.78299800  0.02779384  1.1798521  1.47237421  0.7315151
## obs02  0.13496945 -0.09828544  0.8459553 -0.30552460  0.6747012
## obs03  1.07011010 -0.89064399  2.8613536 -1.59855320  0.9878872
## obs04 -0.08000554 -0.12629534 -0.9352594  0.79411103  0.1870551
## obs05 -0.85065675 -0.32009094 -0.4112016  0.12365052 -1.4178247
## obs06 -0.17948129 -0.83671319  0.3794525 -0.09332861  1.0008256
## obs07  0.35539167 -0.47265710 -0.7420562 -0.53335161  0.5426804
## obs08 -0.58562387 -0.04850411  0.2311475  1.94794612  0.7620525
## obs09  1.96054285 -1.12928212  0.4134701 -1.55678401  2.3572658
## obs10  0.27246945 -0.17734516 -0.1697940  0.97922895  0.6513897
```

The sample mean is 

```r
mean(apply(x, 2, mean))
```

```
## [1] 0.1720586
```

The sample mean average is quite close to the true mean 0.

####3) Exploring weak law of large numbers

```r
n <- 10^(1:4)
names(n) <- paste0("n", n)
SampleMeans <- function(n, B) {
  colMeans(matrix(rnorm(n * B), nrow = n))
	}
x <- sapply(n, SampleMeans, B, simplify = FALSE)
cbind(sampSize = n,
      trueSEM = 1 / sqrt(n),
      obsSEM = sapply(x, sd),
      sampMeanIQR = sapply(x, IQR),
      sampMeanMad = sapply(x, mad))
```

```
##        sampSize    trueSEM      obsSEM sampMeanIQR sampMeanMad
## n10          10 0.31622777 0.477976970 0.860403335 0.095368293
## n100        100 0.10000000 0.156379821 0.044940300 0.065243817
## n1000      1000 0.03162278 0.038658022 0.050806774 0.037438600
## n10000    10000 0.01000000 0.005431522 0.009419783 0.005487867
```

####4) Repeating for a different distribution


```r
n <- 10^(1:4)
names(n) <- paste0("n", n)
SampleMeans <- function(n, B) {
	colMeans(matrix(runif(n * B), nrow = n))
	}
x <- sapply(n, SampleMeans, B, simplify = FALSE)
cbind(sampSize = n,
      trueSEM = 1 / sqrt(n),
      obsSEM = sapply(x, sd),
      sampMeanIQR = sapply(x, IQR),
      sampMeanMad = sapply(x, mad))
```

```
##        sampSize    trueSEM      obsSEM sampMeanIQR sampMeanMad
## n10          10 0.31622777 0.134332440 0.198688764 0.154382599
## n100        100 0.10000000 0.018830218 0.012703898 0.016107932
## n1000      1000 0.03162278 0.002762440 0.004121738 0.003339422
## n10000    10000 0.01000000 0.001964411 0.001102612 0.001208598
```


####5) Generate a reasonably large sample from some normal distribution (it need not be standard normal!). Pick a threshhold. What is the CDF at that threshhold, i.e. what's the true probability of seeing an observation less than or equal to the threshhold? Use your large sample to compute the observed proportion of observations that are less than threshhold. Are the two numbers sort of close? Hint: If x is a numeric vector, then mean(x <= threshhold) computes the proportion of values less than or equal to threshhold.


```r
threshold <- 33
Norm <- rnorm(100000, 35 , 3)
pnorm(threshold, mean = 35, sd =3)
```

```
## [1] 0.2524925
```

```r
mean(Norm <= threshold)
```

```
## [1] 0.25353
```

The true probability of an observation which is less than or equal to the threshold is near to the observed probability.

####6) Do the same for a different distribution.


```r
threshold <- 25
Unif <- runif(100000, 3, 35)
punif(threshold, min = 3, max =35)
```

```
## [1] 0.6875
```

```r
mean(Unif <= threshold)
```

```
## [1] 0.68576
```

####7) Do the same for a variety of sample sizes. Do the two numbers tend to be closer for larger samples?


```r
threshold <- 33
Norm <- rnorm(1000, 35 , 3)
pnorm(threshold, mean = 35, sd =3)
```

```
## [1] 0.2524925
```

```r
mean(Norm <= threshold)
```

```
## [1] 0.278
```
Yes. 

####8) Instead of focusing on values less than the threshhold, focus on values greater than the threshhold.


```r
threshold <- 33
Norm <- rnorm(100000, 35 , 3)
pnorm(threshold, mean = 35, sd =3)
```

```
## [1] 0.2524925
```

```r
mean(Norm >= threshold)
```

```
## [1] 0.74744
```

####9)Instead of focusing on tail probabilities, focus on the probability of the observed values falling in an interval.


```r
threshold <- 33
Norm <- rnorm(100000, 35 , 3)
pnorm(threshold, mean = 35, sd =3)
```

```
## [1] 0.2524925
```

```r
mean(!Norm <= threshold)
```

```
## [1] 0.7487
```
