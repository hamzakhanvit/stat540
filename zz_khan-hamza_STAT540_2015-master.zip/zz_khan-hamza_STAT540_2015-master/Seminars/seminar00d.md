# seminar00d
hamzakhanvit  
Thursday, January 22, 2015  



```r
x <- 3*4
x
```

```
## [1] 12
```

```r
is.vector(x)
```

```
## [1] TRUE
```

```r
length(x)
```

```
## [1] 1
```

```r
x[2] <- 100
x
```

```
## [1]  12 100
```

```r
x[5] <- 3
x
```

```
## [1]  12 100  NA  NA   3
```

```r
x[11]
```

```
## [1] NA
```

```r
x[0]
```

```
## numeric(0)
```

```r
x <- 1:4
(y <- x^2) 
```

```
## [1]  1  4  9 16
```

```r
#The for loop version
z <- vector(mode = mode(x), length = length(x))
for(i in seq_along(x)) {
  z[i] <- x[i]^2
}

#Exploring mean and standard deviation of random normal variates as vectors.
identical(y, z)
```

```
## [1] TRUE
```

```r
set.seed(1999)
rnorm(5, mean = 10^(1:5))
```

```
## [1]     10.73267     99.96217   1001.20301  10001.46980 100000.13369
```

```r
round(rnorm(5, sd = 10^(0:4)), 2)
```

```
## [1]     0.52    -5.49  -118.56 -1147.28 11607.42
```

```r
#Operations with vectors of different sizes and equal sizes
(y <- 1:3)
```

```
## [1] 1 2 3
```

```r
(z <- 3:7)
```

```
## [1] 3 4 5 6 7
```

```r
y + z
```

```
## Warning in y + z: longer object length is not a multiple of shorter object
## length
```

```
## [1] 4 6 8 7 9
```

```r
(y <- 1:10)
```

```
##  [1]  1  2  3  4  5  6  7  8  9 10
```

```r
(z <- 3:7)
```

```
## [1] 3 4 5 6 7
```

```r
y + z
```

```
##  [1]  4  6  8 10 12  9 11 13 15 17
```

```r
#The catenate function for making vectors.
str(c("hello", "world"))
```

```
##  chr [1:2] "hello" "world"
```

```r
str(c(1:3, 100, 150))
```

```
##  num [1:5] 1 2 3 100 150
```

```r
#Elements of different types coerced into one
(x <- c("cabbage", pi, TRUE, 4.3))
```

```
## [1] "cabbage"          "3.14159265358979" "TRUE"            
## [4] "4.3"
```

```r
str(x)
```

```
##  chr [1:4] "cabbage" "3.14159265358979" "TRUE" "4.3"
```

```r
length(x)
```

```
## [1] 4
```

```r
mode(x)
```

```
## [1] "character"
```

```r
class(x)
```

```
## [1] "character"
```

```r
#Some simple vectors fore demo
n <- 8
set.seed(1)
(w <- round(rnorm(n), 2)) # numeric floating point
```

```
## [1] -0.63  0.18 -0.84  1.60  0.33 -0.82  0.49  0.74
```

```r
(x <- 1:n) # numeric integer
```

```
## [1] 1 2 3 4 5 6 7 8
```

```r
(y <- LETTERS[1:n]) # character
```

```
## [1] "A" "B" "C" "D" "E" "F" "G" "H"
```

```r
(z <- runif(n) > 0.3) # logical
```

```
## [1]  TRUE  TRUE  TRUE  TRUE  TRUE FALSE  TRUE FALSE
```

```r
#Using str() and any other functions to inspect these objects.
str(w)
```

```
##  num [1:8] -0.63 0.18 -0.84 1.6 0.33 -0.82 0.49 0.74
```

```r
length(x)
```

```
## [1] 8
```

```r
is.logical(y)
```

```
## [1] FALSE
```

```r
as.numeric(z)
```

```
## [1] 1 1 1 1 1 0 1 0
```

```r
#Indexing Vectors
w
```

```
## [1] -0.63  0.18 -0.84  1.60  0.33 -0.82  0.49  0.74
```

```r
names(w) <- letters[seq_along(w)]
w
```

```
##     a     b     c     d     e     f     g     h 
## -0.63  0.18 -0.84  1.60  0.33 -0.82  0.49  0.74
```

```r
w < 0
```

```
##     a     b     c     d     e     f     g     h 
##  TRUE FALSE  TRUE FALSE FALSE  TRUE FALSE FALSE
```

```r
which(w < 0)
```

```
## a c f 
## 1 3 6
```

```r
w[w < 0]
```

```
##     a     c     f 
## -0.63 -0.84 -0.82
```

```r
seq(from = 1, to = length(w), by = 2)
```

```
## [1] 1 3 5 7
```

```r
w[seq(from = 1, to = length(w), by = 2)]
```

```
##     a     c     e     g 
## -0.63 -0.84  0.33  0.49
```

```r
w[-c(2, 5)]
```

```
##     a     c     d     f     g     h 
## -0.63 -0.84  1.60 -0.82  0.49  0.74
```

```r
w[c('c', 'a', 'f')]
```

```
##     c     a     f 
## -0.84 -0.63 -0.82
```

```r
#Learning about lists
(a <- list("cabbage", pi, TRUE, 4.3))
```

```
## [[1]]
## [1] "cabbage"
## 
## [[2]]
## [1] 3.141593
## 
## [[3]]
## [1] TRUE
## 
## [[4]]
## [1] 4.3
```

```r
str(a)
```

```
## List of 4
##  $ : chr "cabbage"
##  $ : num 3.14
##  $ : logi TRUE
##  $ : num 4.3
```

```r
length(a)
```

```
## [1] 4
```

```r
mode(a)
```

```
## [1] "list"
```

```r
class(a)
```

```
## [1] "list"
```

```r
#Creating names for list components
names(a)
```

```
## NULL
```

```r
names(a) <- c("veg", "dessert", "myAim", "number")
a
```

```
## $veg
## [1] "cabbage"
## 
## $dessert
## [1] 3.141593
## 
## $myAim
## [1] TRUE
## 
## $number
## [1] 4.3
```

```r
a <- list(veg = "cabbage", dessert = pi, myAim = TRUE, number = 4.3)
names(a)
```

```
## [1] "veg"     "dessert" "myAim"   "number"
```

```r
(a <- list(veg = c("cabbage", "eggplant"),
           tNum = c(pi, exp(1), sqrt(2)),
           myAim = TRUE,
           joeNum = 2:6))
```

```
## $veg
## [1] "cabbage"  "eggplant"
## 
## $tNum
## [1] 3.141593 2.718282 1.414214
## 
## $myAim
## [1] TRUE
## 
## $joeNum
## [1] 2 3 4 5 6
```

```r
str(a)
```

```
## List of 4
##  $ veg   : chr [1:2] "cabbage" "eggplant"
##  $ tNum  : num [1:3] 3.14 2.72 1.41
##  $ myAim : logi TRUE
##  $ joeNum: int [1:5] 2 3 4 5 6
```

```r
length(a)
```

```
## [1] 4
```

```r
class(a)
```

```
## [1] "list"
```

```r
mode(a)
```

```
## [1] "list"
```

```r
#Ways to get a single list element
a[[2]] # a positive integer index
```

```
## [1] 3.141593 2.718282 1.414214
```

```r
a$myAim # use dollar sign and element name
```

```
## [1] TRUE
```

```r
str(a$myAim) # we get myAim itself, a length 1 logical vector
```

```
##  logi TRUE
```

```r
a[["tNum"]] # index with length 1 character vector 
```

```
## [1] 3.141593 2.718282 1.414214
```

```r
str(a[["tNum"]]) # we get tNum itself, a length 3 numeric vector
```

```
##  num [1:3] 3.14 2.72 1.41
```

```r
iWantThis <- "joeNum" 
a[[iWantThis]] 
```

```
## [1] 2 3 4 5 6
```

```r
# a[[c("joeNum", "veg")]] returns an error

#A case when one must use the double bracket approach, as opposed to the dollar sign, is when the indexing object itself is an R object; we show that above.
#For more than one element, one must index vector-style with single square brackets. Note that the return value will always be a list, unlike the return value from double square brackets, even if you only request 1 element.

names(a)
```

```
## [1] "veg"    "tNum"   "myAim"  "joeNum"
```

```r
a[c("tNum", "veg")] #indexing by length 2 character vector
```

```
## $tNum
## [1] 3.141593 2.718282 1.414214
## 
## $veg
## [1] "cabbage"  "eggplant"
```

```r
str(a[c("tNum", "veg")]) # returns list of length 2
```

```
## List of 2
##  $ tNum: num [1:3] 3.14 2.72 1.41
##  $ veg : chr [1:2] "cabbage" "eggplant"
```

```r
a["veg"] # indexing by length 1 character vector
```

```
## $veg
## [1] "cabbage"  "eggplant"
```

```r
str(a["veg"])# returns list of length 1
```

```
## List of 1
##  $ veg: chr [1:2] "cabbage" "eggplant"
```

```r
length(a["veg"])
```

```
## [1] 1
```

```r
length(a["veg"][[1]]) # contrast with length of the veg vector itself
```

```
## [1] 2
```

```r
#Learning how to create a data.frame 
n <- 8
set.seed(1)
(jDat <- data.frame(w = round(rnorm(n), 2),
                    x = 1:n,
                    y = I(LETTERS[1:n]),
                    z = runif(n) > 0.3,
                    v = rep(LETTERS[9:12], each = 2)))
```

```
##       w x y     z v
## 1 -0.63 1 A  TRUE I
## 2  0.18 2 B  TRUE I
## 3 -0.84 3 C  TRUE J
## 4  1.60 4 D  TRUE J
## 5  0.33 5 E  TRUE K
## 6 -0.82 6 F FALSE K
## 7  0.49 7 G  TRUE L
## 8  0.74 8 H FALSE L
```

```r
str(jDat)
```

```
## 'data.frame':	8 obs. of  5 variables:
##  $ w: num  -0.63 0.18 -0.84 1.6 0.33 -0.82 0.49 0.74
##  $ x: int  1 2 3 4 5 6 7 8
##  $ y:Class 'AsIs'  chr [1:8] "A" "B" "C" "D" ...
##  $ z: logi  TRUE TRUE TRUE TRUE TRUE FALSE ...
##  $ v: Factor w/ 4 levels "I","J","K","L": 1 1 2 2 3 3 4 4
```

```r
mode(jDat)
```

```
## [1] "list"
```

```r
class(jDat)
```

```
## [1] "data.frame"
```

```r
#Exploring data.frames as lists
is.list(jDat)
```

```
## [1] TRUE
```

```r
jDat[[5]]
```

```
## [1] I I J J K K L L
## Levels: I J K L
```

```r
jDat$v #Using variable names
```

```
## [1] I I J J K K L L
## Levels: I J K L
```

```r
jDat[c("x", "z")] # multiple variables
```

```
##   x     z
## 1 1  TRUE
## 2 2  TRUE
## 3 3  TRUE
## 4 4  TRUE
## 5 5  TRUE
## 6 6 FALSE
## 7 7  TRUE
## 8 8 FALSE
```

```r
str(jDat[c("x", "z")]) # returns a data.frame
```

```
## 'data.frame':	8 obs. of  2 variables:
##  $ x: int  1 2 3 4 5 6 7 8
##  $ z: logi  TRUE TRUE TRUE TRUE TRUE FALSE ...
```

```r
identical(subset(jDat, select = c(x, z)), jDat[c("x", "z")])
```

```
## [1] TRUE
```

```r
##Evaluating the difference in the printing of a list vs. a data.frame
(qDat <- list(w = round(rnorm(n), 2),
              x = 1:(n-1), ## <-- LOOK HERE! I MADE THIS VECTOR SHORTER!
              y = I(LETTERS[1:n])))
```

```
## $w
## [1] -0.62 -2.21  1.12 -0.04 -0.02  0.94  0.82  0.59
## 
## $x
## [1] 1 2 3 4 5 6 7
## 
## $y
## [1] "A" "B" "C" "D" "E" "F" "G" "H"
```

```r
#Won't be able to form a data.frame from this list 
qDat$x <- 1:n ## fixing the short variable x
(qDat <- as.data.frame(qDat)) ## Now its possible to make a data frame from the list
```

```
##       w x y
## 1 -0.62 1 A
## 2 -2.21 2 B
## 3  1.12 3 C
## 4 -0.04 4 D
## 5 -0.02 5 E
## 6  0.94 6 F
## 7  0.82 7 G
## 8  0.59 8 H
```

```r
#Learning Indexing arrays or matrices
jMat <- outer(as.character(1:4), as.character(1:4),
              function(x, y) {
                paste0('x', x, y)
                })
jMat
```

```
##      [,1]  [,2]  [,3]  [,4] 
## [1,] "x11" "x12" "x13" "x14"
## [2,] "x21" "x22" "x23" "x24"
## [3,] "x31" "x32" "x33" "x34"
## [4,] "x41" "x42" "x43" "x44"
```

```r
str(jMat)
```

```
##  chr [1:4, 1:4] "x11" "x21" "x31" "x41" "x12" "x22" ...
```

```r
class(jMat)
```

```
## [1] "matrix"
```

```r
mode(jMat)
```

```
## [1] "character"
```

```r
dim(jMat)
```

```
## [1] 4 4
```

```r
nrow(jMat)
```

```
## [1] 4
```

```r
ncol(jMat)
```

```
## [1] 4
```

```r
rownames(jMat)
```

```
## NULL
```

```r
rownames(jMat) <- paste0("row", seq_len(nrow(jMat)))
colnames(jMat) <- paste0("col", seq_len(ncol(jMat)))
dimnames(jMat) # also useful for assignment
```

```
## [[1]]
## [1] "row1" "row2" "row3" "row4"
## 
## [[2]]
## [1] "col1" "col2" "col3" "col4"
```

```r
jMat
```

```
##      col1  col2  col3  col4 
## row1 "x11" "x12" "x13" "x14"
## row2 "x21" "x22" "x23" "x24"
## row3 "x31" "x32" "x33" "x34"
## row4 "x41" "x42" "x43" "x44"
```

```r
jMat[2, 3]
```

```
## [1] "x23"
```

```r
jMat[2, ] # getting row 2
```

```
##  col1  col2  col3  col4 
## "x21" "x22" "x23" "x24"
```

```r
is.vector(jMat[2, ]) # we get row 2 as an atomic vector
```

```
## [1] TRUE
```

```r
jMat[ , 3, drop = FALSE] # getting column 3
```

```
##      col3 
## row1 "x13"
## row2 "x23"
## row3 "x33"
## row4 "x43"
```

```r
dim(jMat[ , 3, drop = FALSE]) # we get column 3 as a 4 x 1 matrix
```

```
## [1] 4 1
```

```r
jMat[c("row1", "row4"), c("col2", "col3")]
```

```
##      col2  col3 
## row1 "x12" "x13"
## row4 "x42" "x43"
```

```r
jMat[-c(2, 3), c(TRUE, TRUE, FALSE, FALSE)] 
```

```
##      col1  col2 
## row1 "x11" "x12"
## row4 "x41" "x42"
```

```r
jMat[7]
```

```
## [1] "x32"
```

```r
jMat
```

```
##      col1  col2  col3  col4 
## row1 "x11" "x12" "x13" "x14"
## row2 "x21" "x22" "x23" "x24"
## row3 "x31" "x32" "x33" "x34"
## row4 "x41" "x42" "x43" "x44"
```

```r
jMat[1, grepl("[24]", colnames(jMat))]
```

```
##  col2  col4 
## "x12" "x14"
```

```r
jMat["row1", 2:3] <- c("HEY!", "THIS IS NUTS!")
jMat
```

```
##      col1  col2   col3            col4 
## row1 "x11" "HEY!" "THIS IS NUTS!" "x14"
## row2 "x21" "x22"  "x23"           "x24"
## row3 "x31" "x32"  "x33"           "x34"
## row4 "x41" "x42"  "x43"           "x44"
```

```r
#Creating Matrices
#First Method:Filling a matrix with a vector

matrix(1:15, nrow = 5)
```

```
##      [,1] [,2] [,3]
## [1,]    1    6   11
## [2,]    2    7   12
## [3,]    3    8   13
## [4,]    4    9   14
## [5,]    5   10   15
```

```r
matrix("yo!", nrow = 3, ncol = 6)
```

```
##      [,1]  [,2]  [,3]  [,4]  [,5]  [,6] 
## [1,] "yo!" "yo!" "yo!" "yo!" "yo!" "yo!"
## [2,] "yo!" "yo!" "yo!" "yo!" "yo!" "yo!"
## [3,] "yo!" "yo!" "yo!" "yo!" "yo!" "yo!"
```

```r
matrix(c("yo!", "foo?"), nrow = 3, ncol = 6)
```

```
##      [,1]   [,2]   [,3]   [,4]   [,5]   [,6]  
## [1,] "yo!"  "foo?" "yo!"  "foo?" "yo!"  "foo?"
## [2,] "foo?" "yo!"  "foo?" "yo!"  "foo?" "yo!" 
## [3,] "yo!"  "foo?" "yo!"  "foo?" "yo!"  "foo?"
```

```r
matrix(1:15, nrow = 5, byrow = TRUE)
```

```
##      [,1] [,2] [,3]
## [1,]    1    2    3
## [2,]    4    5    6
## [3,]    7    8    9
## [4,]   10   11   12
## [5,]   13   14   15
```

```r
matrix(1:15, nrow = 5,
       dimnames = list(paste0("row", 1:5),
                       paste0("col", 1:3)))
```

```
##      col1 col2 col3
## row1    1    6   11
## row2    2    7   12
## row3    3    8   13
## row4    4    9   14
## row5    5   10   15
```

```r
#Creating a matrix by glueing vectors together
vec1 <- 5:1
vec2 <- 2^(1:5)
cbind(vec1, vec2)
```

```
##      vec1 vec2
## [1,]    5    2
## [2,]    4    4
## [3,]    3    8
## [4,]    2   16
## [5,]    1   32
```

```r
rbind(vec1, vec2)
```

```
##      [,1] [,2] [,3] [,4] [,5]
## vec1    5    4    3    2    1
## vec2    2    4    8   16   32
```

```r
#Creating a matrix from a data.frame.
vecDat <- data.frame(vec1 = 5:1,
                     vec2 = 2^(1:5))
str(vecDat)
```

```
## 'data.frame':	5 obs. of  2 variables:
##  $ vec1: int  5 4 3 2 1
##  $ vec2: num  2 4 8 16 32
```

```r
vecMat <- as.matrix(vecDat)
str(vecMat)
```

```
##  num [1:5, 1:2] 5 4 3 2 1 2 4 8 16 32
##  - attr(*, "dimnames")=List of 2
##   ..$ : NULL
##   ..$ : chr [1:2] "vec1" "vec2"
```

```r
multiDat <- data.frame(vec1 = 5:1,
                       vec2 = paste0("hi", 1:5))
str(multiDat)
```

```
## 'data.frame':	5 obs. of  2 variables:
##  $ vec1: int  5 4 3 2 1
##  $ vec2: Factor w/ 5 levels "hi1","hi2","hi3",..: 1 2 3 4 5
```

```r
(multiMat <- as.matrix(multiDat))
```

```
##      vec1 vec2 
## [1,] "5"  "hi1"
## [2,] "4"  "hi2"
## [3,] "3"  "hi3"
## [4,] "2"  "hi4"
## [5,] "1"  "hi5"
```

```r
str(multiMat)
```

```
##  chr [1:5, 1:2] "5" "4" "3" "2" "1" "hi1" "hi2" "hi3" ...
##  - attr(*, "dimnames")=List of 2
##   ..$ : NULL
##   ..$ : chr [1:2] "vec1" "vec2"
```

```r
#First Method:Filling a matrix with a vector

matrix(1:15, nrow = 5)
```

```
##      [,1] [,2] [,3]
## [1,]    1    6   11
## [2,]    2    7   12
## [3,]    3    8   13
## [4,]    4    9   14
## [5,]    5   10   15
```

```r
matrix("yo!", nrow = 3, ncol = 6)
```

```
##      [,1]  [,2]  [,3]  [,4]  [,5]  [,6] 
## [1,] "yo!" "yo!" "yo!" "yo!" "yo!" "yo!"
## [2,] "yo!" "yo!" "yo!" "yo!" "yo!" "yo!"
## [3,] "yo!" "yo!" "yo!" "yo!" "yo!" "yo!"
```

```r
matrix(c("yo!", "foo?"), nrow = 3, ncol = 6)
```

```
##      [,1]   [,2]   [,3]   [,4]   [,5]   [,6]  
## [1,] "yo!"  "foo?" "yo!"  "foo?" "yo!"  "foo?"
## [2,] "foo?" "yo!"  "foo?" "yo!"  "foo?" "yo!" 
## [3,] "yo!"  "foo?" "yo!"  "foo?" "yo!"  "foo?"
```

```r
matrix(1:15, nrow = 5, byrow = TRUE)
```

```
##      [,1] [,2] [,3]
## [1,]    1    2    3
## [2,]    4    5    6
## [3,]    7    8    9
## [4,]   10   11   12
## [5,]   13   14   15
```

```r
matrix(1:15, nrow = 5,
       dimnames = list(paste0("row", 1:5),
                       paste0("col", 1:3)))
```

```
##      col1 col2 col3
## row1    1    6   11
## row2    2    7   12
## row3    3    8   13
## row4    4    9   14
## row5    5   10   15
```

```r
#Creating a matrix by glueing vectors together
vec1 <- 5:1
vec2 <- 2^(1:5)
cbind(vec1, vec2)
```

```
##      vec1 vec2
## [1,]    5    2
## [2,]    4    4
## [3,]    3    8
## [4,]    2   16
## [5,]    1   32
```

```r
rbind(vec1, vec2)
```

```
##      [,1] [,2] [,3] [,4] [,5]
## vec1    5    4    3    2    1
## vec2    2    4    8   16   32
```

```r
#Creating a matrix from a data.frame.
vecDat <- data.frame(vec1 = 5:1,
                     vec2 = 2^(1:5))
str(vecDat)
```

```
## 'data.frame':	5 obs. of  2 variables:
##  $ vec1: int  5 4 3 2 1
##  $ vec2: num  2 4 8 16 32
```

```r
vecMat <- as.matrix(vecDat)
str(vecMat)
```

```
##  num [1:5, 1:2] 5 4 3 2 1 2 4 8 16 32
##  - attr(*, "dimnames")=List of 2
##   ..$ : NULL
##   ..$ : chr [1:2] "vec1" "vec2"
```

```r
multiDat <- data.frame(vec1 = 5:1,
                       vec2 = paste0("hi", 1:5))
str(multiDat)
```

```
## 'data.frame':	5 obs. of  2 variables:
##  $ vec1: int  5 4 3 2 1
##  $ vec2: Factor w/ 5 levels "hi1","hi2","hi3",..: 1 2 3 4 5
```

```r
(multiMat <- as.matrix(multiDat))
```

```
##      vec1 vec2 
## [1,] "5"  "hi1"
## [2,] "4"  "hi2"
## [3,] "3"  "hi3"
## [4,] "2"  "hi4"
## [5,] "1"  "hi5"
```

```r
str(multiMat)
```

```
##  chr [1:5, 1:2] "5" "4" "3" "2" "1" "hi1" "hi2" "hi3" ...
##  - attr(*, "dimnames")=List of 2
##   ..$ : NULL
##   ..$ : chr [1:2] "vec1" "vec2"
```

```r
#Reviewing list-style indexing of a data.frame:

jDat
```

```
##       w x y     z v
## 1 -0.63 1 A  TRUE I
## 2  0.18 2 B  TRUE I
## 3 -0.84 3 C  TRUE J
## 4  1.60 4 D  TRUE J
## 5  0.33 5 E  TRUE K
## 6 -0.82 6 F FALSE K
## 7  0.49 7 G  TRUE L
## 8  0.74 8 H FALSE L
```

```r
jDat$z
```

```
## [1]  TRUE  TRUE  TRUE  TRUE  TRUE FALSE  TRUE FALSE
```

```r
iWantThis <- "z"
jDat[[iWantThis]]
```

```
## [1]  TRUE  TRUE  TRUE  TRUE  TRUE FALSE  TRUE FALSE
```

```r
str(jDat[[iWantThis]]) # we get an atomic vector
```

```
##  logi [1:8] TRUE TRUE TRUE TRUE TRUE FALSE ...
```

```r
#Reviewing vector-style indexing of a data.frame:

jDat["y"]
```

```
##   y
## 1 A
## 2 B
## 3 C
## 4 D
## 5 E
## 6 F
## 7 G
## 8 H
```

```r
str(jDat["y"]) # we get a data.frame with one variable, y
```

```
## 'data.frame':	8 obs. of  1 variable:
##  $ y:Class 'AsIs'  chr [1:8] "A" "B" "C" "D" ...
```

```r
iWantThis <- c("w", "v")
jDat[iWantThis] # index with a vector of variable names
```

```
##       w v
## 1 -0.63 I
## 2  0.18 I
## 3 -0.84 J
## 4  1.60 J
## 5  0.33 K
## 6 -0.82 K
## 7  0.49 L
## 8  0.74 L
```

```r
str(jDat[c("w", "v")])
```

```
## 'data.frame':	8 obs. of  2 variables:
##  $ w: num  -0.63 0.18 -0.84 1.6 0.33 -0.82 0.49 0.74
##  $ v: Factor w/ 4 levels "I","J","K","L": 1 1 2 2 3 3 4 4
```

```r
str(subset(jDat, select = c(w, v))) # using subset() function
```

```
## 'data.frame':	8 obs. of  2 variables:
##  $ w: num  -0.63 0.18 -0.84 1.6 0.33 -0.82 0.49 0.74
##  $ v: Factor w/ 4 levels "I","J","K","L": 1 1 2 2 3 3 4 4
```

```r
#Demonstrating matrix-style indexing of a data.frame:

jDat[ , "v"]
```

```
## [1] I I J J K K L L
## Levels: I J K L
```

```r
str(jDat[ , "v"])
```

```
##  Factor w/ 4 levels "I","J","K","L": 1 1 2 2 3 3 4 4
```

```r
jDat[ , "v", drop = FALSE]
```

```
##   v
## 1 I
## 2 I
## 3 J
## 4 J
## 5 K
## 6 K
## 7 L
## 8 L
```

```r
str(jDat[ , "v", drop = FALSE])
```

```
## 'data.frame':	8 obs. of  1 variable:
##  $ v: Factor w/ 4 levels "I","J","K","L": 1 1 2 2 3 3 4 4
```

```r
jDat[c(2, 4, 7), c(1, 4)] # awful and arbitrary but syntax works
```

```
##      w    z
## 2 0.18 TRUE
## 4 1.60 TRUE
## 7 0.49 TRUE
```

```r
jDat[jDat$z, ]
```

```
##       w x y    z v
## 1 -0.63 1 A TRUE I
## 2  0.18 2 B TRUE I
## 3 -0.84 3 C TRUE J
## 4  1.60 4 D TRUE J
## 5  0.33 5 E TRUE K
## 7  0.49 7 G TRUE L
```

```r
subset(jDat, subset = z)
```

```
##       w x y    z v
## 1 -0.63 1 A TRUE I
## 2  0.18 2 B TRUE I
## 3 -0.84 3 C TRUE J
## 4  1.60 4 D TRUE J
## 5  0.33 5 E TRUE K
## 7  0.49 7 G TRUE L
```
