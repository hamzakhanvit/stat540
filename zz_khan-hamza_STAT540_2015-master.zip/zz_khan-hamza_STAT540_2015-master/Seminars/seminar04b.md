# sem04b
hamzakhanvit  
Saturday, January 31, 2015  


```r
suppressPackageStartupMessages(library(dplyr))
gd_url <- "http://tiny.cc/gapminder"
gdf <- read.delim(file = gd_url)
str(gdf)
```

```
## 'data.frame':	1704 obs. of  6 variables:
##  $ country  : Factor w/ 142 levels "Afghanistan",..: 1 1 1 1 1 1 1 1 1 1 ...
##  $ year     : int  1952 1957 1962 1967 1972 1977 1982 1987 1992 1997 ...
##  $ pop      : num  8425333 9240934 10267083 11537966 13079460 ...
##  $ continent: Factor w/ 5 levels "Africa","Americas",..: 3 3 3 3 3 3 3 3 3 3 ...
##  $ lifeExp  : num  28.8 30.3 32 34 36.1 ...
##  $ gdpPercap: num  779 821 853 836 740 ...
```

```r
head(gdf)
```

```
##       country year      pop continent lifeExp gdpPercap
## 1 Afghanistan 1952  8425333      Asia  28.801  779.4453
## 2 Afghanistan 1957  9240934      Asia  30.332  820.8530
## 3 Afghanistan 1962 10267083      Asia  31.997  853.1007
## 4 Afghanistan 1967 11537966      Asia  34.020  836.1971
## 5 Afghanistan 1972 13079460      Asia  36.088  739.9811
## 6 Afghanistan 1977 14880372      Asia  38.438  786.1134
```

```r
gtbl <- gd_url %>% read.delim %>% tbl_df

#Question 1. Which country gains the most growth in GDP in a 5-year interval?
#Question 2. Between which 2 years?
gtbl %>%
   group_by(country) %>%
   arrange(year) %>%
   select(country, year, gdpPercap ) %>%
   mutate(gdp_delta = gdpPercap  - lag(gdpPercap )) %>%
   summarize(best_gdp_delta = max(gdp_delta, na.rm = TRUE),  year2 = year[which(gdp_delta == max(gdp_delta, na.rm = TRUE))]) %>%
   filter(min_rank(desc(best_gdp_delta)) < 2) %>%
   arrange(best_gdp_delta)
```

```
## Source: local data frame [1 x 3]
## 
##   country best_gdp_delta year2
## 1  Kuwait       28452.98  1972
```

Kuwait had the highest growth in GDP in a 5-year period between 1972 and the year before.
