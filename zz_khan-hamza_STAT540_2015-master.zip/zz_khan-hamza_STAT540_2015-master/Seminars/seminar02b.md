# sem02b
hamzakhanvit  
Thursday, January 22, 2015  


```r
#Setting seed to 1 for uniformity
set.seed(1)
#creating a vector of 1000 values for x from -5 to 5 
min.x <- -5
max.x <- 5
num.samples <- 1000
x <- seq(from = min.x, to = max.x, length = num.samples)

# Open new blank plot with x limits from -5 to 5, and y limits from 0 to 1
plot(c(-5, 5), c(0, 1), xlab = 'x', ylab = 'f(x)', main = "Normal probability density function", type = "n")

# Add each density plot one at a time
lines(x, dnorm(x, mean = 0, sd = 0.5), lwd = 2, col = "red")

lines(x, dnorm(x, mean = 0, sd = 1), lwd = 2, col = "green")

lines(x, dnorm(x, mean = 0, sd = 2), lwd = 2, col = "blue")

lines(x, dnorm(x, mean = -2, sd = 1), lwd = 2, col = "magenta")

# We can also add a legend to the plot  
legend("topright", c("mean=0, sd=0.5", "mean=0, sd=1", "mean=0, sd=2", "mean=-2, sd=1"), col = c("red","green","blue","magenta"), lty = 1, lwd = 2)
```

![](seminar02b_files/figure-html/unnamed-chunk-1-1.png) 

```r
# Another approach using for loop
normal.mean <- c(0, 0, 0, -2)
normal.sd <- c(0.5, 1, 2, 1)
colors <- c("red", "green", "blue", "magenta")

# Open new plot with x limits from -5 to 5, and y limits from 0 to 1
plot(c(-5, 5), c(0, 1), xlab = 'x', ylab = 'f(x)', main = "Normal probability density function", type = "n")

# Add density plots with a for loop
for(i in 1:length(normal.mean)){
  lines(x, dnorm(x, mean = normal.mean[i], sd = normal.sd[i]), lwd = 2, col = colors[i])
}

# Add a legend to the plot  
legend("topright", paste0("mean=", normal.mean, ", sd=", normal.sd), col = colors, lty = 1, lwd = 2)
```

![](seminar02b_files/figure-html/unnamed-chunk-1-2.png) 

```r
#Learning about mapply function and functional programming
# Open new plot with x limits from -5 to 5, and y limits from 0 to 1
plot(c(-5, 5), c(0, 1), xlab = 'x', ylab = 'f(x)', main = "Normal probability density function", type = "n")

# Create our own user-defined function for plotting Normal probability density function
f <- function(col, ...){
  lines(x, dnorm(x, ...), col = col, lwd = 2)
}

# apply this function with different parameters
plot.status <- mapply(f, mean = normal.mean, sd = normal.sd, col = colors)

# Add a legend to the plot  
legend("topright", paste0("mean=", normal.mean, ", sd=", normal.sd), col = colors, lty = 1, lwd = 2)
```

![](seminar02b_files/figure-html/unnamed-chunk-1-3.png) 

```r
#Simulating data
set.seed(1)
normal.mean <- 1
normal.sd <- 1
rnorm(n = 5, mean = normal.mean, sd = normal.sd)
```

```
## [1] 0.3735462 1.1836433 0.1643714 2.5952808 1.3295078
```

```r
#Trying a bigger sample of 1000 and comparing it to the true distribution
# Draw a sample
set.seed(1)

y <- rnorm(n=1000, mean = normal.mean, sd = normal.sd)

# Estimate sample density
estimated.density <- density(y)

# Plot the estimated density
plot(estimated.density, col="blue", lwd = 2)

# Add the data points under the density plot and colors them organge
rug(y, col="orange")

# Plot the true density lines
x <- seq(from = -5, to = 5, length=1000)

true.density <- dnorm(x, mean = normal.mean, sd = normal.sd)

lines(x, true.density, col="red", lwd = 2)

legend("topright", c("sample density", "true density"), col = c("blue", "red"), lty = 1, lwd = 2)
```

![](seminar02b_files/figure-html/unnamed-chunk-1-4.png) 
Computing Descriptive Statistics


```r
set.seed(1)

normal.mean <- 1
normal.sd <- 1

(true.mean <- normal.mean)
```

```
## [1] 1
```

```r
#Drawing 100 observations from the distribution and comparing the sample mean to the true mean.

n <- 100
y <- rnorm(n, mean = normal.mean, sd = normal.sd)

# This is the sample mean
(y.mean <- mean(y))
```

```
## [1] 1.108887
```

```r
# Comparing the sample mean to the true mean
y.mean - true.mean
```

```
## [1] 0.1088874
```

```r
#EXERCISE 1
n <- 100
t <- rnorm(n, mean = normal.mean, sd = normal.sd)

# sample mean
(t.mean <- mean(t))
```

```
## [1] 0.9621919
```

```r
#Sample variance
(t.variance <- var(t))
```

```
## [1] 0.9175323
```

```r
#Manually calculating sample mean
Manual_mean <- 0
for (i in 1:100 ) {
Manual_mean = Manual_mean+t[i]
}
(Manual_mean = Manual_mean/n)
```

```
## [1] 0.9621919
```

```r
#Manually calculating variance
Manual_var <- 0
for (i in 1:100 ) {
Manual_var = Manual_var+(t[i]-Manual_mean)^2
}
Manual_var
```

```
## [1] 90.8357
```

```r
(Manual_var = Manual_var/(n-1))
```

```
## [1] 0.9175323
```

```r
#Enumerating difference of sample mean and variance using the built in functions mean and var with manual implementation.
t.mean - Manual_mean
```

```
## [1] -2.220446e-16
```

```r
t.variance - Manual_var
```

```
## [1] 2.220446e-16
```

```r
#Generating 100 different samples each of size 10 and storing this data in a matrix where each row represents a single sample.
set.seed(1)

# Number of samples
num.samp <- 100

# Size of each sample
samp.size <- 10

# Generate the samples in a matrix with num.samp rows and samp.size columns
y <- matrix(rnorm(n = num.samp * samp.size, mean = normal.mean, sd = normal.sd),
            nrow = num.samp, ncol=samp.size)

#Calculating mean
y.mean <- apply(y, 1, mean)

#Exercise 2: What would the following code do y.means <- apply(y, 2, mean)?
# It will calculate the mean of columns. (Note: In apply() - 1 means rows, 2 means columns)

#checking length and first few lines
length(y.mean)
```

```
## [1] 100
```

```r
head(y.mean)
```

```
## [1] 0.7531053 1.4308355 1.1723149 1.0056772 0.8410406 1.2483291
```

```r
#Using rowMeans() to do the same thing
y.mean <- rowMeans(y)
#Cross-checking again
length(y.mean)
```

```
## [1] 100
```

```r
head(y.mean)
```

```
## [1] 0.7531053 1.4308355 1.1723149 1.0056772 0.8410406 1.2483291
```

```r
#Computing the difference between the sample mean and the true mean.

mean.diff <- y.mean - true.mean
#Inspecting the first few values
head(mean.diff)
```

```
## [1] -0.246894746  0.430835507  0.172314940  0.005677169 -0.158959383
## [6]  0.248329100
```

```r
#Making a boxplot of the differences.
boxplot(mean.diff)
```

![](seminar02b_files/figure-html/unnamed-chunk-2-1.png) 

```r
#Exploring WLLN
#Making a function out of the code we just implemented. This could be used to compute the differences of means across a range of sample sizes.
normalSampleMean <- function(normal.mean, normal.sd, num.samp, samp.size){
  y <- matrix(rnorm(n = num.samp * samp.size, mean = normal.mean, sd = normal.sd),
              nrow = num.samp, ncol=samp.size)

  y.mean <- rowMeans(y)

  return(y.mean)
}

#Sample sizes 1 to 10k
samp.sizes <- c(10, 100, 1000, 1e4)
names(samp.sizes) <- paste0("n=", samp.sizes)
samp.sizes
```

```
##    n=10   n=100  n=1000 n=10000 
##      10     100    1000   10000
```

```r
#Using sapply to call the function normalSampleMean for different sample sizes.

set.seed(1)
num.samp <- 100
y.mean <- sapply(samp.sizes, normalSampleMean, num.samp = num.samp, normal.mean = normal.mean, normal.sd = normal.sd)

#Using for loop for the same
set.seed(1)
num.samp <- 100

# Create an empty matrix to store y.means later
y.mean <- matrix(nrow = num.samp, ncol = length(samp.sizes), dimnames = list(c(1:num.samp),names(samp.sizes)))

# Compute y.means
for(i in 1:length(samp.sizes)){
  y.mean[,i] <- normalSampleMean(samp.size = samp.sizes[i], num.samp = num.samp, normal.mean = normal.mean, normal.sd = normal.sd)
}

boxplot(y.mean - true.mean, xlab = "Sample size (n)", ylab = expression(bar(Y)[n]-mu))
```

![](seminar02b_files/figure-html/unnamed-chunk-2-2.png) 





CENTRAL LIMIT THEOREM


```r
#To show that CLT holds true even when the original distribution is not normal, we will work with a Chi-square distribution with its degrees of freedom df=1. This distribution looks like this:

df <- 1

x <- seq(0, 10, length=1000)

plot(x, dchisq(x, df = df), type="l", xlab='x', ylab='f(x)', main="Chi-square probability density function")
```

![](seminar02b_files/figure-html/unnamed-chunk-3-1.png) 

```r
#Simulating variables
set.seed(1)

# set sample size and the number of samples to draw
samp.size <- 5

num.samp <- 1000

# Draw 1000 samples and compute means
y <- matrix(rchisq(n = num.samp * samp.size, df = df), nrow = num.samp, ncol=samp.size)
y.mean <- rowMeans(y)

#Computing Zn with the true mean and variance given below.

# Computing the true values
true.mean <- df
true.variance <- df*2

# Computing normalised values
z.n <- (sqrt(samp.size) * (y.mean - true.mean)) / sqrt(true.variance)

# Plotting a histogram
hist(z.n, probability=TRUE, xlab=expression(Z[n]))

# Computing the normal density and overlay it on the plot in red
y <- seq(min(z.n), max(z.n), length=1000)
dens <- dnorm(y, mean=0, sd=1)
lines(y, dens, col="red")
```

![](seminar02b_files/figure-html/unnamed-chunk-3-2.png) 

```r
#Making a few functions to make things easier
#Zn function
chisqNormalisedMean <- function(df, num.samp, samp.size){
  # Compute the true values
  true.mean <- df

  true.variance <- df*2

  # Draw samples 
  y <- matrix(rchisq(n = num.samp * samp.size, df = df), nrow = num.samp, ncol=samp.size)

  y.mean <- rowMeans(y)

  # Compute normalised values
  z.n <- (sqrt(samp.size) * (y.mean - true.mean)) / sqrt(true.variance)

  return(z.n)
}

# put the plotting code into a function.

plotNormalComparison <- function(df, num.samp, n){
  z.n <- chisqNormalisedMean(df, num.samp, n)

  # It will be nice to have a title
  fig.title <- paste0("sample size = ", n)

  # Plot a histogram
  hist(z.n, probability=TRUE, main=fig.title, xlab=expression(Z[n]))

  # Compute the normal density and overlay it on the plot in red
  y <- seq(min(z.n), max(z.n), length=1000)

  dens <- dnorm(y, mean=0, sd=1)

  lines(y, dens, col="red")
}

#Trying some different values of n using lapply function
set.seed(1)
samp.sizes <- c(5, 10, 100, 1000)
plot.status <- lapply(samp.sizes, plotNormalComparison, num.samp = num.samp, df = df)
```

![](seminar02b_files/figure-html/unnamed-chunk-3-3.png) ![](seminar02b_files/figure-html/unnamed-chunk-3-4.png) ![](seminar02b_files/figure-html/unnamed-chunk-3-5.png) ![](seminar02b_files/figure-html/unnamed-chunk-3-6.png) 

```r
# formally check the results using the Kolmogorov-Smirnov (KS) test for n=5
set.seed(1)
n <- 5
z.n <- chisqNormalisedMean(df, num.samp, n)
ks.test(z.n, pnorm, mean=0, sd=1)
```

```
## 
## 	One-sample Kolmogorov-Smirnov test
## 
## data:  z.n
## D = 0.0719, p-value = 6.463e-05
## alternative hypothesis: two-sided
```

```r
#With n=1000
set.seed(1)
n <- 1000
z.n <- chisqNormalisedMean(df, num.samp, n)
ks.test(z.n, pnorm, mean=0, sd=1)
```

```
## 
## 	One-sample Kolmogorov-Smirnov test
## 
## data:  z.n
## D = 0.0264, p-value = 0.4895
## alternative hypothesis: two-sided
```

TAKE HOME PROBLEM


```r
## Taking pr as the probability to get a head and n as the sample size
pr <- 0.6
n <- 50
```



```r
sim <- rbinom(n = n, size = 1, prob = pr)
sim
```

```
##  [1] 0 1 0 1 0 1 0 1 0 0 1 1 0 1 1 1 1 1 0 0 1 1 0 1 1 1 1 0 0 0 1 1 1 0 0
## [36] 0 1 1 0 1 1 0 1 0 1 0 1 1 1 0
```

```r
(prop <- length(which(sim == T))/n)
```

```
## [1] 0.58
```

The probability comes out to be close to 0.6.


```r
##  Running several simulations with increasing number of coin flips from 10 to 1000000.
length <- 100
n <- seq(from = 10, to = 1000000,length.out = length)

sim <- NULL
for(i in 1:length(n)){
  sim[i] <- length(which(rbinom(n = n[i], size = 1, prob = pr) == T))/n[i]
}
```

The Plot


```r
plot(sim, xlim = c(0, length), ylim = c(0.55, 0.65), xlab = "simulation index", ylab = "probability", type = "l")
abline(pr,0, col = "black")
```

![](seminar02b_files/figure-html/unnamed-chunk-7-1.png) 



The observed probability seems to get closer to the expected pobability (here its 0.6) as the number of flips grow larger.
One can alter the value of 'pr' and 'n' to run the code for a different probability and sample size.

