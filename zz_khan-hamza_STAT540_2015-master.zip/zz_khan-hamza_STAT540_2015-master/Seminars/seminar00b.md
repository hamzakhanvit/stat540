# seminar00b
hamzakhanvit  
Wednesday, January 21, 2015  


```r
#Testing a simple assignment to verify ObjectName <- value
x <- 3*4
x
```

```
## [1] 12
```

```r
#Testing long names with tabs in console
this_is_a_very_long_name=3.5

#Inspecting variable names
jenny_rocks <- 2 ^ 3
jenny_rocks
```

```
## [1] 8
```

```r
#jeny_rocks, jennyrocks returns errors.
```
Learning seq()

```r
seq(1,10)
```

```
##  [1]  1  2  3  4  5  6  7  8  9 10
```

```r
#Learning seq assignments
y <- seq(1,10)
y
```

```
##  [1]  1  2  3  4  5  6  7  8  9 10
```

```r
#Surrounding the assignment with paranthesis causes assignment and "print to screen" simultaneously
(y <- seq(1,10))
```

```
##  [1]  1  2  3  4  5  6  7  8  9 10
```

```r
#Not all functions require arguements. For example; date()
date()
```

```
## [1] "Fri Jan 23 15:52:09 2015"
```

```r
#Listing objects
objects()
```

```
## [1] "jenny_rocks"              "this_is_a_very_long_name"
## [3] "x"                        "y"
```

```r
ls()
```

```
## [1] "jenny_rocks"              "this_is_a_very_long_name"
## [3] "x"                        "y"
```

```r
#Removing an object
rm(y)

ls()
```

```
## [1] "jenny_rocks"              "this_is_a_very_long_name"
## [3] "x"
```

```r
#Removing everything
rm(list=ls())
ls()
```

```
## character(0)
```

```r
#Display working directory
getwd()
```

```
## [1] "C:/Users/HAMZA/Desktop/zz_khan-hamza_STAT540_2015"
```

```r
# A simple example and plot

a <- 2
b <- -3
sig_sq <- 0.5
x <- runif(40)
y <- a + b * x + rnorm(40, sd = sqrt(sig_sq))
(avg_x <- mean(x))
```

```
## [1] 0.5393205
```

```r
write(avg_x, "avg_x.txt")
plot(x, y)
abline(a, b, col = "purple")
```

![](seminar00b_files/figure-html/unnamed-chunk-2-1.png) 
