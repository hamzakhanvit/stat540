# Seminar09
hamzakhanvit  
Wednesday, March 18, 2015  
##Take-home problem

(1)Draw a plot with number of clusters in the x-axis and the average silhouette widths in the y-axis. Use the information obtained to determine if 5 was the best choice for the number of clusters.

```r
options(warn=-1) #Avoiding the display of warnings
library(RColorBrewer)
library(cluster)
library(pvclust)
library(xtable)
library(limma)
library(plyr)
library(lattice)


prDat <- read.table("GSE4051_data.tsv.txt",
                    header = TRUE, row.names = 1) # the whole enchilada
str(prDat, max.level = 0)
```

```
## 'data.frame':	29949 obs. of  39 variables:
```

```r
prDes <- readRDS("GSE4051_design.rds")
str(prDes)
```

```
## 'data.frame':	39 obs. of  4 variables:
##  $ sidChar : chr  "Sample_20" "Sample_21" "Sample_22" "Sample_23" ...
##  $ sidNum  : num  20 21 22 23 16 17 6 24 25 26 ...
##  $ devStage: Factor w/ 5 levels "E16","P2","P6",..: 1 1 1 1 1 1 1 2 2 2 ...
##  $ gType   : Factor w/ 2 levels "wt","NrlKO": 1 1 1 1 2 2 2 1 1 1 ...
```
Lets make a distance matrix first

```r
tr.dat  <-(t(prDat))
scale.tr.dat <- scale(tr.dat)
dis.dat <- dist(scale.tr.dat)
```
Lets make the plot

```r
b <- unlist(sapply((2:10), function (k) {
    pam(dis.dat, k = k)$silinfo$avg.width
}))
plot((2:10), b, type="b", xlab="clusters", ylab="Average silhouette width")
```

![](seminar09_files/figure-html/unnamed-chunk-3-1.png) 

As the number of clusters increase, the average silhouette width decreases. Looks like there is little peak at 4 clusters as compared to 5 clusters. Moreover, 2  clusters seems to display the characteristics of the data better than 5 which could be due to the two genotypes present in the samples.

(2)For a common choice of k, compare the clustering across different methods, e.g. hierarchical (pruned to specific k, obviously), k-means, PAM. You will re-discover the "label switching problem" for yourself. How does that manifest itself? How concordant are the clusterings for different methods?

Taking K = 4

```r
k <- 4
```
HIERARCHIAL CLUSTERING

```r
prDes$grp <- with(prDes, interaction(gType, devStage))
hc.w <- hclust(dis.dat, method = 'ward.D')
pr.hc.w.lust <- cutree(hc.w, k = k)
ward.DTable <- table(data.frame(devStage = prDes$grp, ward_cluster = pr.hc.w.lust))
addmargins(ward.DTable, margin = seq_along(ncol(ward.DTable)), FUN = sum)
```

```
##                ward_cluster
## devStage         1  2  3  4
##   wt.E16         4  0  0  0
##   NrlKO.E16      2  1  0  0
##   wt.P2          0  0  4  0
##   NrlKO.P2       0  1  3  0
##   wt.P6          1  0  3  0
##   NrlKO.P6       0  1  3  0
##   wt.P10         1  2  1  0
##   NrlKO.P10      1  0  0  3
##   wt.4_weeks     1  0  0  3
##   NrlKO.4_weeks  1  0  1  2
##   sum           11  5 15  8
```
PAM CLUSTERING

```r
pr.pam <- pam(dis.dat, k = k)
pamdat <- cbind.data.frame(group = prDes$grp,
                pamclust = pr.pam$clustering)
pamtab <- table(pamdat)
addmargins(pamtab, margin = seq_along(ncol(pamtab)), FUN = sum)
```

```
##                pamclust
## group            1  2  3  4
##   wt.E16         4  0  0  0
##   NrlKO.E16      2  1  0  0
##   wt.P2          0  2  2  0
##   NrlKO.P2       0  2  2  0
##   wt.P6          1  1  2  0
##   NrlKO.P6       0  1  3  0
##   wt.P10         0  2  1  1
##   NrlKO.P10      0  0  4  0
##   wt.4_weeks     0  0  0  4
##   NrlKO.4_weeks  1  0  1  2
##   sum            8  9 15  7
```

K-MEANS CLUSTERING

```r
pr.km <- kmeans(t(prDat), centers = k, nstart =  50)
pr.kmTable <- data.frame(group = prDes$grp, cluster = pr.km$cluster)
ptab <- table(pr.kmTable)
addmargins(ptab, margin = seq_along(ncol(ptab)), FUN = sum)
```

```
##                cluster
## group            1  2  3  4
##   wt.E16         0  4  0  0
##   NrlKO.E16      0  2  0  1
##   wt.P2          3  0  0  1
##   NrlKO.P2       3  0  0  1
##   wt.P6          2  1  0  1
##   NrlKO.P6       3  0  0  1
##   wt.P10         1  0  1  2
##   NrlKO.P10      0  0  4  0
##   wt.4_weeks     0  0  4  0
##   NrlKO.4_weeks  0  1  3  0
##   sum           12  8 12  7
```
Looks that PAM and K-means clustering methods have similar results which are different from the results obtained from hierarchical clustering methods.
