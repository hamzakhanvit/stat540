# seminar07a
hamzakhanvit  
Tuesday, March 3, 2015  


```r
#Loading Libraries
library(ShortRead)
```

```
## Loading required package: BiocGenerics
## Loading required package: parallel
## 
## Attaching package: 'BiocGenerics'
## 
## The following objects are masked from 'package:parallel':
## 
##     clusterApply, clusterApplyLB, clusterCall, clusterEvalQ,
##     clusterExport, clusterMap, parApply, parCapply, parLapply,
##     parLapplyLB, parRapply, parSapply, parSapplyLB
## 
## The following object is masked from 'package:stats':
## 
##     xtabs
## 
## The following objects are masked from 'package:base':
## 
##     anyDuplicated, append, as.data.frame, as.vector, cbind,
##     colnames, do.call, duplicated, eval, evalq, Filter, Find, get,
##     intersect, is.unsorted, lapply, Map, mapply, match, mget,
##     order, paste, pmax, pmax.int, pmin, pmin.int, Position, rank,
##     rbind, Reduce, rep.int, rownames, sapply, setdiff, sort,
##     table, tapply, union, unique, unlist, unsplit
## 
## Loading required package: BiocParallel
## Loading required package: Biostrings
## Loading required package: S4Vectors
## Loading required package: stats4
## Loading required package: IRanges
## Loading required package: XVector
## Loading required package: Rsamtools
## Loading required package: GenomeInfoDb
## Loading required package: GenomicRanges
## Loading required package: GenomicAlignments
```

```r
library(Rsamtools)
library(easyRNASeq)

#Loading Files
bamDat <- readAligned("drosophilaMelanogasterSubset.bam", type="BAM")
str(bamDat)
```

```
## Formal class 'AlignedRead' [package "ShortRead"] with 8 slots
##   ..@ chromosome  : Factor w/ 15 levels "chrYHet","chrM",..: 2 2 2 2 2 2 2 2 2 2 ...
##   ..@ position    : int [1:64206] 548 1497 1506 1528 1540 1552 1552 1555 1559 1566 ...
##   ..@ strand      : Factor w/ 3 levels "+","-","*": 2 1 1 1 1 1 1 1 2 2 ...
##   ..@ alignQuality:Formal class 'NumericQuality' [package "ShortRead"] with 1 slot
##   .. .. ..@ quality: int [1:64206] 132 132 127 130 130 122 132 132 132 132 ...
##   ..@ alignData   :Formal class 'AlignedDataFrame' [package "ShortRead"] with 4 slots
##   .. .. ..@ varMetadata      :'data.frame':	1 obs. of  1 variable:
##   .. .. .. ..$ labelDescription: chr "Type of read; see ?scanBam"
##   .. .. ..@ data             :'data.frame':	64206 obs. of  1 variable:
##   .. .. .. ..$ flag: int [1:64206] 16 0 0 0 0 0 0 0 16 16 ...
##   .. .. ..@ dimLabels        : chr [1:2] "readName" "alignColumn"
##   .. .. ..@ .__classVersion__:Formal class 'Versions' [package "Biobase"] with 1 slot
##   .. .. .. .. ..@ .Data:List of 1
##   .. .. .. .. .. ..$ : int [1:3] 1 1 0
##   ..@ quality     :Formal class 'FastqQuality' [package "ShortRead"] with 1 slot
##   .. .. ..@ quality:Formal class 'BStringSet' [package "Biostrings"] with 5 slots
##   .. .. .. .. ..@ pool           :Formal class 'SharedRaw_Pool' [package "XVector"] with 2 slots
##   .. .. .. .. .. .. ..@ xp_list                    :List of 1
##   .. .. .. .. .. .. .. ..$ :<externalptr> 
##   .. .. .. .. .. .. ..@ .link_to_cached_object_list:List of 1
##   .. .. .. .. .. .. .. ..$ :<environment: 0x000000000b62e6f8> 
##   .. .. .. .. ..@ ranges         :Formal class 'GroupedIRanges' [package "XVector"] with 7 slots
##   .. .. .. .. .. .. ..@ group          : int [1:64206] 1 1 1 1 1 1 1 1 1 1 ...
##   .. .. .. .. .. .. ..@ start          : int [1:64206] 1 37 73 109 145 181 217 253 289 325 ...
##   .. .. .. .. .. .. ..@ width          : int [1:64206] 36 36 36 36 36 36 36 36 36 36 ...
##   .. .. .. .. .. .. ..@ NAMES          : NULL
##   .. .. .. .. .. .. ..@ elementType    : chr "integer"
##   .. .. .. .. .. .. ..@ elementMetadata: NULL
##   .. .. .. .. .. .. ..@ metadata       : list()
##   .. .. .. .. ..@ elementType    : chr "BString"
##   .. .. .. .. ..@ elementMetadata: NULL
##   .. .. .. .. ..@ metadata       : list()
##   ..@ sread       :Formal class 'DNAStringSet' [package "Biostrings"] with 5 slots
##   .. .. ..@ pool           :Formal class 'SharedRaw_Pool' [package "XVector"] with 2 slots
##   .. .. .. .. ..@ xp_list                    :List of 1
##   .. .. .. .. .. ..$ :<externalptr> 
##   .. .. .. .. ..@ .link_to_cached_object_list:List of 1
##   .. .. .. .. .. ..$ :<environment: 0x000000000b62e6f8> 
##   .. .. ..@ ranges         :Formal class 'GroupedIRanges' [package "XVector"] with 7 slots
##   .. .. .. .. ..@ group          : int [1:64206] 1 1 1 1 1 1 1 1 1 1 ...
##   .. .. .. .. ..@ start          : int [1:64206] 1 37 73 109 145 181 217 253 289 325 ...
##   .. .. .. .. ..@ width          : int [1:64206] 36 36 36 36 36 36 36 36 36 36 ...
##   .. .. .. .. ..@ NAMES          : NULL
##   .. .. .. .. ..@ elementType    : chr "integer"
##   .. .. .. .. ..@ elementMetadata: NULL
##   .. .. .. .. ..@ metadata       : list()
##   .. .. ..@ elementType    : chr "DNAString"
##   .. .. ..@ elementMetadata: NULL
##   .. .. ..@ metadata       : list()
##   ..@ id          :Formal class 'BStringSet' [package "Biostrings"] with 5 slots
##   .. .. ..@ pool           :Formal class 'SharedRaw_Pool' [package "XVector"] with 2 slots
##   .. .. .. .. ..@ xp_list                    :List of 1
##   .. .. .. .. .. ..$ :<externalptr> 
##   .. .. .. .. ..@ .link_to_cached_object_list:List of 1
##   .. .. .. .. .. ..$ :<environment: 0x000000000b62e6f8> 
##   .. .. ..@ ranges         :Formal class 'GroupedIRanges' [package "XVector"] with 7 slots
##   .. .. .. .. ..@ group          : int [1:64206] 1 1 1 1 1 1 1 1 1 1 ...
##   .. .. .. .. ..@ start          : int [1:64206] 1 29 57 85 114 144 173 202 230 260 ...
##   .. .. .. .. ..@ width          : int [1:64206] 28 28 28 29 30 29 29 28 30 30 ...
##   .. .. .. .. ..@ NAMES          : NULL
##   .. .. .. .. ..@ elementType    : chr "integer"
##   .. .. .. .. ..@ elementMetadata: NULL
##   .. .. .. .. ..@ metadata       : list()
##   .. .. ..@ elementType    : chr "BString"
##   .. .. ..@ elementMetadata: NULL
##   .. .. ..@ metadata       : list()
```

```r
indexFile <- indexBam("drosophilaMelanogasterSubset.bam")
```
Filering Reads

```r
#nFilt will keep only reads with at most 2 N's
nFilt <- nFilter(2)
#keep only reads which have been aligned to the reference genome by testing the presence of 'chr'
chrFilt <- chromosomeFilter(regex="chr")
#Combining the two filters
filt <- compose(nFilt, chrFilt)
#Extract data on the b/o filters
bamDatFiltered <- bamDat[filt(bamDat)]
```
Examining the BAM File

```r
str(bamDatFiltered)
```

```
## Formal class 'AlignedRead' [package "ShortRead"] with 8 slots
##   ..@ chromosome  : Factor w/ 7 levels "chrM","chr2L",..: 1 1 1 1 1 1 1 1 1 1 ...
##   ..@ position    : int [1:56883] 548 1497 1506 1528 1540 1552 1552 1555 1559 1566 ...
##   ..@ strand      : Factor w/ 3 levels "+","-","*": 2 1 1 1 1 1 1 1 2 2 ...
##   ..@ alignQuality:Formal class 'NumericQuality' [package "ShortRead"] with 1 slot
##   .. .. ..@ quality: int [1:56883] 132 132 127 130 130 122 132 132 132 132 ...
##   ..@ alignData   :Formal class 'AlignedDataFrame' [package "ShortRead"] with 4 slots
##   .. .. ..@ varMetadata      :'data.frame':	1 obs. of  1 variable:
##   .. .. .. ..$ labelDescription: chr "Type of read; see ?scanBam"
##   .. .. ..@ data             :'data.frame':	56883 obs. of  1 variable:
##   .. .. .. ..$ flag: int [1:56883] 16 0 0 0 0 0 0 0 16 16 ...
##   .. .. ..@ dimLabels        : chr [1:2] "readName" "alignColumn"
##   .. .. ..@ .__classVersion__:Formal class 'Versions' [package "Biobase"] with 1 slot
##   .. .. .. .. ..@ .Data:List of 1
##   .. .. .. .. .. ..$ : int [1:3] 1 1 0
##   ..@ quality     :Formal class 'FastqQuality' [package "ShortRead"] with 1 slot
##   .. .. ..@ quality:Formal class 'BStringSet' [package "Biostrings"] with 5 slots
##   .. .. .. .. ..@ pool           :Formal class 'SharedRaw_Pool' [package "XVector"] with 2 slots
##   .. .. .. .. .. .. ..@ xp_list                    :List of 1
##   .. .. .. .. .. .. .. ..$ :<externalptr> 
##   .. .. .. .. .. .. ..@ .link_to_cached_object_list:List of 1
##   .. .. .. .. .. .. .. ..$ :<environment: 0x000000000b62e6f8> 
##   .. .. .. .. ..@ ranges         :Formal class 'GroupedIRanges' [package "XVector"] with 7 slots
##   .. .. .. .. .. .. ..@ group          : int [1:56883] 1 1 1 1 1 1 1 1 1 1 ...
##   .. .. .. .. .. .. ..@ start          : int [1:56883] 1 37 73 109 145 181 217 253 289 325 ...
##   .. .. .. .. .. .. ..@ width          : int [1:56883] 36 36 36 36 36 36 36 36 36 36 ...
##   .. .. .. .. .. .. ..@ NAMES          : NULL
##   .. .. .. .. .. .. ..@ elementType    : chr "integer"
##   .. .. .. .. .. .. ..@ elementMetadata: NULL
##   .. .. .. .. .. .. ..@ metadata       : list()
##   .. .. .. .. ..@ elementType    : chr "BString"
##   .. .. .. .. ..@ elementMetadata: NULL
##   .. .. .. .. ..@ metadata       : list()
##   ..@ sread       :Formal class 'DNAStringSet' [package "Biostrings"] with 5 slots
##   .. .. ..@ pool           :Formal class 'SharedRaw_Pool' [package "XVector"] with 2 slots
##   .. .. .. .. ..@ xp_list                    :List of 1
##   .. .. .. .. .. ..$ :<externalptr> 
##   .. .. .. .. ..@ .link_to_cached_object_list:List of 1
##   .. .. .. .. .. ..$ :<environment: 0x000000000b62e6f8> 
##   .. .. ..@ ranges         :Formal class 'GroupedIRanges' [package "XVector"] with 7 slots
##   .. .. .. .. ..@ group          : int [1:56883] 1 1 1 1 1 1 1 1 1 1 ...
##   .. .. .. .. ..@ start          : int [1:56883] 1 37 73 109 145 181 217 253 289 325 ...
##   .. .. .. .. ..@ width          : int [1:56883] 36 36 36 36 36 36 36 36 36 36 ...
##   .. .. .. .. ..@ NAMES          : NULL
##   .. .. .. .. ..@ elementType    : chr "integer"
##   .. .. .. .. ..@ elementMetadata: NULL
##   .. .. .. .. ..@ metadata       : list()
##   .. .. ..@ elementType    : chr "DNAString"
##   .. .. ..@ elementMetadata: NULL
##   .. .. ..@ metadata       : list()
##   ..@ id          :Formal class 'BStringSet' [package "Biostrings"] with 5 slots
##   .. .. ..@ pool           :Formal class 'SharedRaw_Pool' [package "XVector"] with 2 slots
##   .. .. .. .. ..@ xp_list                    :List of 1
##   .. .. .. .. .. ..$ :<externalptr> 
##   .. .. .. .. ..@ .link_to_cached_object_list:List of 1
##   .. .. .. .. .. ..$ :<environment: 0x000000000b62e6f8> 
##   .. .. ..@ ranges         :Formal class 'GroupedIRanges' [package "XVector"] with 7 slots
##   .. .. .. .. ..@ group          : int [1:56883] 1 1 1 1 1 1 1 1 1 1 ...
##   .. .. .. .. ..@ start          : int [1:56883] 1 29 57 85 114 144 173 202 230 260 ...
##   .. .. .. .. ..@ width          : int [1:56883] 28 28 28 29 30 29 29 28 30 30 ...
##   .. .. .. .. ..@ NAMES          : NULL
##   .. .. .. .. ..@ elementType    : chr "integer"
##   .. .. .. .. ..@ elementMetadata: NULL
##   .. .. .. .. ..@ metadata       : list()
##   .. .. ..@ elementType    : chr "BString"
##   .. .. ..@ elementMetadata: NULL
##   .. .. ..@ metadata       : list()
```

```r
#Levels for chromosome
levels(chromosome(bamDatFiltered))
```

```
## [1] "chrM"  "chr2L" "chrX"  "chr3L" "chr4"  "chr2R" "chr3R"
```

```r
#Looking at the reads ids for the first 10 reads
id(bamDatFiltered)[1:10]
```

```
##   A BStringSet instance of length 10
##      width seq
##  [1]    28 HWI-EAS225_90320:3:1:141:680
##  [2]    28 HWI-EAS225_90320:3:1:660:332
##  [3]    28 HWI-EAS225_90320:3:1:164:226
##  [4]    29 HWI-EAS225_90320:3:1:1088:176
##  [5]    30 HWI-EAS225_90320:3:1:1038:1484
##  [6]    29 HWI-EAS225_90320:3:1:850:1742
##  [7]    29 HWI-EAS225_90320:3:1:1319:586
##  [8]    28 HWI-EAS225_90320:3:1:103:631
##  [9]    30 HWI-EAS225_90320:3:1:1353:1498
## [10]    30 HWI-EAS225_90320:3:1:1092:1016
```

```r
#Looking at the first 10 lines for a read
sread(bamDatFiltered)[1:10]
```

```
##   A DNAStringSet instance of length 10
##      width seq
##  [1]    36 GGAAATCAAAAATGGAAAGGAGCGGCTCCACTTTTT
##  [2]    36 AAATCATAAAGATATTGGAACTTTATATTTTATTTT
##  [3]    36 AGATATTGGAACTTTATATTTTATTTTTGGAGCTTG
##  [4]    36 ATTTTTGGAGCTTGAGCTGGAATAGTTGGAACATCT
##  [5]    36 TGAGCTGGAATAGTTGGAACATCTTTAAGAATTTTA
##  [6]    36 GTTGGAACATCTTTAAGAATTTTAATTAGAGCTGAA
##  [7]    36 GTTGGAACATCTTTAAGAATTTTAATTCGAGCTGAA
##  [8]    36 GGAACATCTTTAAGAATTTTAATTCGAGCTGAATTA
##  [9]    36 GTCCTAATTCAGCTCGAATTAAAATTCTTAAAGATG
## [10]    36 CCAGGATGTCCTAATTCAGCTCGAATTAAAATTCTT
```

```r
# Need to ask PIs for the formula to convert ASCII to integer PHRED 

# position where the read was aligned on the chromosome for the first 10 reads
position(bamDatFiltered)[1:10]
```

```
##  [1]  548 1497 1506 1528 1540 1552 1552 1555 1559 1566
```

```r
# Strand where the read was aligned on the chromosome for the first 10 reads
strand(bamDatFiltered)[1:10]
```

```
##  [1] - + + + + + + + - -
## Levels: + - *
```

####Q. What are the differences between the filtered and unfiltered BAM files?


```r
#No of reads for the unfiltered data
length(position(bamDat))
```

```
## [1] 64206
```

```r
#No of reads for the filtered data
length(position(bamDatFiltered))
```

```
## [1] 56883
```
####Q. What are the chromosomes with aligned reads from the BAM file?

```r
summary(chromosome(bamDat))
```

```
##   chrYHet      chrM     chr2L      chrX     chr3L      chr4     chr2R 
##         0      1921      9839      8892      9231       739     12370 
##     chr3R chrUextra  chr2RHet  chr2LHet  chr3LHet  chr3RHet      chrU 
##     13891         0         0         0         0         0         0 
##   chrXHet      NA's 
##         0      7323
```

```r
summary(chromosome(bamDatFiltered))
```

```
##  chrM chr2L  chrX chr3L  chr4 chr2R chr3R 
##  1921  9839  8892  9231   739 12370 13891
```
Accessing Drosophila Genome Annotations

```r
library(BSgenome.Dmelanogaster.UCSC.dm3)
```

```
## Loading required package: BSgenome
## Loading required package: rtracklayer
```

```r
#length of the chromsomes in the genome.
(chrSizes <- seqlengths(Dmelanogaster))
```

```
##     chr2L     chr2R     chr3L     chr3R      chr4      chrX      chrU 
##  23011544  21146708  24543557  27905053   1351857  22422827  10049037 
##      chrM  chr2LHet  chr2RHet  chr3LHet  chr3RHet   chrXHet   chrYHet 
##     19517    368872   3288761   2555491   2517507    204112    347038 
## chrUextra 
##  29004656
```

```r
#Using the BioMart functionality of the Ensembl database to retrieve the annotations of Drosophila melagoaster chromosome 2L.
library(biomaRt)
ensembl <- useMart("ensembl", dataset="dmelanogaster_gene_ensembl")

#Defining our fields of interest
annotation.fields <- c("ensembl_gene_id",
                        "strand",
                        "chromosome_name",
                        "start_position",
                        "end_position")

#Downloading the annotation data as per our interest
gene.annotation <- getBM(annotation.fields,
                         mart=ensembl,
                         filters="chromosome_name",
                         values=c("2L"))
str(gene.annotation)
```

```
## 'data.frame':	2986 obs. of  5 variables:
##  $ ensembl_gene_id: chr  "FBgn0031208" "FBgn0002121" "FBgn0031209" "FBgn0263584" ...
##  $ strand         : int  1 -1 -1 1 -1 1 1 1 -1 1 ...
##  $ chromosome_name: chr  "2L" "2L" "2L" "2L" ...
##  $ start_position : int  7529 9839 21823 21952 25402 66584 71757 76348 82421 94739 ...
##  $ end_position   : int  9484 21376 25155 24237 65404 71390 76211 77783 87387 102086 ...
```

```r
#Adding 'chr' to the chromosome names
gene.annotation$chromosome <- paste("chr", gene.annotation$chromosome_name, sep='')

levels(as.factor(gene.annotation$chromosome))
```

```
## [1] "chr2L"
```

```r
#Storing gene annotation information in an IRanges object
gene.range <- RangedData(IRanges(start=gene.annotation$start_position,
                                 end=gene.annotation$end_position),
                                 space=gene.annotation$chromosome,
                                 strand=gene.annotation$strand,
                                 gene=gene.annotation$ensembl_gene_id,
                                 universe="Dm3")

show(gene.range)
```

```
## RangedData with 2986 rows and 2 value columns across 1 space
##         space               ranges   |    strand        gene
##      <factor>            <IRanges>   | <integer> <character>
## 1       chr2L       [ 7529,  9484]   |         1 FBgn0031208
## 2       chr2L       [ 9839, 21376]   |        -1 FBgn0002121
## 3       chr2L       [21823, 25155]   |        -1 FBgn0031209
## 4       chr2L       [21952, 24237]   |         1 FBgn0263584
## 5       chr2L       [25402, 65404]   |        -1 FBgn0051973
## 6       chr2L       [66584, 71390]   |         1 FBgn0067779
## 7       chr2L       [71757, 76211]   |         1 FBgn0031213
## 8       chr2L       [76348, 77783]   |         1 FBgn0031214
## 9       chr2L       [82421, 87387]   |        -1 FBgn0002931
## ...       ...                  ... ...       ...         ...
## 2978    chr2L [22690251, 22691008]   |        -1 FBgn0058439
## 2979    chr2L [22735486, 22736297]   |        -1 FBgn0262947
## 2980    chr2L [22736952, 22747273]   |         1 FBgn0041004
## 2981    chr2L [22811944, 22834955]   |         1 FBgn0002566
## 2982    chr2L [22841770, 22843208]   |        -1 FBgn0058005
## 2983    chr2L [22874534, 22885080]   |         1 FBgn0000384
## 2984    chr2L [22892306, 22918647]   |        -1 FBgn0250907
## 2985    chr2L [22959606, 22961179]   |        -1 FBgn0086683
## 2986    chr2L [22961737, 22963456]   |         1 FBgn0262887
```
Coverage Calculation

```r
#Evaluating the number of bases that cover each position in every chromosome.

(cover <- coverage(bamDatFiltered, width=chrSizes))
```

```
## RleList of length 7
## $chrM
## integer-Rle of length 19517 with 953 runs
##   Lengths:  547   36  913    9   22    5 ...    3    5   13  258   36 5793
##   Values :    0    1    0    1    2    3 ...    4    3    2    0    1    0
## 
## $chr2L
## integer-Rle of length 23011544 with 17850 runs
##   Lengths:  6777    36  2316    36  1621 ...   107    36   499    36 50474
##   Values :     0     1     0     1     0 ...     0     1     0     1     0
## 
## $chrX
## integer-Rle of length 22422827 with 16522 runs
##   Lengths:  18996     36  12225     36 ...     36    130     36   6180
##   Values :      0      1      0      1 ...      1      0      1      0
## 
## $chr3L
## integer-Rle of length 24543557 with 17396 runs
##   Lengths: 135455     36   6783     23 ...     36  82251     36  12469
##   Values :      0      1      0      1 ...      1      0      1      0
## 
## $chr4
## integer-Rle of length 1351857 with 1255 runs
##   Lengths:  59510     36   2019     36 ...     36    267     36 118808
##   Values :      0      1      0      1 ...      1      0      1      0
## 
## ...
## <2 more elements>
```

```r
#coverage on a per gene basis-
#Aggregating the coverage for each gene
gene.coverage <- aggregate(cover[match(names(gene.range),names(cover))],
                           ranges(gene.range),sum)

#Finding the number of reads covering each gene
gene.coverage <- ceiling(gene.coverage/unique(width(bamDat)))
gene.coverage
```

```
## NumericList of length 1
## [["chr2L"]] 1 47 0 0 1 6 0 0 8 11 1 1 58 ... 17 16 1 0 0 0 15 4 0 1 0 6 0
```

```r
#For chr2L
length(gene.coverage[["chr2L"]])
```

```
## [1] 2986
```

Building a count table and store it in a data frame, Using the coverage and gene annotation data.

```r
countTable <- data.frame(chromosome=gene.range$space,
                         gene_start=start(gene.range$ranges),
                         gene_end=end(gene.range$ranges),
                         strand=gene.range$strand,
                         gene=gene.range$gene,
                         count=as.vector(gene.coverage[["chr2L"]]))
dim(countTable)
```

```
## [1] 2986    6
```

```r
head(countTable)
```

```
##   chromosome gene_start gene_end strand        gene count
## 1      chr2L       7529     9484      1 FBgn0031208     1
## 2      chr2L       9839    21376     -1 FBgn0002121    47
## 3      chr2L      21823    25155     -1 FBgn0031209     0
## 4      chr2L      21952    24237      1 FBgn0263584     0
## 5      chr2L      25402    65404     -1 FBgn0051973     1
## 6      chr2L      66584    71390      1 FBgn0067779     6
```

##TAKE HOME PROBLEM
####Create a similar count table for all the exons located on chr2L.

```r
exon.annotation.fields <- c("ensembl_exon_id", "strand", "chromosome_name",
        "exon_chrom_start", "exon_chrom_end")
exon.annotation <- getBM( exon.annotation.fields,
                          mart = ensembl, 
                          filters = "chromosome_name", 
                          values = c("2L"))
str(exon.annotation)
```

```
## 'data.frame':	14402 obs. of  5 variables:
##  $ ensembl_exon_id : chr  "FBgn0031208:1" "FBgn0031208:3" "FBgn0031208:2" "FBgn0031208:5" ...
##  $ strand          : int  1 1 1 1 1 -1 -1 -1 -1 -1 ...
##  $ chromosome_name : chr  "2L" "2L" "2L" "2L" ...
##  $ exon_chrom_start: int  7529 8193 8193 8668 8229 21136 19885 14933 13683 13520 ...
##  $ exon_chrom_end  : int  8116 9484 8589 9484 9484 21376 20020 15711 14874 13625 ...
```

```r
exon.annotation$chromosome <- paste("chr", exon.annotation$chromosome_name,
    sep = "")

#Storing the gene annotation information in an IRanges object for the exons
exon.range <- RangedData(
    IRanges(
        start = exon.annotation$exon_chrom_start,
        end = exon.annotation$exon_chrom_end),
    space = exon.annotation$chromosome, strand = exon.annotation$strand,
    exon = exon.annotation$ensembl_exon_id,
    universe = "Dm3")
show(exon.range)
```

```
## RangedData with 14402 rows and 2 value columns across 1 space
##          space               ranges   |    strand              exon
##       <factor>            <IRanges>   | <integer>       <character>
## 1        chr2L       [ 7529,  8116]   |         1     FBgn0031208:1
## 2        chr2L       [ 8193,  9484]   |         1     FBgn0031208:3
## 3        chr2L       [ 8193,  8589]   |         1     FBgn0031208:2
## 4        chr2L       [ 8668,  9484]   |         1     FBgn0031208:5
## 5        chr2L       [ 8229,  9484]   |         1     FBgn0031208:4
## 6        chr2L       [21136, 21376]   |        -1    FBgn0002121:17
## 7        chr2L       [19885, 20020]   |        -1    FBgn0002121:13
## 8        chr2L       [14933, 15711]   |        -1     FBgn0002121:7
## 9        chr2L       [13683, 14874]   |        -1     FBgn0002121:6
## ...        ...                  ... ...       ...               ...
## 14394    chr2L [22908770, 22908836]   |        -1     FBgn0250907:8
## 14395    chr2L [22960932, 22961179]   |        -1     FBgn0086683:5
## 14396    chr2L [22959877, 22960876]   |        -1     FBgn0086683:3
## 14397    chr2L [22959606, 22959815]   |        -1     FBgn0086683:1
## 14398    chr2L [22960932, 22961179]   |        -1 FBgn0086683:52985
## 14399    chr2L [22959877, 22960833]   |        -1     FBgn0086683:2
## 14400    chr2L [22959877, 22960915]   |        -1     FBgn0086683:4
## 14401    chr2L [22961737, 22961993]   |         1     FBgn0262887:1
## 14402    chr2L [22962624, 22963456]   |         1     FBgn0262887:2
```

```r
#Calculating coverage
cover <- coverage(bamDatFiltered, width = chrSizes)

#Aggregating the coverage for each exon
exon.coverage <- aggregate(cover[match(names(exon.range), names(cover))],
    ranges(exon.range), sum)

##Finding the number of reads covering each exon
exon.coverage <- ceiling(exon.coverage/unique(width(bamDat)))
exon.coverage
```

```
## NumericList of length 1
## [["chr2L"]] 0 1 0 1 1 0 0 13 9 2 11 4 3 5 ... 0 0 0 0 0 0 1 4 1 1 4 4 0 0
```

Creating the count table using normalization value RPKM which is defined as the "number of Reads Per Kilobase of gene (feature) per Million mapped reads" 

```r
countTable <- data.frame(chromosome = exon.range$space, 
                         exon_start = start(exon.range$ranges),
                         exon_end = end(exon.range$ranges),
                         strand = exon.range$strand, exon = exon.range$exon,
                         count = as.vector(exon.coverage[["chr2L"]]), 
                         RPKM = (as.vector(exon.coverage[["chr2L"]])/(end(exon.range$ranges) - start(exon.range$ranges))) * (1000000000/length(bamDat)))
head(countTable)
```

```
##   chromosome exon_start exon_end strand           exon count     RPKM
## 1      chr2L       7529     8116      1  FBgn0031208:1     0  0.00000
## 2      chr2L       8193     9484      1  FBgn0031208:3     1 12.06419
## 3      chr2L       8193     8589      1  FBgn0031208:2     0  0.00000
## 4      chr2L       8668     9484      1  FBgn0031208:5     1 19.08685
## 5      chr2L       8229     9484      1  FBgn0031208:4     1 12.41025
## 6      chr2L      21136    21376     -1 FBgn0002121:17     0  0.00000
```

```
