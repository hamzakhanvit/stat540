# Seminar03
hamzakhanvit  
Saturday, January 24, 2015  


```r
kDat <- readRDS("GSE4051_MINI.rds")
str(kDat)
```

```
## 'data.frame':	39 obs. of  7 variables:
##  $ sidChar   : chr  "Sample_20" "Sample_21" "Sample_22" "Sample_23" ...
##  $ sidNum    : num  20 21 22 23 16 17 6 24 25 26 ...
##  $ devStage  : Factor w/ 5 levels "E16","P2","P6",..: 1 1 1 1 1 1 1 2 2 2 ...
##  $ gType     : Factor w/ 2 levels "wt","NrlKO": 1 1 1 1 2 2 2 1 1 1 ...
##  $ crabHammer: num  10.22 10.02 9.64 9.65 8.58 ...
##  $ eggBomb   : num  7.46 6.89 6.72 6.53 6.47 ...
##  $ poisonFang: num  7.37 7.18 7.35 7.04 7.49 ...
```

```r
table(kDat$devStage)
```

```
## 
##     E16      P2      P6     P10 4_weeks 
##       7       8       8       8       8
```

```r
table(kDat$gType)
```

```
## 
##    wt NrlKO 
##    20    19
```

```r
with(kDat, table(devStage, gType))
```

```
##          gType
## devStage  wt NrlKO
##   E16      4     3
##   P2       4     4
##   P6       4     4
##   P10      4     4
##   4_weeks  4     4
```
TAKE HOME PROBLEM - 
The full photoRec dataset has 39 samples and 29,949 random_probesets. Choose 2 . or 20 . or 200 random random_probesets/genes and look for gene expression differences between the two genotypes, wild type versus knockout. Make use of the graphing techniques discussed this week such as scatter plots, box plot, etc. Share questions, success, failure on the Google group.

Setting up the data frame

Loading the files.

```r
prDat <- read.table("GSE4051_data.tsv.txt")
prDes <- readRDS("GSE4051_design.rds")

set.seed(88)
```

Select 20 random probes from the dataset

```r
prDat20 <- t(prDat[sample(1:nrow(prDat), size = 20), ])
```

```r
random_probes <- colnames(prDat20)
```
Making a table out of the data

```r
prTable<- cbind(prDes, prDat20)
```

Dataframe construction

```r
dfDat <- with(prTable,
             data.frame(sidChar, sidNum, devStage, gType,
                        random_probeset = factor(rep(random_probes, each = nrow(prTable))),
                        geneExp = unlist(prTable[, random_probes])
                        )
             )
```
Using ggplot2


```r
library(ggplot2)
```

Constructing Striplot

```r
# Expression level of gene
(p <- ggplot(dfDat, aes(geneExp, random_probeset, color = gType)) + 
   geom_point(position = position_jitter(height = 0.1)))
```

![](seminar03_files/figure-html/unnamed-chunk-8-1.png) 

Plot the gene expression changes over the course of development,
showing different genes in separate panels,
and the averages with stat_summary at the bottom.

```r
(p <- ggplot(dfDat, aes(devStage, geneExp)) +
   geom_point() +
   facet_wrap(~random_probeset) +
   aes(color = gType) +
   stat_summary(fun.y = mean, geom = "point", shape = 4, size = 4))
```

![](seminar03_files/figure-html/unnamed-chunk-9-1.png) 

```r
#A Density plot based on developmental stage.

ggplot(dfDat, aes(geneExp, color = devStage)) + 
       stat_density(geom = "line", position = "identity") + 
       geom_point(aes(y = 0.05), position = position_jitter(height = 0.005))
```

![](seminar03_files/figure-html/unnamed-chunk-9-2.png) 

```r
# Density plot of geneExp by Devstage

p <- ggplot(dfDat, aes(geneExp, colour = devStage)) + 
   stat_density(geom = "line", position = "identity", adjust = 0.5) + 
   geom_point(aes(y = 0.05), 
              position = position_jitter(height = 0.01))
p + facet_wrap(~ devStage) +
  ggtitle("Density plot of geneExp by stage")
```

![](seminar03_files/figure-html/unnamed-chunk-9-3.png) 

###Box plot

```r
(p <- ggplot(dfDat, aes(devStage, geneExp)) + geom_boxplot() +
   facet_wrap(~gType))
```

![](seminar03_files/figure-html/unnamed-chunk-10-1.png) 

###Violin plot

```r
(p <- ggplot(dfDat, aes(devStage, geneExp)) + geom_violin() +
   facet_wrap(~gType))
```

![](seminar03_files/figure-html/unnamed-chunk-11-1.png) 

HeatMap for 20 random probesets

```r
library(RColorBrewer)
 
# set seed so that we have exactly reproducable results
set.seed(1)
 
# choose 50 probes out of the 30k to work with
yo <- sample(1:nrow(prDat), size = 20)
hDat <- prDat[yo, ]
colnames(hDat) <- with(prDes, paste(devStage, gType, sidChar, sep = "_"))
 
# transform the data to tall format
prDatTall <- data.frame(sample = rep(colnames(hDat), each = nrow(hDat)),
                        probe = rownames(hDat),
                        expression = unlist(hDat))
 
# create a blue -> purple palette
jBuPuFun <- colorRampPalette(brewer.pal(n = 9, "BuPu"))
paletteSize <- 256
jBuPuPalette <- jBuPuFun(paletteSize)
 
# heatmap!
ggplot(prDatTall, aes(x = probe, y = sample, fill = expression)) +
  theme(axis.text.x = element_text(angle = 90, hjust = 1, vjust = 0.5)) +
  geom_tile() +
  scale_fill_gradient2(low = jBuPuPalette[1],
                       mid = jBuPuPalette[paletteSize/2],
                       high = jBuPuPalette[paletteSize],
                       midpoint = (max(prDatTall$expression) +
                                     min(prDatTall$expression)) / 2,
                       name = "Expression")
```

![](seminar03_files/figure-html/unnamed-chunk-12-1.png) 



##Plotting with lattice


```r
library(lattice)
```

###Stripplot

Plotting the expression level of each gene w


```r
stripplot(random_probeset ~ geneExp, dfDat, groups = gType, jitter.data = TRUE)
```

![](seminar03_files/figure-html/unnamed-chunk-14-1.png) 

###Density plot

```r
densityplot(~ geneExp, dfDat,
            groups = gType, auto.key = TRUE)
```

![](seminar03_files/figure-html/unnamed-chunk-15-1.png) 

###Box plot

```r
bwplot(geneExp ~ devStage | gType, dfDat)
```

![](seminar03_files/figure-html/unnamed-chunk-16-1.png) 

###Violin plot

```r
bwplot(geneExp ~ devStage, dfDat,
       panel = panel.violin)
```

![](seminar03_files/figure-html/unnamed-chunk-17-1.png) 

###Pairwise scatterplots for 5 samples.


```r
library(GGally)
set.seed(88)
pairs <- sample(1:ncol(prDat), 5)
pairDat <- prDat[,pairs]
ggpairs(pairDat, alpha = 0.1)
```

![](seminar03_files/figure-html/unnamed-chunk-18-1.png) 
