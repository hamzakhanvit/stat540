﻿# seminar006
hamzakhanvit  
Friday, February 13, 2015  


```r
library(limma)
library(lattice)
library(ggplot2)
source("C:/Users/HAMZA/Desktop/stat540/utilities.r")

prDat <- read.table("GSE4051_data.tsv.txt")
str(prDat, max.level = 0)
```

```
## 'data.frame':	29949 obs. of  39 variables:
```

```r
prDes <- readRDS("GSE4051_design.rds")
str(prDes)
```

```
## 'data.frame':	39 obs. of  4 variables:
##  $ sidChar : chr  "Sample_20" "Sample_21" "Sample_22" "Sample_23" ...
##  $ sidNum  : num  20 21 22 23 16 17 6 24 25 26 ...
##  $ devStage: Factor w/ 5 levels "E16","P2","P6",..: 1 1 1 1 1 1 1 2 2 2 ...
##  $ gType   : Factor w/ 2 levels "wt","NrlKO": 1 1 1 1 2 2 2 1 1 1 ...
```

```r
#simulating data for 1000 genes. For each gene, we get 3 observations from a normal distribution with mean 0 and variance 1.
m <- 1000
n <- 3
x <- matrix(rnorm(m * n), nrow = m)
head(x)
```

```
##            [,1]         [,2]       [,3]
## [1,] -0.3000190  0.754789278 -0.0765618
## [2,] -1.5758257  0.983128013  0.3742530
## [3,]  1.5383983  0.490767187  0.4431288
## [4,]  0.8046821  0.002908675 -0.4317136
## [5,] -0.8362274  0.002556233 -0.1283018
## [6,]  2.0011307 -0.130594529  1.5754291
```

```r
#observed gene-wise variances
obsVars <- apply(x, 1, var)
summary(obsVars)
```

```
##     Min.  1st Qu.   Median     Mean  3rd Qu.     Max. 
## 0.000542 0.282200 0.698500 1.013000 1.373000 7.888000
```

```r
densityplot(~ obsVars, n = 200)
```

![](seminar006_files/figure-html/unnamed-chunk-1-1.png) 

###Fitting a linear model: gene expression in the wild type mice as a function of developmental stage (one-way ANOVA)


```r
wtDes <- subset(prDes, gType == "wt")
str(wtDes)
```

```
## 'data.frame':	20 obs. of  4 variables:
##  $ sidChar : chr  "Sample_20" "Sample_21" "Sample_22" "Sample_23" ...
##  $ sidNum  : num  20 21 22 23 24 25 26 27 28 29 ...
##  $ devStage: Factor w/ 5 levels "E16","P2","P6",..: 1 1 1 1 2 2 2 2 3 3 ...
##  $ gType   : Factor w/ 2 levels "wt","NrlKO": 1 1 1 1 1 1 1 1 1 1 ...
```

```r
wtDat <- subset(prDat, select = prDes$gType == "wt")
str(wtDat, max.level = 0)
```

```
## 'data.frame':	29949 obs. of  20 variables:
```

```r
wtDesMat <- model.matrix(~ devStage, wtDes)
str(wtDesMat)
```

```
##  num [1:20, 1:5] 1 1 1 1 1 1 1 1 1 1 ...
##  - attr(*, "dimnames")=List of 2
##   ..$ : chr [1:20] "12" "13" "14" "15" ...
##   ..$ : chr [1:5] "(Intercept)" "devStageP2" "devStageP6" "devStageP10" ...
##  - attr(*, "assign")= int [1:5] 0 1 1 1 1
##  - attr(*, "contrasts")=List of 1
##   ..$ devStage: chr "contr.treatment"
```

```r
wtFit <- lmFit(wtDat, wtDesMat)
wtEbFit <- eBayes(wtFit)
topTable(wtEbFit)
```

```
## Removing intercept from test coefficients
```

```
##              devStageP2 devStageP6 devStageP10 devStage4_weeks AveExpr
## 1440645_at      0.39900    0.19525     0.92000         3.96125 6.52835
## 1416041_at      0.15800    0.47975     0.33275         5.11450 9.38250
## 1425222_x_at    0.88200    0.79950     1.54875         5.53175 7.02815
## 1451635_at      1.30250    1.19000     2.01600         6.18825 8.31860
## 1429028_at     -2.44325   -3.40725    -4.31050        -4.60175 8.04495
## 1422929_s_at   -2.91175   -3.61825    -3.54725        -3.66125 7.27830
## 1424852_at      0.45750    0.22975     0.57400         3.97900 7.45405
## 1425171_at      0.99800    3.05300     5.27875         6.07875 9.62045
## 1451617_at      0.72550    2.51275     4.98375         6.68475 8.81660
## 1451618_at      0.60275    2.89025     5.05075         6.28825 9.43065
##                     F      P.Value    adj.P.Val
## 1440645_at   425.4464 1.587779e-17 4.755241e-13
## 1416041_at   195.4574 1.522363e-14 2.279662e-10
## 1425222_x_at 173.3572 4.348283e-14 4.340891e-10
## 1451635_at   157.3341 1.013031e-13 7.584816e-10
## 1429028_at   148.7971 1.645967e-13 9.202951e-10
## 1422929_s_at 146.8672 1.843725e-13 9.202951e-10
## 1424852_at   143.2443 2.290408e-13 9.799345e-10
## 1425171_at   138.8483 3.001762e-13 1.123747e-09
## 1451617_at   136.4774 3.485203e-13 1.159759e-09
## 1451618_at   134.2025 4.031647e-13 1.207438e-09
```

```r
head(coef(wtEbFit))
```

```
##              (Intercept) devStageP2 devStageP6 devStageP10 devStage4_weeks
## 1415670_at       7.22225   -0.04825    0.16975    -0.09275        -0.02475
## 1415671_at       9.87050   -0.61300   -0.66300    -0.73400        -0.81775
## 1415672_at       9.96750   -0.38175    0.03175    -0.32000        -0.53475
## 1415673_at       8.40675   -0.00025   -0.04175     0.00600         0.19000
## 1415674_a_at     8.59025   -0.16950   -0.05600    -0.12325        -0.26575
## 1415675_at       9.67975    0.02875   -0.05125    -0.13675        -0.18050
```

```r
topTable(wtEbFit, coef = 1:5)
```

```
##              X.Intercept. devStageP2 devStageP6 devStageP10
## 1423641_s_at      12.1800    -0.0175     0.0750      0.0675
## 1438940_x_at      12.8625     0.0850     0.1325      0.3425
## 1438657_x_at      12.7825     0.1400     0.1250     -0.1850
## 1456736_x_at      12.3225     0.1625     0.3050      0.2075
## 1436884_x_at      12.9275     0.1775     0.3225      0.0300
## 1419700_a_at      12.3200     0.1650     0.6475      0.8175
## 1435800_a_at      12.2850     0.0450     0.6825      0.9000
## 1454613_at        12.4675    -0.1075    -0.0500     -0.1025
## 1451240_a_at      12.9975     0.3100     0.2800      0.2800
## 1450084_s_at      12.6350     0.0825     0.0525      0.1725
##              devStage4_weeks AveExpr        F      P.Value    adj.P.Val
## 1423641_s_at          0.1800 12.2410 45349.98 3.573822e-36 5.201351e-32
## 1438940_x_at          0.3500 13.0445 44956.74 3.864588e-36 5.201351e-32
## 1438657_x_at         -0.4500 12.7085 43485.87 5.210208e-36 5.201351e-32
## 1456736_x_at          0.0725 12.4720 39508.56 1.233083e-35 6.725010e-32
## 1436884_x_at          0.0250 13.0385 39269.42 1.302189e-35 6.725010e-32
## 1419700_a_at          0.6825 12.7825 39120.82 1.347292e-35 6.725010e-32
## 1435800_a_at          1.0200 12.8145 36668.31 2.409850e-35 1.031037e-31
## 1454613_at           -0.3825 12.3390 35835.07 2.962415e-35 1.077791e-31
## 1451240_a_at         -0.3700 13.0975 35480.84 3.238879e-35 1.077791e-31
## 1450084_s_at          0.2600 12.7485 34410.51 4.264522e-35 1.234197e-31
```

```r
#topTable for selected devStages
colnames(coef(wtEbFit)) 
```

```
## [1] "(Intercept)"     "devStageP2"      "devStageP6"      "devStageP10"    
## [5] "devStage4_weeks"
```

```r
(dsHits <- topTable(wtEbFit,
                    coef = grep("devStage", colnames(coef(wtEbFit)))))
```

```
##              devStageP2 devStageP6 devStageP10 devStage4_weeks AveExpr
## 1440645_at      0.39900    0.19525     0.92000         3.96125 6.52835
## 1416041_at      0.15800    0.47975     0.33275         5.11450 9.38250
## 1425222_x_at    0.88200    0.79950     1.54875         5.53175 7.02815
## 1451635_at      1.30250    1.19000     2.01600         6.18825 8.31860
## 1429028_at     -2.44325   -3.40725    -4.31050        -4.60175 8.04495
## 1422929_s_at   -2.91175   -3.61825    -3.54725        -3.66125 7.27830
## 1424852_at      0.45750    0.22975     0.57400         3.97900 7.45405
## 1425171_at      0.99800    3.05300     5.27875         6.07875 9.62045
## 1451617_at      0.72550    2.51275     4.98375         6.68475 8.81660
## 1451618_at      0.60275    2.89025     5.05075         6.28825 9.43065
##                     F      P.Value    adj.P.Val
## 1440645_at   425.4464 1.587779e-17 4.755241e-13
## 1416041_at   195.4574 1.522363e-14 2.279662e-10
## 1425222_x_at 173.3572 4.348283e-14 4.340891e-10
## 1451635_at   157.3341 1.013031e-13 7.584816e-10
## 1429028_at   148.7971 1.645967e-13 9.202951e-10
## 1422929_s_at 146.8672 1.843725e-13 9.202951e-10
## 1424852_at   143.2443 2.290408e-13 9.799345e-10
## 1425171_at   138.8483 3.001762e-13 1.123747e-09
## 1451617_at   136.4774 3.485203e-13 1.159759e-09
## 1451618_at   134.2025 4.031647e-13 1.207438e-09
```

```r
#plot for hits 3, 6, and 9 on the list.
mystripplot(tempfunc(rownames(dsHits)[c(3, 6, 9)]))
```

![](seminar006_files/figure-html/unnamed-chunk-2-1.png) 



####How many probes have Benjamini-Hochberg ("BH") adjusted p-values for the F test conducted above that are less than 1e-05?


```r
count <- topTable(wtEbFit, coef = grep("devStage", colnames(coef(wtEbFit))),
                   p.value = 1e-05, n = Inf)
(number <- nrow(count))
```

```
## [1] 350
```
Answer : 350 probes.


####What is the 63rd hit on this list? Provide itâs Affy ID, F statistic, BH adjusted p-value, and the estimated effect for developmental stage P6 in that order.

```r
count[63, c("F", "adj.P.Val", "devStageP6")]
```

```
##                    F    adj.P.Val devStageP6
## 1451633_a_at 64.0104 1.048908e-07      2.069
```

####Consider the effects associated with developmental stages P2 and P10. Scatterplot the t statistics for the test that the P2 effect is zero against that for P10. Ideally this plot would be a high-volume scatterplot, include an x = y line, and have an aspect ratio of 1 and common axes, but just do your best. 

```r
#head(wtEbFit)

P2_t <- topTable(wtEbFit, coef = "devStageP2", n = Inf, sort = "none")
P10_t <- topTable(wtEbFit, coef = "devStageP10", n = Inf, sort = "none")

xyplot(P10_t$t ~ P2_t$t, 
       xlab = " P2 t-stats",
       ylab = "P10 t-stats",
       xlim = c(-20, 16), ylim = c(-20, 16),
       panel = function(x, y, ...){
       panel.smoothScatter(x, y, ...)
       panel.abline(a = 0, b = 1)
       })
```

```
## (loaded the KernSmooth namespace)
```

![](seminar006_files/figure-html/unnamed-chunk-5-1.png) 

```r
#A densityplot of the associated adjusted p-value
densityplot(~ P10_t$adj.P.Val + P2_t$adj.P.Val)
```

![](seminar006_files/figure-html/unnamed-chunk-5-2.png) 

```r
tab = table(P2 = P2_t$adj.P.Val < 1e-03,
                  P10 = P10_t$adj.P.Val < 1e-03)
addmargins(tab)
```

```
##        P10
## P2      FALSE  TRUE   Sum
##   FALSE 29201   695 29896
##   TRUE      1    52    53
##   Sum   29202   747 29949
```
With p-value less than 1e-03, P2 = 53 hits, P10 = 747 hits, overlap = 52 hits.


A scatterplot matrix of raw p-values, BH adjusted p-values, and BY p-values for P10.

```r
P10effect <- data.frame(raw = P10_t$P.Value,
                       BH = P10_t$adj.P.Val,
                       BY = p.adjust(P10_t$P.Value, method = "BY"))
splom(P10effect,
      panel = function(x, y, ... ) {
          panel.xyplot(x, y, pch = ".", ...)
          panel.abline(a = 0, b = 1, col = "red")
      })
```

![](seminar006_files/figure-html/unnamed-chunk-6-1.png) 
Performing Inference for some contrasts

```r
colnames(wtDesMat)
```

```
## [1] "(Intercept)"     "devStageP2"      "devStageP6"      "devStageP10"    
## [5] "devStage4_weeks"
```

```r
(cont.matrix <- makeContrasts(
    P10VsP6 = devStageP10 - devStageP6,
    fourweeksVsP10 = devStage4_weeks - devStageP10,
    levels = wtDesMat))
```

```
## Warning in makeContrasts(P10VsP6 = devStageP10 - devStageP6,
## fourweeksVsP10 = devStage4_weeks - : Renaming (Intercept) to Intercept
```

```
##                  Contrasts
## Levels            P10VsP6 fourweeksVsP10
##   Intercept             0              0
##   devStageP2            0              0
##   devStageP6           -1              0
##   devStageP10           1             -1
##   devStage4_weeks       0              1
```

```r
wtFitCont <- contrasts.fit(wtFit, cont.matrix)
```

```
## Warning in contrasts.fit(wtFit, cont.matrix): row names of contrasts don't
## match col names of coefficients
```

```r
wtEbFitCont <- eBayes(wtFitCont)

#Lets see the top hits with toptable and plot first two hits
(tophits <- topTable(wtEbFitCont))
```

```
##               P10VsP6 fourweeksVsP10 AveExpr        F      P.Value
## 1440645_at    0.72475        3.04125 6.52835 632.7410 2.224325e-17
## 1416041_at   -0.14700        4.78175 9.38250 302.3940 1.472973e-14
## 1425222_x_at  0.74925        3.98300 7.02815 235.3682 1.299509e-13
## 1424852_at    0.34425        3.40500 7.45405 225.1087 1.910320e-13
## 1420726_x_at  0.17325        3.55125 7.19000 203.5215 4.555385e-13
## 1451635_at    0.82600        4.17225 8.31860 200.0177 5.289072e-13
## 1429394_at   -0.09800        2.40975 7.84825 167.4991 2.416043e-12
## 1455447_at   -0.97650       -1.79975 9.97295 153.5444 5.063369e-12
## 1429791_at    0.24800        1.65825 8.02555 145.7407 7.877494e-12
## 1422612_at    0.48375        3.42600 8.83255 142.2388 9.676005e-12
##                 adj.P.Val
## 1440645_at   6.661631e-13
## 1416041_at   2.205703e-10
## 1425222_x_at 1.297300e-09
## 1424852_at   1.430304e-09
## 1420726_x_at 2.640040e-09
## 1451635_at   2.640040e-09
## 1429394_at   1.033687e-08
## 1455447_at   1.895536e-08
## 1429791_at   2.621367e-08
## 1422612_at   2.840295e-08
```

```r
mystripplot(tempfunc(rownames(tophits)[1:2]))
```

![](seminar006_files/figure-html/unnamed-chunk-7-1.png) 

```r
# shows little expression change from P6 to P10 and a strong increase from P10 to 4_weeks.


#Using decideTests
cutoff <- 1e-04
wtResCont <- decideTests(wtEbFitCont, p.value = cutoff, method = "global")
summary(wtResCont)
```

```
##    P10VsP6 fourweeksVsP10
## -1       4              8
## 0    29945          29895
## 1        0             46
```

```r
# 4 probes that go down from P6 to P10 and no hits going the other way. 8 probes that go down from P10 to 4_weeks and 46 going the other way. 

#These 4 hits for P6--->P10 are -
(hits1 <- rownames(prDat)[which(wtResCont[, "P10VsP6"] < 0)])
```

```
## [1] "1416635_at" "1437781_at" "1454752_at" "1455260_at"
```

```r
mystripplot(tempfunc(hits1))
```

![](seminar006_files/figure-html/unnamed-chunk-7-2.png) 

```r
#8 that decline from P10 to 4_weeks are -
(hits2 <- rownames(prDat)[which(wtResCont[, "fourweeksVsP10"] < 0)])
```

```
## [1] "1416021_a_at" "1423851_a_at" "1434500_at"   "1435415_x_at"
## [5] "1437502_x_at" "1448182_a_at" "1452679_at"   "1455447_at"
```

```r
# 46 that increase from P10 to 4_weeks.
(hits3 <- rownames(prDat)[which(wtResCont[, "fourweeksVsP10"] > 0)])
```

```
##  [1] "1416041_at"   "1417280_at"   "1418406_at"   "1418710_at"  
##  [5] "1418789_at"   "1419069_at"   "1420725_at"   "1420726_x_at"
##  [9] "1421061_at"   "1421818_at"   "1422612_at"   "1424852_at"  
## [13] "1424895_at"   "1425222_x_at" "1426059_at"   "1426223_at"  
## [17] "1427388_at"   "1428763_at"   "1429394_at"   "1429791_at"  
## [21] "1430580_at"   "1431174_at"   "1433699_at"   "1434297_at"  
## [25] "1434573_at"   "1435436_at"   "1435679_at"   "1435727_s_at"
## [29] "1436265_at"   "1436287_at"   "1440402_at"   "1440645_at"  
## [33] "1441518_at"   "1442243_at"   "1443252_at"   "1446484_at"  
## [37] "1449170_at"   "1449393_at"   "1451042_a_at" "1451635_at"  
## [41] "1452243_at"   "1453385_at"   "1455493_at"   "1457878_at"  
## [45] "1458418_at"   "1459904_at"
```

```r
#Venn diagram
vennDiagram(wtResCont)
```

![](seminar006_files/figure-html/unnamed-chunk-7-3.png) 

#TAKE HOME PROBLEM

Q1.See if you can find one or more probes that have some expression changes up to P6 and then hold steady all the way to 4_weeks. Plot the probes in your finding. Here's some I found.

```r
#So our Design marix looks like this
wtDesMat
```

```
##    (Intercept) devStageP2 devStageP6 devStageP10 devStage4_weeks
## 12           1          0          0           0               0
## 13           1          0          0           0               0
## 14           1          0          0           0               0
## 15           1          0          0           0               0
## 28           1          1          0           0               0
## 29           1          1          0           0               0
## 30           1          1          0           0               0
## 31           1          1          0           0               0
## 36           1          0          1           0               0
## 37           1          0          1           0               0
## 38           1          0          1           0               0
## 39           1          0          1           0               0
## 20           1          0          0           1               0
## 21           1          0          0           1               0
## 22           1          0          0           1               0
## 23           1          0          0           1               0
## 5            1          0          0           0               1
## 6            1          0          0           0               1
## 7            1          0          0           0               1
## 8            1          0          0           0               1
## attr(,"assign")
## [1] 0 1 1 1 1
## attr(,"contrasts")
## attr(,"contrasts")$devStage
## [1] "contr.treatment"
```

```r
cont.mat <- makeContrasts(P2VsE16 = devStageP2 - Intercept, P6VsP2 = devStageP6 - devStageP2,P10VsP6 = devStageP10 - devStageP6,fourweeksVsP10 = devStage4_weeks - devStageP10,levels = wtDesMat)
```

```
## Warning in makeContrasts(P2VsE16 = devStageP2 - Intercept, P6VsP2 =
## devStageP6 - : Renaming (Intercept) to Intercept
```

```r
Fitmodel <- lmFit(wtDat, wtDesMat)
ContFit <- contrasts.fit(Fitmodel, cont.mat)
```

```
## Warning in contrasts.fit(Fitmodel, cont.mat): row names of contrasts don't
## match col names of coefficients
```

```r
ebFit <- eBayes(ContFit)

#Taking p-value < 1e-4

results_cont <- decideTests(ebFit, p.value = 1e-04, method = "global")
summary(results_cont)
```

```
##    P2VsE16 P6VsP2 P10VsP6 fourweeksVsP10
## -1   29903      0      32             37
## 0       46  29937   29907          29712
## 1        0     12      10            200
```

```r
vennDiagram(results_cont)
```

![](seminar006_files/figure-html/unnamed-chunk-8-1.png) 

```r
# Listing the genes where expression remains constant after P10.

(gene_hits <- rownames(prDat)[which(results_cont[, "P2VsE16"] != 0 &
                                     results_cont[, "P6VsP2"] != 0 &
                                     results_cont[, "P10VsP6"] == 0 &
                                     results_cont[, "fourweeksVsP10"] == 0)])
```

```
##  [1] "1419740_at"   "1421084_at"   "1424963_at"   "1425530_a_at"
##  [5] "1428288_at"   "1433590_at"   "1435661_at"   "1435800_a_at"
##  [9] "1445574_at"   "1450723_at"
```

```r
#Stripplot all the hits
mystripplot(tempfunc(gene_hits))
```

![](seminar006_files/figure-html/unnamed-chunk-8-2.png) 
Q2.Repeat (1) for the genotype NrlKO. Compare the hits between the wt and NrlKO. Are there any common genes shared by these 2 groups of hits, what does the result suggest in terms of the effect of genotype?


```r
koDes <- subset(prDes, gType == "NrlKO")
koDat <- subset(prDat, select = prDes$gType == "NrlKO")
(NrlkoDesMat <- model.matrix(~devStage, koDes))
```

```
##    (Intercept) devStageP2 devStageP6 devStageP10 devStage4_weeks
## 9            1          0          0           0               0
## 10           1          0          0           0               0
## 11           1          0          0           0               0
## 24           1          1          0           0               0
## 25           1          1          0           0               0
## 26           1          1          0           0               0
## 27           1          1          0           0               0
## 32           1          0          1           0               0
## 33           1          0          1           0               0
## 34           1          0          1           0               0
## 35           1          0          1           0               0
## 16           1          0          0           1               0
## 17           1          0          0           1               0
## 18           1          0          0           1               0
## 19           1          0          0           1               0
## 1            1          0          0           0               1
## 2            1          0          0           0               1
## 3            1          0          0           0               1
## 4            1          0          0           0               1
## attr(,"assign")
## [1] 0 1 1 1 1
## attr(,"contrasts")
## attr(,"contrasts")$devStage
## [1] "contr.treatment"
```

```r
#Fit the model

koFit <- lmFit(koDat, NrlkoDesMat)
koEbFit <- eBayes(koFit)
#Construct the contrast matrix
cont.matrix <- makeContrasts(P2VsE16 = devStageP2 - Intercept, 
                             P6VsP2 = devStageP6 - devStageP2, 
                             P10VsP6 = devStageP10 - devStageP6, 
                             fourweeksVsP10 = devStage4_weeks - devStageP10, 
                             levels = NrlkoDesMat)
```

```
## Warning in makeContrasts(P2VsE16 = devStageP2 - Intercept, P6VsP2 =
## devStageP6 - : Renaming (Intercept) to Intercept
```

```r
NrlkoFitCont <- contrasts.fit(koFit, cont.matrix)
```

```
## Warning in contrasts.fit(koFit, cont.matrix): row names of contrasts don't
## match col names of coefficients
```

```r
NrlkoEbFitCont <- eBayes(NrlkoFitCont)

results_cont2 <- decideTests(NrlkoEbFitCont, p.value = 1e-04, method = "global")
summary(results_cont2)
```

```
##    P2VsE16 P6VsP2 P10VsP6 fourweeksVsP10
## -1   29939      6      53             26
## 0       10  29888   29809          29830
## 1        0     55      87             93
```

```r
#These are the gene hits for this - 
(gene_hits2 <- rownames(prDat)[which(results_cont2[, "P2VsE16"] != 0 &
                                     results_cont2[, "P6VsP2"] != 0 &
                                     results_cont2[, "P10VsP6"] == 0 &
                                     results_cont2[, "fourweeksVsP10"] == 0)])
```

```
##  [1] "1416085_s_at" "1417089_a_at" "1418304_at"   "1418714_at"  
##  [5] "1419025_at"   "1419085_at"   "1420925_at"   "1421084_at"  
##  [9] "1421840_at"   "1424118_a_at" "1425100_a_at" "1425167_a_at"
## [13] "1425219_x_at" "1425506_at"   "1428288_at"   "1428289_at"  
## [17] "1428763_at"   "1434866_x_at" "1435038_s_at" "1435392_at"  
## [21] "1435579_at"   "1436335_at"   "1437393_at"   "1437458_x_at"
## [25] "1438068_at"   "1438156_x_at" "1438443_at"   "1440256_at"  
## [29] "1440838_at"   "1444095_a_at" "1444150_at"   "1444696_at"  
## [33] "1445716_at"   "1449421_a_at" "1450723_at"   "1451590_at"  
## [37] "1451603_at"   "1451633_a_at" "1451636_at"   "1451674_at"  
## [41] "1452358_at"   "1452879_at"   "1454086_a_at" "1454608_x_at"
## [45] "1455893_at"   "1456341_a_at" "1457254_x_at" "1457622_at"  
## [49] "1458386_at"   "1460101_at"   "1460214_at"   "1460324_at"  
## [53] "1460409_at"
```

```r
#Stripplot all the hits
mystripplot(tempfunc(gene_hits2[1:5]))
```

![](seminar006_files/figure-html/unnamed-chunk-9-1.png) 

```r
#Intersecting hits:
(intersect(gene_hits, gene_hits2))
```

```
## [1] "1421084_at" "1428288_at" "1450723_at"
```
The knockout doesn't have any effect for these intersecting genes.
