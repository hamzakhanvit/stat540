# seminar00c
hamzakhanvit  
Friday, January 21, 2015  



```r
#Check the current working directory
getwd()
```

```
## [1] "C:/Users/HAMZA/Desktop/zz_khan-hamza_STAT540_2015"
```

```r
#Cleaning Workspace
rm(list = ls())

#Reading the gapminder file
gDat <- read.delim("gapminderDataFiveYear.txt")

#Display the structure of the object
str(gDat)
```

```
## 'data.frame':	1704 obs. of  6 variables:
##  $ country  : Factor w/ 142 levels "Afghanistan",..: 1 1 1 1 1 1 1 1 1 1 ...
##  $ year     : int  1952 1957 1962 1967 1972 1977 1982 1987 1992 1997 ...
##  $ pop      : num  8425333 9240934 10267083 11537966 13079460 ...
##  $ continent: Factor w/ 5 levels "Africa","Americas",..: 3 3 3 3 3 3 3 3 3 3 ...
##  $ lifeExp  : num  28.8 30.3 32 34 36.1 ...
##  $ gdpPercap: num  779 821 853 836 740 ...
```

```r
#Display the first bit of the file
head(gDat)
```

```
##       country year      pop continent lifeExp gdpPercap
## 1 Afghanistan 1952  8425333      Asia  28.801  779.4453
## 2 Afghanistan 1957  9240934      Asia  30.332  820.8530
## 3 Afghanistan 1962 10267083      Asia  31.997  853.1007
## 4 Afghanistan 1967 11537966      Asia  34.020  836.1971
## 5 Afghanistan 1972 13079460      Asia  36.088  739.9811
## 6 Afghanistan 1977 14880372      Asia  38.438  786.1134
```

```r
#Display the last bit of the file
tail(gDat)
```

```
##       country year      pop continent lifeExp gdpPercap
## 1699 Zimbabwe 1982  7636524    Africa  60.363  788.8550
## 1700 Zimbabwe 1987  9216418    Africa  62.351  706.1573
## 1701 Zimbabwe 1992 10704340    Africa  60.377  693.4208
## 1702 Zimbabwe 1997 11404948    Africa  46.809  792.4500
## 1703 Zimbabwe 2002 11926563    Africa  39.989  672.0386
## 1704 Zimbabwe 2007 12311143    Africa  43.487  469.7093
```

```r
# Display variable or column names
names(gDat)
```

```
## [1] "country"   "year"      "pop"       "continent" "lifeExp"   "gdpPercap"
```

```r
ncol(gDat)
```

```
## [1] 6
```

```r
length(gDat)
```

```
## [1] 6
```

```r
head(rownames(gDat))
```

```
## [1] "1" "2" "3" "4" "5" "6"
```

```r
dim(gDat)
```

```
## [1] 1704    6
```

```r
nrow(gDat)
```

```
## [1] 1704
```

```r
#Displaying summary view
summary(gDat)
```

```
##         country          year           pop               continent  
##  Afghanistan:  12   Min.   :1952   Min.   :6.001e+04   Africa  :624  
##  Albania    :  12   1st Qu.:1966   1st Qu.:2.794e+06   Americas:300  
##  Algeria    :  12   Median :1980   Median :7.024e+06   Asia    :396  
##  Angola     :  12   Mean   :1980   Mean   :2.960e+07   Europe  :360  
##  Argentina  :  12   3rd Qu.:1993   3rd Qu.:1.959e+07   Oceania : 24  
##  Australia  :  12   Max.   :2007   Max.   :1.319e+09                 
##  (Other)    :1632                                                    
##     lifeExp        gdpPercap       
##  Min.   :23.60   Min.   :   241.2  
##  1st Qu.:48.20   1st Qu.:  1202.1  
##  Median :60.71   Median :  3531.8  
##  Mean   :59.47   Mean   :  7215.3  
##  3rd Qu.:70.85   3rd Qu.:  9325.5  
##  Max.   :82.60   Max.   :113523.1  
## 
```

```r
#A Simple plot lifeExp Vs year
plot(lifeExp ~ year, gDat)
```

![](seminar00c_files/figure-html/unnamed-chunk-1-1.png) 

```r
#A simple plot lifeExp Vs gdpPercap
plot(lifeExp ~ gdpPercap, gDat)
```

![](seminar00c_files/figure-html/unnamed-chunk-1-2.png) 

```r
#A Simple plot lifeExp Vs log(gdpPercap)
plot(lifeExp ~ log(gdpPercap), gDat)
```

![](seminar00c_files/figure-html/unnamed-chunk-1-3.png) 

```r
# Looking at the variables inside a data.frame
head(gDat$lifeExp)
```

```
## [1] 28.801 30.332 31.997 34.020 36.088 38.438
```

```r
summary(gDat$lifeExp)
```

```
##    Min. 1st Qu.  Median    Mean 3rd Qu.    Max. 
##   23.60   48.20   60.71   59.47   70.85   82.60
```

```r
#Drawing a Histogram
hist(gDat$lifeExp)
```

![](seminar00c_files/figure-html/unnamed-chunk-1-4.png) 

```r
#Factors and levels
class(gDat$continent)
```

```
## [1] "factor"
```

```r
summary(gDat$continent)
```

```
##   Africa Americas     Asia   Europe  Oceania 
##      624      300      396      360       24
```

```r
#Listing Levels in continent
levels(gDat$continent)
```

```
## [1] "Africa"   "Americas" "Asia"     "Europe"   "Oceania"
```

```r
#Number of levels in continent
nlevels(gDat$continent)
```

```
## [1] 5
```

```r
str(gDat$continent)
```

```
##  Factor w/ 5 levels "Africa","Americas",..: 3 3 3 3 3 3 3 3 3 3 ...
```

```r
#Displaying observations associated with continent
table(gDat$continent)
```

```
## 
##   Africa Americas     Asia   Europe  Oceania 
##      624      300      396      360       24
```

```r
barplot(table(gDat$continent))

#ggplot
library(ggplot2)
```

![](seminar00c_files/figure-html/unnamed-chunk-1-5.png) 

```r
p <- ggplot(subset(gDat, continent != "Oceania"),
            aes(x = gdpPercap, y = lifeExp)) # just initializes
p <- p + scale_x_log10() # log the x axis the right way
p + geom_point() # scatterplot
```

![](seminar00c_files/figure-html/unnamed-chunk-1-6.png) 

```r
p + geom_point(aes(color = continent)) # map continent to color
```

![](seminar00c_files/figure-html/unnamed-chunk-1-7.png) 

```r
p + geom_point(alpha = (1/3), size = 3) + geom_smooth(lwd = 3, se = FALSE)
```

```
## geom_smooth: method="auto" and size of largest group is >=1000, so using gam with formula: y ~ s(x, bs = "cs"). Use 'method = x' to change the smoothing method.
```

![](seminar00c_files/figure-html/unnamed-chunk-1-8.png) 

```r
## geom_smooth: method="auto" and size of largest group is >=1000, so using gam with formula: y ~ s(x, bs = "cs"). Use 'method = x' to change the smoothing method.
p + geom_point(alpha = (1/3), size = 3) + facet_wrap(~ continent)
```

![](seminar00c_files/figure-html/unnamed-chunk-1-9.png) 

```r
#Playing with subset
subset(gDat, subset = country == "Uruguay")
```

```
##      country year     pop continent lifeExp gdpPercap
## 1621 Uruguay 1952 2252965  Americas  66.071  5716.767
## 1622 Uruguay 1957 2424959  Americas  67.044  6150.773
## 1623 Uruguay 1962 2598466  Americas  68.253  5603.358
## 1624 Uruguay 1967 2748579  Americas  68.468  5444.620
## 1625 Uruguay 1972 2829526  Americas  68.673  5703.409
## 1626 Uruguay 1977 2873520  Americas  69.481  6504.340
## 1627 Uruguay 1982 2953997  Americas  70.805  6920.223
## 1628 Uruguay 1987 3045153  Americas  71.918  7452.399
## 1629 Uruguay 1992 3149262  Americas  72.752  8137.005
## 1630 Uruguay 1997 3262838  Americas  74.223  9230.241
## 1631 Uruguay 2002 3363085  Americas  75.307  7727.002
## 1632 Uruguay 2007 3447496  Americas  76.384 10611.463
```

```r
#Another method for a subset
gDat[1621:1632, ]
```

```
##      country year     pop continent lifeExp gdpPercap
## 1621 Uruguay 1952 2252965  Americas  66.071  5716.767
## 1622 Uruguay 1957 2424959  Americas  67.044  6150.773
## 1623 Uruguay 1962 2598466  Americas  68.253  5603.358
## 1624 Uruguay 1967 2748579  Americas  68.468  5444.620
## 1625 Uruguay 1972 2829526  Americas  68.673  5703.409
## 1626 Uruguay 1977 2873520  Americas  69.481  6504.340
## 1627 Uruguay 1982 2953997  Americas  70.805  6920.223
## 1628 Uruguay 1987 3045153  Americas  71.918  7452.399
## 1629 Uruguay 1992 3149262  Americas  72.752  8137.005
## 1630 Uruguay 1997 3262838  Americas  74.223  9230.241
## 1631 Uruguay 2002 3363085  Americas  75.307  7727.002
## 1632 Uruguay 2007 3447496  Americas  76.384 10611.463
```

```r
#Using subset = and select = together to simultaneously filter rows and columns or variables.
subset(gDat, subset = country == "Mexico",
       select = c(country, year, lifeExp))
```

```
##     country year lifeExp
## 985  Mexico 1952  50.789
## 986  Mexico 1957  55.190
## 987  Mexico 1962  58.299
## 988  Mexico 1967  60.110
## 989  Mexico 1972  62.361
## 990  Mexico 1977  65.032
## 991  Mexico 1982  67.405
## 992  Mexico 1987  69.498
## 993  Mexico 1992  71.455
## 994  Mexico 1997  73.670
## 995  Mexico 2002  74.902
## 996  Mexico 2007  76.195
```

```r
# An example of subsetting the data to make a plot just for Colombia and a similar call to lm for fitting a linear model to just the data from Colombia.
p <- ggplot(subset(gDat, country == "Colombia"), aes(x = year, y = lifeExp))
p + geom_point() + geom_smooth(lwd = 1, se = FALSE, method = "lm")
```

![](seminar00c_files/figure-html/unnamed-chunk-1-10.png) 

```r
(minYear <- min(gDat$year))
```

```
## [1] 1952
```

```r
myFit <- lm(lifeExp ~ I(year - minYear), gDat, subset = country == "Colombia")
summary(myFit)
```

```
## 
## Call:
## lm(formula = lifeExp ~ I(year - minYear), data = gDat, subset = country == 
##     "Colombia")
## 
## Residuals:
##     Min      1Q  Median      3Q     Max 
## -2.7841 -0.3816  0.1840  0.8413  1.8034 
## 
## Coefficients:
##                   Estimate Std. Error t value Pr(>|t|)    
## (Intercept)       53.42712    0.71223   75.01 4.33e-15 ***
## I(year - minYear)  0.38075    0.02194   17.36 8.54e-09 ***
## ---
## Signif. codes:  0 '***' 0.001 '**' 0.01 '*' 0.05 '.' 0.1 ' ' 1
## 
## Residual standard error: 1.312 on 10 degrees of freedom
## Multiple R-squared:  0.9679,	Adjusted R-squared:  0.9647 
## F-statistic: 301.3 on 1 and 10 DF,  p-value: 8.537e-09
```

```r
#Combining with() and subset()
with(subset(gDat, subset = country == "Colombia"),
     cor(lifeExp, gdpPercap))
```

```
## [1] 0.9514699
```
