# seminar04a
hamzakhanvit  
Thursday, January 29, 2015  


```r
library(lattice)
library(ggplot2)
library(plyr)

prDat <- read.table("GSE4051_data.tsv.txt")
str(prDat, max.level = 0)
```

```
## 'data.frame':	29949 obs. of  39 variables:
```

```r
prDes <- readRDS("GSE4051_design.rds")
str(prDes)
```

```
## 'data.frame':	39 obs. of  4 variables:
##  $ sidChar : chr  "Sample_20" "Sample_21" "Sample_22" "Sample_23" ...
##  $ sidNum  : num  20 21 22 23 16 17 6 24 25 26 ...
##  $ devStage: Factor w/ 5 levels "E16","P2","P6",..: 1 1 1 1 1 1 1 2 2 2 ...
##  $ gType   : Factor w/ 2 levels "wt","NrlKO": 1 1 1 1 2 2 2 1 1 1 ...
```

```r
#Two sample tests -one gene

#Extracting data for one gene
set.seed(987)
(theGene <- sample(1:nrow(prDat), 1))
```

```
## [1] 14294
```

```r
#placing it a data.frame
pDat <- data.frame(prDes, gExp = unlist(prDat[theGene, ]))
str(pDat)
```

```
## 'data.frame':	39 obs. of  5 variables:
##  $ sidChar : chr  "Sample_20" "Sample_21" "Sample_22" "Sample_23" ...
##  $ sidNum  : num  20 21 22 23 16 17 6 24 25 26 ...
##  $ devStage: Factor w/ 5 levels "E16","P2","P6",..: 1 1 1 1 1 1 1 2 2 2 ...
##  $ gType   : Factor w/ 2 levels "wt","NrlKO": 1 1 1 1 2 2 2 1 1 1 ...
##  $ gExp    : num  9.88 10.59 10.28 10.22 8.75 ...
```

```r
#Exploring a bit
aggregate(gExp ~ gType, pDat, FUN = mean)
```

```
##   gType     gExp
## 1    wt 9.758200
## 2 NrlKO 9.553105
```

```r
#Using plyr for the same
ddply(pDat, ~ gType, summarize, gExp = mean(gExp))
```

```
##   gType     gExp
## 1    wt 9.758200
## 2 NrlKO 9.553105
```

```r
#Sanity test with a stripplot using lattice
stripplot(gType ~ gExp, pDat)
```

![](seminar04a_files/figure-html/unnamed-chunk-1-1.png) 

```r
#same using ggplot
ggplot(pDat, aes(x = gExp, y = gType)) + geom_point()
```

![](seminar04a_files/figure-html/unnamed-chunk-1-2.png) 

```r
#Doing a two-sample t test and saving the results
ttRes <- t.test(gExp ~ gType, pDat)
str(ttRes)
```

```
## List of 9
##  $ statistic  : Named num 1.48
##   ..- attr(*, "names")= chr "t"
##  $ parameter  : Named num 36.8
##   ..- attr(*, "names")= chr "df"
##  $ p.value    : num 0.148
##  $ conf.int   : atomic [1:2] -0.0759 0.4861
##   ..- attr(*, "conf.level")= num 0.95
##  $ estimate   : Named num [1:2] 9.76 9.55
##   ..- attr(*, "names")= chr [1:2] "mean in group wt" "mean in group NrlKO"
##  $ null.value : Named num 0
##   ..- attr(*, "names")= chr "difference in means"
##  $ alternative: chr "two.sided"
##  $ method     : chr "Welch Two Sample t-test"
##  $ data.name  : chr "gExp by gType"
##  - attr(*, "class")= chr "htest"
```
***TRY YOURSELF***

```r
prDat <- read.table("GSE4051_data.tsv.txt")
prDes <- readRDS("GSE4051_design.rds")
onegene <- sample(1:nrow(prDat),1)
df <- data.frame(prDes, gExp=unlist(prDat[onegene, ]))
ttest <- t.test(gExp ~ gType, df)
ttest
```

```
## 
## 	Welch Two Sample t-test
## 
## data:  gExp by gType
## t = 0.4994, df = 36.987, p-value = 0.6205
## alternative hypothesis: true difference in means is not equal to 0
## 95 percent confidence interval:
##  -0.2284361  0.3778624
## sample estimates:
##    mean in group wt mean in group NrlKO 
##            6.862450            6.787737
```

```r
wtest <- wilcox.test(gExp ~ gType, df)
wtest
```

```
## 
## 	Wilcoxon rank sum test
## 
## data:  gExp by gType
## W = 210, p-value = 0.5877
## alternative hypothesis: true location shift is not equal to 0
```

```r
kttest <- ks.test(df[df$gType == "wt", "gExp"], df[df$gType == "NrlKO", "gExp"])
kttest
```

```
## 
## 	Two-sample Kolmogorov-Smirnov test
## 
## data:  df[df$gType == "wt", "gExp"] and df[df$gType == "NrlKO", "gExp"]
## D = 0.2158, p-value = 0.674
## alternative hypothesis: two-sided
```


***Learning the use of apply()***

```r
kDat <- readRDS("GSE4051_MINI.rds")
#Making a matrix
kMat <- as.matrix(kDat[c('crabHammer', 'eggBomb', 'poisonFang')])
str(kMat)
```

```
##  num [1:39, 1:3] 10.22 10.02 9.64 9.65 8.58 ...
##  - attr(*, "dimnames")=List of 2
##   ..$ : chr [1:39] "12" "13" "14" "15" ...
##   ..$ : chr [1:3] "crabHammer" "eggBomb" "poisonFang"
```

```r
#Computing means
median(kMat[ , 2])  #Second column's median
```

```
## [1] 6.757
```

```r
median(kMat[ , 'eggBomb']) # Using names
```

```
## [1] 6.757
```

```r
apply(kMat, 2, median) #Using apply();1=rows;2=columns
```

```
## crabHammer    eggBomb poisonFang 
##      9.611      6.757      7.350
```

```r
#Other Cool stuff to do with apply()
apply(kMat, 2, quantile, probs = 0.5)
```

```
## crabHammer    eggBomb poisonFang 
##      9.611      6.757      7.350
```

```r
apply(kMat, 2, quantile, probs = c(0.25, 0.75))
```

```
##     crabHammer eggBomb poisonFang
## 25%      8.938  6.2780     7.1885
## 75%      9.830  7.0945     7.4765
```

```r
#Minimum gene expression for each sample
apply(kMat, 1, min)
```

```
##    12    13    14    15     9    10    11    28    29    30    31    24 
## 7.370 6.890 6.720 6.529 6.470 7.005 6.735 6.587 6.170 6.870 6.800 6.138 
##    25    26    27    36    37    38    39    32    33    34    35    20 
## 6.166 6.269 6.264 6.530 7.100 6.269 6.211 6.286 6.347 6.270 6.188 7.005 
##    21    22    23    16    17    18    19     5     6     7     8     1 
## 7.082 6.757 6.155 7.228 7.226 7.363 7.081 6.993 6.992 6.608 7.003 6.981 
##     2     3     4 
## 7.165 7.075 6.558
```

```r
#name of these genes
colnames(kMat)[apply(kMat, 1, which.min)]
```

```
##  [1] "poisonFang" "eggBomb"    "eggBomb"    "eggBomb"    "eggBomb"   
##  [6] "poisonFang" "poisonFang" "eggBomb"    "eggBomb"    "eggBomb"   
## [11] "eggBomb"    "eggBomb"    "eggBomb"    "eggBomb"    "eggBomb"   
## [16] "eggBomb"    "poisonFang" "eggBomb"    "eggBomb"    "eggBomb"   
## [21] "eggBomb"    "eggBomb"    "eggBomb"    "poisonFang" "eggBomb"   
## [26] "eggBomb"    "eggBomb"    "eggBomb"    "eggBomb"    "poisonFang"
## [31] "eggBomb"    "poisonFang" "eggBomb"    "eggBomb"    "eggBomb"   
## [36] "poisonFang" "eggBomb"    "poisonFang" "eggBomb"
```

```r
#Sum of rows
rowSums(kMat)
```

```
##     12     13     14     15      9     10     11     28     29     30 
## 25.052 24.087 23.712 23.221 22.547 24.210 24.092 22.964 22.657 23.992 
##     31     24     25     26     27     36     37     38     39     32 
## 23.256 22.960 22.780 22.599 23.396 22.172 24.804 22.494 22.313 22.584 
##     33     34     35     20     21     22     23     16     17     18 
## 23.143 22.604 22.745 25.428 24.172 23.860 21.805 24.525 24.758 24.941 
##     19      5      6      7      8      1      2      3      4 
## 24.438 24.819 23.983 23.704 24.523 23.862 23.644 23.926 23.423
```

```r
#sanity check
all.equal(rowSums(kMat), apply(kMat, 1, sum))
```

```
## [1] TRUE
```

```r
#column mean
colMeans(kMat)
```

```
## crabHammer    eggBomb poisonFang 
##   9.427821   6.788077   7.378846
```

```r
#sanity check
all.equal(colMeans(kMat), apply(kMat, 2, mean))
```

```
## [1] TRUE
```
***Learning aggregate() on groups***


```r
aggregate(eggBomb ~ devStage, kDat, FUN = mean)
```

```
##   devStage  eggBomb
## 1      E16 6.879000
## 2       P2 6.408000
## 3       P6 6.459375
## 4      P10 7.142500
## 5  4_weeks 7.062875
```

```r
#Splitting data on the basis of a combination of factors
aggregate(eggBomb ~ gType * devStage, kDat, FUN = mean)
```

```
##    gType devStage  eggBomb
## 1     wt      E16 6.900250
## 2  NrlKO      E16 6.850667
## 3     wt       P2 6.606750
## 4  NrlKO       P2 6.209250
## 5     wt       P6 6.646000
## 6  NrlKO       P6 6.272750
## 7     wt      P10 7.041750
## 8  NrlKO      P10 7.243250
## 9     wt  4_weeks 7.117250
## 10 NrlKO  4_weeks 7.008500
```

```r
#Max and min for each group
aggregate(eggBomb ~ gType * devStage, kDat, FUN = range)
```

```
##    gType devStage eggBomb.1 eggBomb.2
## 1     wt      E16     6.529     7.462
## 2  NrlKO      E16     6.470     7.065
## 3     wt       P2     6.170     6.870
## 4  NrlKO       P2     6.138     6.269
## 5     wt       P6     6.211     7.574
## 6  NrlKO       P6     6.188     6.347
## 7     wt      P10     6.155     8.173
## 8  NrlKO      P10     7.081     7.438
## 9     wt  4_weeks     6.608     7.866
## 10 NrlKO  4_weeks     6.558     7.204
```

```r
#Learning to do the same jobs w=using plyr
ddply(kDat, ~ devStage, summarize, avg = mean(eggBomb))
```

```
##   devStage      avg
## 1      E16 6.879000
## 2       P2 6.408000
## 3       P6 6.459375
## 4      P10 7.142500
## 5  4_weeks 7.062875
```

```r
ddply(kDat, ~ gType * devStage, summarize, avg = mean(eggBomb))
```

```
##    gType devStage      avg
## 1     wt      E16 6.900250
## 2     wt       P2 6.606750
## 3     wt       P6 6.646000
## 4     wt      P10 7.041750
## 5     wt  4_weeks 7.117250
## 6  NrlKO      E16 6.850667
## 7  NrlKO       P2 6.209250
## 8  NrlKO       P6 6.272750
## 9  NrlKO      P10 7.243250
## 10 NrlKO  4_weeks 7.008500
```

```r
ddply(kDat, ~ gType * devStage, summarize,
      min = min(eggBomb), max = max(eggBomb))
```

```
##    gType devStage   min   max
## 1     wt      E16 6.529 7.462
## 2     wt       P2 6.170 6.870
## 3     wt       P6 6.211 7.574
## 4     wt      P10 6.155 8.173
## 5     wt  4_weeks 6.608 7.866
## 6  NrlKO      E16 6.470 7.065
## 7  NrlKO       P2 6.138 6.269
## 8  NrlKO       P6 6.188 6.347
## 9  NrlKO      P10 7.081 7.438
## 10 NrlKO  4_weeks 6.558 7.204
```
**Two sample tests on a handful of genes**

```r
#Taking six genes
keepGenes <- c("1431708_a_at", "1424336_at", "1454696_at",
               "1416119_at", "1432141_x_at", "1429226_at" )
miniDat <- subset(prDat, rownames(prDat) %in% keepGenes)
miniDat <- data.frame(gExp = as.vector(t(as.matrix(miniDat))),
                      gene = factor(rep(rownames(miniDat), each = ncol(miniDat)),
                                    levels = keepGenes))
miniDat <- suppressWarnings(data.frame(prDes, miniDat))
str(miniDat)
```

```
## 'data.frame':	234 obs. of  6 variables:
##  $ sidChar : chr  "Sample_20" "Sample_21" "Sample_22" "Sample_23" ...
##  $ sidNum  : num  20 21 22 23 16 17 6 24 25 26 ...
##  $ devStage: Factor w/ 5 levels "E16","P2","P6",..: 1 1 1 1 1 1 1 2 2 2 ...
##  $ gType   : Factor w/ 2 levels "wt","NrlKO": 1 1 1 1 2 2 2 1 1 1 ...
##  $ gExp    : num  10.6 11 10.8 10.9 9.2 ...
##  $ gene    : Factor w/ 6 levels "1431708_a_at",..: 4 4 4 4 4 4 4 4 4 4 ...
```

```r
#Plotting with stripplot
stripplot(gType ~ gExp | gene, miniDat,
          scales = list(x = list(relation = "free")),
          group = gType, auto.key = TRUE)
```

![](seminar04a_files/figure-html/unnamed-chunk-5-1.png) 

```r
#Plotting with ggplot
ggplot(miniDat, aes(x = gExp, y = gType, color = gType)) +
  facet_wrap(~ gene, scales="free_x") +
  geom_point(alpha = 0.7) +
  theme(panel.grid.major.x = element_blank())
```

![](seminar04a_files/figure-html/unnamed-chunk-5-2.png) 

```r
#2-sample t-test on one gene
someDat <- droplevels(subset(miniDat, gene == keepGenes[1]))
t.test(gExp ~ gType, someDat)
```

```
## 
## 	Welch Two Sample t-test
## 
## data:  gExp by gType
## t = 9.838, df = 36.89, p-value = 7.381e-12
## alternative hypothesis: true difference in means is not equal to 0
## 95 percent confidence interval:
##  1.569556 2.383870
## sample estimates:
##    mean in group wt mean in group NrlKO 
##            9.554450            7.577737
```

```r
#Using the plyr package
  
  library(plyr)
d_ply(miniDat, ~ gene, function(x) t.test(gExp ~ gType, x), .print = TRUE)
```

```
## 
## 	Welch Two Sample t-test
## 
## data:  gExp by gType
## t = 9.838, df = 36.89, p-value = 7.381e-12
## alternative hypothesis: true difference in means is not equal to 0
## 95 percent confidence interval:
##  1.569556 2.383870
## sample estimates:
##    mean in group wt mean in group NrlKO 
##            9.554450            7.577737 
## 
## 
## 	Welch Two Sample t-test
## 
## data:  gExp by gType
## t = 9.0607, df = 36.489, p-value = 7.146e-11
## alternative hypothesis: true difference in means is not equal to 0
## 95 percent confidence interval:
##  0.6238652 0.9834769
## sample estimates:
##    mean in group wt mean in group NrlKO 
##            7.670250            6.866579 
## 
## 
## 	Welch Two Sample t-test
## 
## data:  gExp by gType
## t = 8.0771, df = 33.493, p-value = 2.278e-09
## alternative hypothesis: true difference in means is not equal to 0
## 95 percent confidence interval:
##  1.402286 2.345872
## sample estimates:
##    mean in group wt mean in group NrlKO 
##            12.84850            10.97442 
## 
## 
## 	Welch Two Sample t-test
## 
## data:  gExp by gType
## t = -0.184, df = 36.534, p-value = 0.8551
## alternative hypothesis: true difference in means is not equal to 0
## 95 percent confidence interval:
##  -0.5079125  0.4233967
## sample estimates:
##    mean in group wt mean in group NrlKO 
##            9.892900            9.935158 
## 
## 
## 	Welch Two Sample t-test
## 
## data:  gExp by gType
## t = -0.1324, df = 36.313, p-value = 0.8954
## alternative hypothesis: true difference in means is not equal to 0
## 95 percent confidence interval:
##  -0.2413424  0.2117529
## sample estimates:
##    mean in group wt mean in group NrlKO 
##            7.092100            7.106895 
## 
## 
## 	Welch Two Sample t-test
## 
## data:  gExp by gType
## t = 0.0983, df = 35.578, p-value = 0.9223
## alternative hypothesis: true difference in means is not equal to 0
## 95 percent confidence interval:
##  -0.1019067  0.1122804
## sample estimates:
##    mean in group wt mean in group NrlKO 
##            6.551450            6.546263
```

```r
#making a list of the output for better organisation
ttRes <- dlply(miniDat, ~ gene, function(x) t.test(gExp ~ gType, x))
names(ttRes)
```

```
## [1] "1431708_a_at" "1424336_at"   "1454696_at"   "1416119_at"  
## [5] "1432141_x_at" "1429226_at"
```

```r
#Retrieving a single gene result
ttRes[["1454696_at"]]
```

```
## 
## 	Welch Two Sample t-test
## 
## data:  gExp by gType
## t = 8.0771, df = 33.493, p-value = 2.278e-09
## alternative hypothesis: true difference in means is not equal to 0
## 95 percent confidence interval:
##  1.402286 2.345872
## sample estimates:
##    mean in group wt mean in group NrlKO 
##            12.84850            10.97442
```

**HOMEWORK**

```r
prDat <- read.table("GSE4051_data.tsv.txt")

#Selecting 50 random rows.
set.seed(5)
random_rows <- sample(1:nrow(prDat),size = 50)
prmat <- prDat[random_rows,]

#Making a matrix
rDat = matrix( rnorm(50*50) , nrow=50 , ncol=50 )
pr_plot <- apply(combn(50, 2), 2, function (x) {
    t.test(prmat[x[1],], prmat[x[2],])$p.value
})
r_plot <- apply(combn(50, 2), 2, function (x) {
    t.test(rDat[x[1],], rDat[x[2],])$p.value
})
hist(r_plot, breaks=30, xlab="p-value")
```

![](seminar04a_files/figure-html/unnamed-chunk-6-1.png) 

```r
ggplot(data.frame(p.value=pr_plot), aes(x=p.value)) + geom_histogram()
```

```
## stat_bin: binwidth defaulted to range/30. Use 'binwidth = x' to adjust this.
```

![](seminar04a_files/figure-html/unnamed-chunk-6-2.png) 



The above two histograms differ in the case that the data from one belong to the same normal distribution and the expression levels are correlated with each other. While, the values belonging to the other histogram have different expression levels, contributing to a fairly even distribution of p-values.  
