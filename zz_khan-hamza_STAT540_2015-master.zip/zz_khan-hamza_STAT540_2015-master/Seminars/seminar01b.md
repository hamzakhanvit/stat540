# sem01b
hamzakhanvit  
Friday, January 23, 2015  



```r
#Reading data from a file
prDat <- read.table("C:/Users/HAMZA/Desktop/stat540/GSE4051_MINI.tsv.txt", header = TRUE, row.names = 1)
str(prDat)
```

```
## 'data.frame':	39 obs. of  6 variables:
##  $ sidNum    : int  20 21 22 23 16 17 6 24 25 26 ...
##  $ devStage  : Factor w/ 5 levels "4_weeks","E16",..: 2 2 2 2 2 2 2 4 4 4 ...
##  $ gType     : Factor w/ 2 levels "NrlKO","wt": 2 2 2 2 1 1 1 2 2 2 ...
##  $ crabHammer: num  10.22 10.02 9.64 9.65 8.58 ...
##  $ eggBomb   : num  7.46 6.89 6.72 6.53 6.47 ...
##  $ poisonFang: num  7.37 7.18 7.35 7.04 7.49 ...
```

```r
#No. of rows = 39
nrow(prDat)
```

```
## [1] 39
```

```r
dim(prDat)
```

```
## [1] 39  6
```

```r
#No. of columns or variables = 6
ncol(prDat)
```

```
## [1] 6
```

```r
length(prDat)
```

```
## [1] 6
```

```r
dim(prDat)
```

```
## [1] 39  6
```

```r
#First few observations
head(prDat)
```

```
##           sidNum devStage gType crabHammer eggBomb poisonFang
## Sample_20     20      E16    wt     10.220   7.462      7.370
## Sample_21     21      E16    wt     10.020   6.890      7.177
## Sample_22     22      E16    wt      9.642   6.720      7.350
## Sample_23     23      E16    wt      9.652   6.529      7.040
## Sample_16     16      E16 NrlKO      8.583   6.470      7.494
## Sample_17     17      E16 NrlKO     10.140   7.065      7.005
```

```r
#Last few observations
tail(prDat)
```

```
##           sidNum devStage gType crabHammer eggBomb poisonFang
## Sample_38     38  4_weeks    wt      9.767   6.608      7.329
## Sample_39     39  4_weeks    wt     10.200   7.003      7.320
## Sample_11     11  4_weeks NrlKO      9.677   7.204      6.981
## Sample_12     12  4_weeks NrlKO      9.129   7.165      7.350
## Sample_2       2  4_weeks NrlKO      9.744   7.107      7.075
## Sample_9       9  4_weeks NrlKO      9.822   6.558      7.043
```

```r
#Rows corresponds to different MICE

#Variable names
names(prDat)
```

```
## [1] "sidNum"     "devStage"   "gType"      "crabHammer" "eggBomb"   
## [6] "poisonFang"
```

```r
dimnames(prDat) # All dimensions ,ie; row names and column names
```

```
## [[1]]
##  [1] "Sample_20" "Sample_21" "Sample_22" "Sample_23" "Sample_16"
##  [6] "Sample_17" "Sample_6"  "Sample_24" "Sample_25" "Sample_26"
## [11] "Sample_27" "Sample_14" "Sample_3"  "Sample_5"  "Sample_8" 
## [16] "Sample_28" "Sample_29" "Sample_30" "Sample_31" "Sample_1" 
## [21] "Sample_10" "Sample_4"  "Sample_7"  "Sample_32" "Sample_33"
## [26] "Sample_34" "Sample_35" "Sample_13" "Sample_15" "Sample_18"
## [31] "Sample_19" "Sample_36" "Sample_37" "Sample_38" "Sample_39"
## [36] "Sample_11" "Sample_12" "Sample_2"  "Sample_9" 
## 
## [[2]]
## [1] "sidNum"     "devStage"   "gType"      "crabHammer" "eggBomb"   
## [6] "poisonFang"
```

```r
#Flavor in each variable = one int, two factors, three num
str(prDat)
```

```
## 'data.frame':	39 obs. of  6 variables:
##  $ sidNum    : int  20 21 22 23 16 17 6 24 25 26 ...
##  $ devStage  : Factor w/ 5 levels "4_weeks","E16",..: 2 2 2 2 2 2 2 4 4 4 ...
##  $ gType     : Factor w/ 2 levels "NrlKO","wt": 2 2 2 2 1 1 1 2 2 2 ...
##  $ crabHammer: num  10.22 10.02 9.64 9.65 8.58 ...
##  $ eggBomb   : num  7.46 6.89 6.72 6.53 6.47 ...
##  $ poisonFang: num  7.37 7.18 7.35 7.04 7.49 ...
```

```r
#Sanity Check
str(prDat)
```

```
## 'data.frame':	39 obs. of  6 variables:
##  $ sidNum    : int  20 21 22 23 16 17 6 24 25 26 ...
##  $ devStage  : Factor w/ 5 levels "4_weeks","E16",..: 2 2 2 2 2 2 2 4 4 4 ...
##  $ gType     : Factor w/ 2 levels "NrlKO","wt": 2 2 2 2 1 1 1 2 2 2 ...
##  $ crabHammer: num  10.22 10.02 9.64 9.65 8.58 ...
##  $ eggBomb   : num  7.46 6.89 6.72 6.53 6.47 ...
##  $ poisonFang: num  7.37 7.18 7.35 7.04 7.49 ...
```

```r
sort(prDat$sidNum)
```

```
##  [1]  1  2  3  4  5  6  7  8  9 10 11 12 13 14 15 16 17 18 19 20 21 22 23
## [24] 24 25 26 27 28 29 30 31 32 33 34 35 36 37 38 39
```

```r
seq_len(nrow(prDat))
```

```
##  [1]  1  2  3  4  5  6  7  8  9 10 11 12 13 14 15 16 17 18 19 20 21 22 23
## [24] 24 25 26 27 28 29 30 31 32 33 34 35 36 37 38 39
```

```r
all(sort(prDat$sidNum) == seq_len(nrow(prDat)))
```

```
## [1] TRUE
```

```r
identical(sort(prDat$sidNum), seq_len(nrow(prDat)))
```

```
## [1] TRUE
```

```r
#Levels for each factor

# Levels for devStage = 5
levels(prDat$devStage)
```

```
## [1] "4_weeks" "E16"     "P10"     "P2"      "P6"
```

```r
# Levels for gType = 2
levels(prDat$gType)
```

```
## [1] "NrlKO" "wt"
```

```r
#How many observations do we have for each level of devStage? gType?

# devStage
summary(prDat$devStage)
```

```
## 4_weeks     E16     P10      P2      P6 
##       8       7       8       8       8
```

```r
# gType
summary(prDat$gType)
```

```
## NrlKO    wt 
##    19    20
```

```r
#Perform cross-tabulation of devStage and gType.

table(prDat$devStage, prDat$gType)
```

```
##          
##           NrlKO wt
##   4_weeks     4  4
##   E16         3  4
##   P10         4  4
##   P2          4  4
##   P6          4  4
```

```r
addmargins(with(prDat, table(devStage, gType)))
```

```
##          gType
## devStage  NrlKO wt Sum
##   4_weeks     4  4   8
##   E16         3  4   7
##   P10         4  4   8
##   P2          4  4   8
##   P6          4  4   8
##   Sum        19 20  39
```

```r
#If you had to guess, what do you think the intended experimental design was? What happened in real life?

#The intended experimental design would have been to take 4 mice for each and every genotype and developmental stage. It was found that one of the NrlKO mice died at its embryonic stage.

#For each quantitative variable, what are the extremes? How about the average or median?

# For sidNum
range(prDat$sidNum)
```

```
## [1]  1 39
```

```r
summary(prDat$sidNum)
```

```
##    Min. 1st Qu.  Median    Mean 3rd Qu.    Max. 
##     1.0    10.5    20.0    20.0    29.5    39.0
```

```r
# For poisonfang
summary(prDat$poisonFang)
```

```
##    Min. 1st Qu.  Median    Mean 3rd Qu.    Max. 
##   6.735   7.188   7.350   7.379   7.476   8.584
```

```r
# For eggbomb
summary(prDat$eggBomb)
```

```
##    Min. 1st Qu.  Median    Mean 3rd Qu.    Max. 
##   6.138   6.278   6.757   6.788   7.094   8.173
```

```r
# For crabhammer
summary(prDat$crabHammer)
```

```
##    Min. 1st Qu.  Median    Mean 3rd Qu.    Max. 
##   8.214   8.938   9.611   9.428   9.830  10.340
```

```r
# Creating a new data frame with poisonFang > 7.5
weeDat <- subset(prDat, poisonFang > 7.5)

#For how many observations poisonFang > 7.5? How do they break down by genotype and developmental stage?
str(weeDat)
```

```
## 'data.frame':	9 obs. of  6 variables:
##  $ sidNum    : int  24 26 27 8 7 33 34 15 19
##  $ devStage  : Factor w/ 5 levels "4_weeks","E16",..: 4 4 4 4 5 3 3 3 3
##  $ gType     : Factor w/ 2 levels "NrlKO","wt": 2 2 2 1 1 2 2 1 1
##  $ crabHammer: num  8.87 9.61 8.61 9.12 8.8 ...
##  $ eggBomb   : num  6.59 6.87 6.8 6.26 6.19 ...
##  $ poisonFang: num  7.51 7.51 7.84 8.02 7.75 ...
```

```r
summary(weeDat)
```

```
##      sidNum         devStage   gType     crabHammer       eggBomb     
##  Min.   : 7.00   4_weeks:0   NrlKO:4   Min.   :8.519   Min.   :6.188  
##  1st Qu.:15.00   E16    :0   wt   :5   1st Qu.:8.803   1st Qu.:6.587  
##  Median :24.00   P10    :4             Median :9.004   Median :6.800  
##  Mean   :21.44   P2     :4             Mean   :9.117   Mean   :6.762  
##  3rd Qu.:27.00   P6     :1             3rd Qu.:9.611   3rd Qu.:7.081  
##  Max.   :34.00                         Max.   :9.771   Max.   :7.226  
##    poisonFang   
##  Min.   :7.508  
##  1st Qu.:7.586  
##  Median :7.786  
##  Mean   :7.853  
##  3rd Qu.:8.016  
##  Max.   :8.584
```

```r
#Print the observations with row names “Sample_16” and “Sample_38” to screen, showing only the 3 gene expression variables.
prDat[c("Sample_16", "Sample_38"), c("crabHammer", "eggBomb", "poisonFang")]
```

```
##           crabHammer eggBomb poisonFang
## Sample_16      8.583   6.470      7.494
## Sample_38      9.767   6.608      7.329
```

```r
#Which samples have eggBomb less than the 0.10 quartile?

rownames(prDat[prDat$eggBomb < quantile(prDat$eggBomb, 0.1), ])
```

```
## [1] "Sample_25" "Sample_14" "Sample_3"  "Sample_35"
```
BONUS

```r
require(dplyr)
```

```
## Loading required package: dplyr
## 
## Attaching package: 'dplyr'
## 
## The following object is masked from 'package:stats':
## 
##     filter
## 
## The following objects are masked from 'package:base':
## 
##     intersect, setdiff, setequal, union
```

```r
select(filter(prDat, rownames(prDat)=="Sample_16"| rownames(prDat)=="Sample_38"),crabHammer,eggBomb,poisonFang)
```

```
##   crabHammer eggBomb poisonFang
## 1      8.583   6.470      7.494
## 2      9.767   6.608      7.329
```
