# seminar005
hamzakhanvit  
Wednesday, February 04, 2015  


```r
library(lattice) 
library(ggplot2) 
library(reshape2) 
prDat <- read.table("GSE4051_data.tsv.txt")
str(prDat, max.level = 0)
```

```
## 'data.frame':	29949 obs. of  39 variables:
```

```r
#head(prDat)
prDes <- readRDS("GSE4051_design.rds")
str(prDes)
```

```
## 'data.frame':	39 obs. of  4 variables:
##  $ sidChar : chr  "Sample_20" "Sample_21" "Sample_22" "Sample_23" ...
##  $ sidNum  : num  20 21 22 23 16 17 6 24 25 26 ...
##  $ devStage: Factor w/ 5 levels "E16","P2","P6",..: 1 1 1 1 1 1 1 2 2 2 ...
##  $ gType   : Factor w/ 2 levels "wt","NrlKO": 1 1 1 1 2 2 2 1 1 1 ...
```

```r
head(prDes)
```

```
##      sidChar sidNum devStage gType
## 12 Sample_20     20      E16    wt
## 13 Sample_21     21      E16    wt
## 14 Sample_22     22      E16    wt
## 15 Sample_23     23      E16    wt
## 9  Sample_16     16      E16 NrlKO
## 10 Sample_17     17      E16 NrlKO
```
###FUNCTION PREPAREDATA

```r
prepareData <- function(x){
just<-prDat[rownames(prDat)==x,] 
head(just)
colnames(just)
prDes$sidChar
coll <- prDes[prDes$sidChar==colnames(just),]
gExp <- t(just)
gene <- rep(x,nrow(coll))
out <- cbind(coll,gExp,gene)
colnames(out)[5]="gExp"
return(out)
}

tempfunc <- function(x){
  out <- prepareData(x[1])
  if(length(x)>1){
    for(i in 2:length(x)){
      out=rbind(out,prepareData(x[i]))
    }
    return(out)
  }
  
}

(luckyGenes <- c("1419655_at","1438815_at"))
```

```
## [1] "1419655_at" "1438815_at"
```

```r
jDat <- tempfunc(luckyGenes)
head(jDat)
```

```
##      sidChar sidNum devStage gType   gExp       gene
## 12 Sample_20     20      E16    wt 10.930 1419655_at
## 13 Sample_21     21      E16    wt 10.740 1419655_at
## 14 Sample_22     22      E16    wt 10.670 1419655_at
## 15 Sample_23     23      E16    wt 10.680 1419655_at
## 9  Sample_16     16      E16 NrlKO  9.606 1419655_at
## 10 Sample_17     17      E16 NrlKO 10.840 1419655_at
```

```r
mDat <- read.table("mDat.tsv",header=T,sep="\t",row.names=1)
head(mDat)
```

```
##      sidChar sidNum devStage gType  gExp         gene
## 12 Sample_20     20      E16    wt 7.938 1438786_a_at
## 13 Sample_21     21      E16    wt 8.986 1438786_a_at
## 14 Sample_22     22      E16    wt 8.550 1438786_a_at
## 15 Sample_23     23      E16    wt 8.617 1438786_a_at
## 9  Sample_16     16      E16 NrlKO 5.721 1438786_a_at
## 10 Sample_17     17      E16 NrlKO 9.104 1438786_a_at
```
###A Tiny little function to make a stripplot

```r
mystripplot <- function(x, ...){

stripplot(gExp ~ devStage | gene, x,
          group = gType, jitter.data = TRUE,
          auto.key = TRUE, type = c('p', 'a'), ... , grid = TRUE)
}

mystripplot(jDat)
```

![](seminar005_files/figure-html/unnamed-chunk-3-1.png) 

```r
mystripplot(jDat,pch = 17, cex = 3)
```

![](seminar005_files/figure-html/unnamed-chunk-3-2.png) 

```r
makeStripplotGg <- function(x, ...){
(p <- ggplot(x, aes( devStage,gExp,...,color = gType)) + 
   geom_point() + facet_wrap(~gene) +
   stat_smooth(se = F))
}

makeStripplotGg(jDat)
```

```
## geom_smooth: Only one unique x value each group.Maybe you want aes(group = 1)?
## geom_smooth: Only one unique x value each group.Maybe you want aes(group = 1)?
```

![](seminar005_files/figure-html/unnamed-chunk-3-3.png) 

```r
mystripplot(newDat <- prepareData("1419655_at"))
```

![](seminar005_files/figure-html/unnamed-chunk-3-4.png) 

```r
str(newDat)
```

```
## 'data.frame':	39 obs. of  6 variables:
##  $ sidChar : chr  "Sample_20" "Sample_21" "Sample_22" "Sample_23" ...
##  $ sidNum  : num  20 21 22 23 16 17 6 24 25 26 ...
##  $ devStage: Factor w/ 5 levels "E16","P2","P6",..: 1 1 1 1 1 1 1 2 2 2 ...
##  $ gType   : Factor w/ 2 levels "wt","NrlKO": 1 1 1 1 2 2 2 1 1 1 ...
##  $ gExp    : num  10.93 10.74 10.67 10.68 9.61 ...
##  $ gene    : Factor w/ 1 level "1419655_at": 1 1 1 1 1 1 1 1 1 1 ...
```

```r
head(newDat)
```

```
##      sidChar sidNum devStage gType   gExp       gene
## 12 Sample_20     20      E16    wt 10.930 1419655_at
## 13 Sample_21     21      E16    wt 10.740 1419655_at
## 14 Sample_22     22      E16    wt 10.670 1419655_at
## 15 Sample_23     23      E16    wt 10.680 1419655_at
## 9  Sample_16     16      E16 NrlKO  9.606 1419655_at
## 10 Sample_17     17      E16 NrlKO 10.840 1419655_at
```

###TWO SAMPLE t-test 

```r
t.test(gExp ~ devStage, subset = devStage %in% c("P2", "4_weeks"), var.equal = TRUE, jDat)
```

```
## 
## 	Two Sample t-test
## 
## data:  gExp by devStage
## t = 3.8123, df = 30, p-value = 0.0006379
## alternative hypothesis: true difference in means is not equal to 0
## 95 percent confidence interval:
##  0.4745641 1.5696859
## sample estimates:
##      mean in group P2 mean in group 4_weeks 
##              9.948063              8.925937
```
FIT A LINEAR MODEL

```r
mystripplot(Dat <- prepareData("1438786_a_at"))
```

![](seminar005_files/figure-html/unnamed-chunk-5-1.png) 

```r
#MODEL expression as a function of the devStage factor.

summary(model <- lm(formula = gExp ~ devStage, data = Dat, subset = gType == "wt"))
```

```
## 
## Call:
## lm(formula = gExp ~ devStage, data = Dat, subset = gType == "wt")
## 
## Residuals:
##      Min       1Q   Median       3Q      Max 
## -1.15650 -0.44000  0.02875  0.49150  1.20650 
## 
## Coefficients:
##                 Estimate Std. Error t value Pr(>|t|)    
## (Intercept)       8.5228     0.3788  22.498  5.7e-13 ***
## devStageP2       -1.4503     0.5357  -2.707   0.0162 *  
## devStageP6       -0.1067     0.5357  -0.199   0.8447    
## devStageP10      -1.2012     0.5357  -2.242   0.0405 *  
## devStage4_weeks   0.0810     0.5357   0.151   0.8818    
## ---
## Signif. codes:  0 '***' 0.001 '**' 0.01 '*' 0.05 '.' 0.1 ' ' 1
## 
## Residual standard error: 0.7576 on 15 degrees of freedom
## Multiple R-squared:  0.4974,	Adjusted R-squared:  0.3634 
## F-statistic: 3.712 on 4 and 15 DF,  p-value: 0.02716
```

```r
coef(model)
```

```
##     (Intercept)      devStageP2      devStageP6     devStageP10 
##         8.52275        -1.45025        -0.10675        -1.20125 
## devStage4_weeks 
##         0.08100
```

Yes, the intercept looks pausible. The summary report shows that devStage P2 is significantly different from E16 at an alpha of 0.05. 

###INFERENCING THE CONTRAST

```r
library(gmodels)
cmat <- rbind( "P2 vs P10"    =c(0,1, 0, -1, 0))
coef(model)
```

```
##     (Intercept)      devStageP2      devStageP6     devStageP10 
##         8.52275        -1.45025        -0.10675        -1.20125 
## devStage4_weeks 
##         0.08100
```

```r
(obsDiff <- cmat %*% coef(model))
```

```
##             [,1]
## P2 vs P10 -0.249
```

```r
#Checking the observed difference in sample mean for the wild type mice, P2 vs. P10.
(sampMeans <- aggregate(gExp ~ devStage, mDat, FUN = mean,
                        subset = gType == "wt"))
```

```
##   devStage    gExp
## 1  4_weeks 8.60375
## 2      E16 8.52275
## 3      P10 7.32150
## 4       P2 7.07250
## 5       P6 8.41600
```

```r
with(sampMeans, gExp[devStage == "P2"] - gExp[devStage == "P10"])
```

```
## [1] -0.249
```

```r
#Yes, it is the same.


#Variance and co-variance
vcov(model)
```

```
##                 (Intercept) devStageP2 devStageP6 devStageP10
## (Intercept)       0.1435072 -0.1435072 -0.1435072  -0.1435072
## devStageP2       -0.1435072  0.2870144  0.1435072   0.1435072
## devStageP6       -0.1435072  0.1435072  0.2870144   0.1435072
## devStageP10      -0.1435072  0.1435072  0.1435072   0.2870144
## devStage4_weeks  -0.1435072  0.1435072  0.1435072   0.1435072
##                 devStage4_weeks
## (Intercept)          -0.1435072
## devStageP2            0.1435072
## devStageP6            0.1435072
## devStageP10           0.1435072
## devStage4_weeks       0.2870144
```

```r
summary(model)$coefficients[ , "Std. Error"]
```

```
##     (Intercept)      devStageP2      devStageP6     devStageP10 
##       0.3788234       0.5357372       0.5357372       0.5357372 
## devStage4_weeks 
##       0.5357372
```

```r
sqrt(diag(vcov(model)))
```

```
##     (Intercept)      devStageP2      devStageP6     devStageP10 
##       0.3788234       0.5357372       0.5357372       0.5357372 
## devStage4_weeks 
##       0.5357372
```

```r
summary(model)$coefficients
```

```
##                 Estimate Std. Error    t value     Pr(>|t|)
## (Intercept)      8.52275  0.3788234 22.4979484 5.697244e-13
## devStageP2      -1.45025  0.5357372 -2.7070174 1.622876e-02
## devStageP6      -0.10675  0.5357372 -0.1992581 8.447367e-01
## devStageP10     -1.20125  0.5357372 -2.2422373 4.048697e-02
## devStage4_weeks  0.08100  0.5357372  0.1511935 8.818377e-01
```

```r
(estSe <- cmat %*% vcov(model) %*% t(cmat))
```

```
##           P2 vs P10
## P2 vs P10 0.2870144
```

```r
#test statistic as an observed effect divided by its estimated standard error:

(testStat <- obsDiff/estSe)
```

```
##                 [,1]
## P2 vs P10 -0.8675523
```

```r
2 * pt(abs(testStat), df = df.residual(model), lower.tail = FALSE)
```

```
##                [,1]
## P2 vs P10 0.3993062
```
FIT A LINEAR MODEL WITH TWO CATEGORIAL CO-VARIATES

```r
#With interactions
mystripplot(oDat <- prepareData("1448690_at"))
```

![](seminar005_files/figure-html/unnamed-chunk-7-1.png) 

```r
str(oDat)
```

```
## 'data.frame':	39 obs. of  6 variables:
##  $ sidChar : chr  "Sample_20" "Sample_21" "Sample_22" "Sample_23" ...
##  $ sidNum  : num  20 21 22 23 16 17 6 24 25 26 ...
##  $ devStage: Factor w/ 5 levels "E16","P2","P6",..: 1 1 1 1 1 1 1 2 2 2 ...
##  $ gType   : Factor w/ 2 levels "wt","NrlKO": 1 1 1 1 2 2 2 1 1 1 ...
##  $ gExp    : num  8.02 9.05 8.71 8.92 6.8 ...
##  $ gene    : Factor w/ 1 level "1448690_at": 1 1 1 1 1 1 1 1 1 1 ...
```

```r
model1 <- lm(formula = gExp ~ devStage * gType, data = oDat)
summary(model1)$coef
```

```
##                               Estimate Std. Error     t value     Pr(>|t|)
## (Intercept)                 8.67800000  0.3986668 21.76754966 1.634011e-19
## devStageP2                 -1.02900000  0.5638000 -1.82511517 7.830030e-02
## devStageP6                 -1.91450000  0.5638000 -3.39570748 2.002778e-03
## devStageP10                -2.19325000  0.5638000 -3.89012036 5.387044e-04
## devStage4_weeks            -2.08200000  0.5638000 -3.69279862 9.148816e-04
## gTypeNrlKO                 -0.84233333  0.6089736 -1.38320163 1.771604e-01
## devStageP2:gTypeNrlKO       0.06983333  0.8298912  0.08414758 9.335173e-01
## devStageP6:gTypeNrlKO       0.16533333  0.8298912  0.19922291 8.434787e-01
## devStageP10:gTypeNrlKO      0.22583333  0.8298912  0.27212403 7.874548e-01
## devStage4_weeks:gTypeNrlKO  0.64608333  0.8298912  0.77851572 4.425713e-01
```

```r
#Without interactions
model2 <- lm(formula = gExp ~ devStage + gType, data = oDat)
summary(model2)$coef
```

```
##                   Estimate Std. Error   t value     Pr(>|t|)
## (Intercept)      8.5803162  0.3046461 28.164864 1.177029e-24
## devStageP2      -1.0103640  0.3924016 -2.574821 1.470127e-02
## devStageP6      -1.8481140  0.3924016 -4.709752 4.327597e-05
## devStageP10     -2.0966140  0.3924016 -5.343032 6.703381e-06
## devStage4_weeks -1.7752390  0.3924016 -4.524036 7.443740e-05
## gTypeNrlKO      -0.6144044  0.2430235 -2.528168 1.643264e-02
```

```r
#ANOVA Between models
(model3 <- anova(model1, model2))
```

```
## Analysis of Variance Table
## 
## Model 1: gExp ~ devStage * gType
## Model 2: gExp ~ devStage + gType
##   Res.Df    RSS Df Sum of Sq      F Pr(>F)
## 1     29 18.436                           
## 2     33 18.933 -4   -0.4966 0.1953 0.9389
```

##TAKE HOME PROBLEM

**Q1. Estimating the effect of devStage on mDat with lm().**

```r
m1 <- lm(formula = gExp ~ devStage, data = mDat) 
summary(m1)
```

```
## 
## Call:
## lm(formula = gExp ~ devStage, data = mDat)
## 
## Residuals:
##      Min       1Q   Median       3Q      Max 
## -2.55871 -0.44281 -0.07737  0.56787  1.48525 
## 
## Coefficients:
##             Estimate Std. Error t value Pr(>|t|)    
## (Intercept)  8.37137    0.29630  28.254  < 2e-16 ***
## devStageE16 -0.09166    0.43373  -0.211  0.83389    
## devStageP10 -1.32863    0.41902  -3.171  0.00321 ** 
## devStageP2  -1.42200    0.41902  -3.394  0.00177 ** 
## devStageP6  -0.59350    0.41902  -1.416  0.16576    
## ---
## Signif. codes:  0 '***' 0.001 '**' 0.01 '*' 0.05 '.' 0.1 ' ' 1
## 
## Residual standard error: 0.838 on 34 degrees of freedom
## Multiple R-squared:  0.3685,	Adjusted R-squared:  0.2942 
## F-statistic: 4.959 on 4 and 34 DF,  p-value: 0.002936
```
Dev stage P2 and P10 look significantly different from 4_weeks with an alpha of 0.01.



**Q2.Run the exact same test on mDat values with genotype "NrlKO". What are the differences between this test and the last one?**

```r
m2  <- lm(gExp ~ devStage, data = mDat, subset = gType == "NrlKO")
summary(m2)
```

```
## 
## Call:
## lm(formula = gExp ~ devStage, data = mDat, subset = gType == 
##     "NrlKO")
## 
## Residuals:
##      Min       1Q   Median       3Q      Max 
## -2.23467 -0.23350  0.07575  0.45787  1.14833 
## 
## Coefficients:
##             Estimate Std. Error t value Pr(>|t|)    
## (Intercept)   8.1390     0.4286  18.992 2.17e-11 ***
## devStageE16  -0.1833     0.6546  -0.280   0.7835    
## devStageP10  -1.3750     0.6061  -2.269   0.0396 *  
## devStageP2   -1.3128     0.6061  -2.166   0.0481 *  
## devStageP6   -0.9992     0.6061  -1.649   0.1214    
## ---
## Signif. codes:  0 '***' 0.001 '**' 0.01 '*' 0.05 '.' 0.1 ' ' 1
## 
## Residual standard error: 0.8571 on 14 degrees of freedom
## Multiple R-squared:  0.3774,	Adjusted R-squared:  0.1995 
## F-statistic: 2.121 on 4 and 14 DF,  p-value: 0.1321
```

```r
coef(m2)
```

```
## (Intercept) devStageE16 devStageP10  devStageP2  devStageP6 
##   8.1390000  -0.1833333  -1.3750000  -1.3127500  -0.9992500
```
The difference between this test and the last one is that over here P2 and P10 are less significantly different from 4_weeks at 0.05. 



**Q3.Fit a linear model of the expression of 1438786_a_at as a linear model of devStage and gType without interactions. Use the following formula: gExp ~ devStage + gType.**

```r
m3_with  <- lm(gExp ~ devStage + gType, data = mDat)
summary(m3_with)
```

```
## 
## Call:
## lm(formula = gExp ~ devStage + gType, data = mDat)
## 
## Residuals:
##      Min       1Q   Median       3Q      Max 
## -2.20215 -0.38988  0.06986  0.46888  1.18085 
## 
## Coefficients:
##             Estimate Std. Error t value Pr(>|t|)    
## (Intercept)   8.0594     0.3030  26.600  < 2e-16 ***
## devStageE16  -0.1362     0.4043  -0.337 0.738271    
## devStageP10  -1.3286     0.3902  -3.405 0.001754 ** 
## devStageP2   -1.4220     0.3902  -3.644 0.000912 ***
## devStageP6   -0.5935     0.3902  -1.521 0.137771    
## gTypewt       0.6240     0.2504   2.492 0.017894 *  
## ---
## Signif. codes:  0 '***' 0.001 '**' 0.01 '*' 0.05 '.' 0.1 ' ' 1
## 
## Residual standard error: 0.7804 on 33 degrees of freedom
## Multiple R-squared:  0.4685,	Adjusted R-squared:  0.388 
## F-statistic: 5.818 on 5 and 33 DF,  p-value: 0.0005865
```



**Q4.Fit a linear model of the expression of 1438786_a_at as a linear model of devStage and gType with interactions. Use the following formula gExp ~ devStage * gType. Is this model different from the model without interctions?**

```r
m3_without  <- lm(gExp ~ devStage * gType, data = mDat)
summary(m3_without)
```

```
## 
## Call:
## lm(formula = gExp ~ devStage * gType, data = mDat)
## 
## Residuals:
##      Min       1Q   Median       3Q      Max 
## -2.23467 -0.37612  0.03025  0.47862  1.20650 
## 
## Coefficients:
##                     Estimate Std. Error t value Pr(>|t|)    
## (Intercept)          8.13900    0.40360  20.166   <2e-16 ***
## devStageE16         -0.18333    0.61650  -0.297   0.7683    
## devStageP10         -1.37500    0.57077  -2.409   0.0226 *  
## devStageP2          -1.31275    0.57077  -2.300   0.0288 *  
## devStageP6          -0.99925    0.57077  -1.751   0.0906 .  
## gTypewt              0.46475    0.57077   0.814   0.4221    
## devStageE16:gTypewt  0.10233    0.84015   0.122   0.9039    
## devStageP10:gTypewt  0.09275    0.80719   0.115   0.9093    
## devStageP2:gTypewt  -0.21850    0.80719  -0.271   0.7885    
## devStageP6:gTypewt   0.81150    0.80719   1.005   0.3231    
## ---
## Signif. codes:  0 '***' 0.001 '**' 0.01 '*' 0.05 '.' 0.1 ' ' 1
## 
## Residual standard error: 0.8072 on 29 degrees of freedom
## Multiple R-squared:  0.5003,	Adjusted R-squared:  0.3452 
## F-statistic: 3.226 on 9 and 29 DF,  p-value: 0.007869
```
Linear model of devStage and gType with interactions has the signifance of the development stages reduced a little, but not below 0.05.



**Q5. Run an anova comparing the models from questions 3 and 4. Are the models significantly different?**

```r
anova(m3_with, m3_without)
```

```
## Analysis of Variance Table
## 
## Model 1: gExp ~ devStage + gType
## Model 2: gExp ~ devStage * gType
##   Res.Df    RSS Df Sum of Sq     F Pr(>F)
## 1     33 20.097                          
## 2     29 18.895  4    1.2014 0.461 0.7637
```
The models are not significantly different as the P-value is 0.7637.



**Q6.We are now going to create a batch effect and control for it in our analysis using a blocking variable. Run the following code block to create a new data set, bDat, with a batch effect.How has the batch effect changed the result of the test? How is it different from the result of question 4?**


```r
batches = as.character( rep(c("batch1","batch2"),20)[1:39] )
batchEffect = rep( c(0,4),20 )[1:39]
bDat = mDat
bDat$gExp = bDat$gExp + batchEffect 
summary( lm( gExp ~ devStage * gType , data=bDat ) )
```

```
## 
## Call:
## lm(formula = gExp ~ devStage * gType, data = bDat)
## 
## Residuals:
##    Min     1Q Median     3Q    Max 
## -3.568 -2.000 -0.247  2.106  3.815 
## 
## Coefficients:
##                     Estimate Std. Error t value Pr(>|t|)    
## (Intercept)         10.13900    1.29331   7.840  1.2e-08 ***
## devStageE16         -0.85000    1.97557  -0.430    0.670    
## devStageP10         -1.37500    1.82902  -0.752    0.458    
## devStageP2          -1.31275    1.82902  -0.718    0.479    
## devStageP6          -0.99925    1.82902  -0.546    0.589    
## gTypewt              0.46475    1.82902   0.254    0.801    
## devStageE16:gTypewt  0.76900    2.69225   0.286    0.777    
## devStageP10:gTypewt  0.09275    2.58663   0.036    0.972    
## devStageP2:gTypewt  -0.21850    2.58663  -0.084    0.933    
## devStageP6:gTypewt   0.81150    2.58663   0.314    0.756    
## ---
## Signif. codes:  0 '***' 0.001 '**' 0.01 '*' 0.05 '.' 0.1 ' ' 1
## 
## Residual standard error: 2.587 on 29 degrees of freedom
## Multiple R-squared:  0.08919,	Adjusted R-squared:  -0.1935 
## F-statistic: 0.3155 on 9 and 29 DF,  p-value: 0.9633
```

The batch effect has changed the result by making the parameters not significant at any level whatsoever. As compared to Ques.4, P2 and P10 are not significant anymore.



**Q7.Fit a new linear model with the formula gExp ~ devStage * gType + batches using data=bDat. How is this similar to the results of question 4? In this case, batches is our blocking variable. By including batches in the model we can estimate the effect of contamination in our data caused by the difference in batches and get back to testing hypotheses we're really interested in, like the effect of knockouts!**


```r
m7  <- lm(formula = gExp ~ devStage * gType + batches, data = bDat)
summary(m7)
```

```
## 
## Call:
## lm(formula = gExp ~ devStage * gType + batches, data = bDat)
## 
## Residuals:
##     Min      1Q  Median      3Q     Max 
## -2.1465 -0.3621  0.1043  0.3822  1.1745 
## 
## Coefficients:
##                     Estimate Std. Error t value Pr(>|t|)    
## (Intercept)          8.00667    0.42366  18.899  < 2e-16 ***
## devStageE16         -0.13922    0.61759  -0.225   0.8233    
## devStageP10         -1.37500    0.57037  -2.411   0.0227 *  
## devStageP2          -1.31275    0.57037  -2.302   0.0290 *  
## devStageP6          -0.99925    0.57037  -1.752   0.0907 .  
## gTypewt              0.46475    0.57037   0.815   0.4221    
## batchesbatch2        4.26466    0.25944  16.438 6.48e-16 ***
## devStageE16:gTypewt  0.05822    0.84068   0.069   0.9453    
## devStageP10:gTypewt  0.09275    0.80663   0.115   0.9093    
## devStageP2:gTypewt  -0.21850    0.80663  -0.271   0.7885    
## devStageP6:gTypewt   0.81150    0.80663   1.006   0.3230    
## ---
## Signif. codes:  0 '***' 0.001 '**' 0.01 '*' 0.05 '.' 0.1 ' ' 1
## 
## Residual standard error: 0.8066 on 28 degrees of freedom
## Multiple R-squared:  0.9145,	Adjusted R-squared:  0.8839 
## F-statistic: 29.94 on 10 and 28 DF,  p-value: 2.456e-12
```
It is similar to the results of Ques.4 with similar p-values.



**Q8.Run an anova comparing the two formulae gExp ~ devStage + gType + batches and gExp ~ devStage * gType + batches. How are these results similar to that of question 5?**

```r
anova(lm(gExp ~ devStage + gType + batches, data=bDat ), lm(gExp ~ devStage * gType + batches, data=bDat ))
```

```
## Analysis of Variance Table
## 
## Model 1: gExp ~ devStage + gType + batches
## Model 2: gExp ~ devStage * gType + batches
##   Res.Df    RSS Df Sum of Sq      F Pr(>F)
## 1     32 19.431                           
## 2     28 18.218  4    1.2127 0.4659 0.7601
```
As depicted from the P-value, the models are not significantly different.
