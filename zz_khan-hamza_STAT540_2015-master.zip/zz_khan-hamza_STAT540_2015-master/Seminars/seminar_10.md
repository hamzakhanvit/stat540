# seminar10
hamzakhanvit  
Tuesday, March 31, 2015  

```r
options(warn=-1) #Avoiding the display of warnings
# Load required R packages:
suppressMessages(library(ROCR))
suppressMessages(library(CMA))
suppressMessages(library(GEOquery))
suppressMessages(library(lattice))
suppressMessages(library(class))
suppressMessages(library(MASS))
suppressMessages(library(reshape))
suppressMessages(library(car))
suppressMessages(library(limma))
suppressMessages(library(e1071))
suppressMessages(library(glmnet))
```
Loading the dataset

```r
if(file.exists("class_LNstatus.Rdata")) { 
  load("class_LNstatus.Rdata")
} else { 
  datgeo <- getGEO('GSE23177', GSEMatrix = TRUE) 
  dat <- datgeo[[1]]   #Note that dat is an ExpressionSets
  
  str(pData(dat), max.level = 0)
  
  # extract only those variables of interest 
  pData(dat) <-
    subset(pData(dat),
           select = c("characteristics_ch1.2",
                      "characteristics_ch1.3","characteristics_ch1"))
  names(pData(dat))<-c("LnStatus", "LnRatio", "Set")
  
  #Note: LNRatio will not be used in this Seminar. However, you can use it to try some of the regularization techniques learned in class
  
  # split the ExpressionSet into training and test sets. 
  train.es <- dat[, dat$Set == "patient type: training set"]
  test.es <- dat[ , dat$Set != "patient type: training set"]
  
  #Re-labelling factor
  pData(train.es)$LnStatus <- gsub("ln: ", "", pData(train.es)$LnStatus)
  levels(pData(train.es)$LnStatus) <- c('neg', 'pos')
  pData(test.es)$LnStatus <- gsub("ln: ", "", pData(test.es)$LnStatus)
  levels(pData(test.es)$LnStatus) <- c('neg', 'pos')
  
  # creating data matrices with expression values (probesets in rows).
  trainDat <- exprs(train.es)
  testDat <- exprs(test.es)
  
  # Redefining the quantitative variable LnRatio to make it a numeric variable.
  ntrain <- dim(pData(train.es))[1]
  ntest <- dim(pData(test.es))[1]
  
  pData(train.es)$LnRatio <- as.numeric(unlist(strsplit(as.vector(unlist(pData(train.es)$LnRatio)), ":", fixed = TRUE))[(1:ntrain)*2])
  pData(test.es)$LnRatio <- as.numeric(unlist(strsplit(as.vector(unlist(pData(test.es)$LnRatio)), ":", fixed = TRUE))[(1:ntest)*2])
  
  # saving the data to avoid future re-downloading
  save(dat,trainDat,testDat,train.es,test.es, file = "class_LNstatus.Rdata")
}

options(stringsAsFactors = TRUE)
```
Time for some Exploratory data analyses

```r
table(pData(train.es)$LnStatus)
```

```
## 
## neg pos 
##  48  48
```

```r
table(pData(test.es)$LnStatus)
```

```
## 
## neg pos 
##   9  11
```

```r
tapply(pData(train.es)$LnRatio,pData(train.es)$LnStatus,summary)
```

```
## $neg
##    Min. 1st Qu.  Median    Mean 3rd Qu.    Max. 
##       0       0       0       0       0       0 
## 
## $pos
##    Min. 1st Qu.  Median    Mean 3rd Qu.    Max. 
##  0.0400  0.0700  0.1100  0.1935  0.2275  0.9600
```

```r
tapply(pData(test.es)$LnRatio,pData(test.es)$LnStatus,summary)
```

```
## $neg
##    Min. 1st Qu.  Median    Mean 3rd Qu.    Max. 
##       0       0       0       0       0       0 
## 
## $pos
##    Min. 1st Qu.  Median    Mean 3rd Qu.    Max. 
##  0.0500  0.1800  0.5000  0.4573  0.6100  0.9400
```

```r
set.seed(1234)
(getMe <- sample(1:nrow(train.es), size = 3)) 
```

```
## [1]  2756 15082 14766
```

```r
trDat <- trainDat[getMe, ]

trDat <- data.frame(LnStatus=pData(train.es)$LnStatus, Set=rep("train",nrow(pData(train.es))),t(trDat))
plotDat.train <- melt(trDat, id=c("LnStatus","Set"),variable_name="gene")
colnames(plotDat.train)[colnames(plotDat.train)=="value"]="gExp"

tDat <- testDat[getMe, ]
tDat <- data.frame(LnStatus=pData(test.es)$LnStatus,Set=rep("test",nrow(pData(test.es))), t(tDat))
plotDat.test <- melt(tDat, id=c("LnStatus","Set"),variable_name="gene")
colnames(plotDat.test)[colnames(plotDat.test)=="value"]="gExp"

plotDat <- rbind(plotDat.train,plotDat.test)

stripplot(gExp ~ LnStatus | gene+Set, plotDat,
grid = TRUE,
group = LnStatus, auto.key = TRUE,
jitter.data = TRUE)
```

![](seminar_10_files/figure-html/unnamed-chunk-4-1.png) 
#Classification - 
Feature and model selection

```r
nfold <- 6
tabTrain <- table(train.es$LnStatus)
indlist <- sapply(names(tabTrain), function(z) which(train.es$LnStatus == z), simplify = FALSE)
set.seed(1234)

fold.pos <- matrix(sample(indlist[["pos"]]),nrow=nfold)
fold.neg <- matrix(sample(indlist[["neg"]]),nrow=nfold)
splits <- GenerateLearningsets(y = train.es$LnStatus, method="CV", fold=nfold, strat= TRUE)
```

# Take-home exercise

**Exercise 1: perform 100 runs of this CV before selecting a model to test! Add at least on model to the list of models, e.g., use genes with a p-val threshold < cutoff.**

```r
ngenes <- 50
nmethod <- 8
nruns <- 100

pr.err <- matrix(-1, nfold * nruns,nmethod, dimnames=list(paste0("Fold",1:600),c("1NN","5NN","10NN", "15NN","LDA","Logit","SVM","NNPval")))

for (key in 0:nruns-1) {
  for(i in 1:nfold){
    index <- nfold * key + i
    train.index <- sample(seq_len(nrow(trainDat)), (nfold - 1) / nfold)
    
    #Test Fold for the i-th step
    testdat.fold<-trainDat[,c(fold.pos[i,],fold.neg[i,])]
    #creating a factor of classes for the test set of the i_th fold
    testclass.fold<-train.es$LnStatus[c(fold.pos[i,],fold.neg[i,])]
    
     #The rest of the samples are the training set for the i-th step
    traindat.fold<-trainDat[,-c(fold.pos[i,],fold.neg[i,])]
    trainclass.fold<-train.es$LnStatus[-c(fold.pos[i,],fold.neg[i,])]
  
    #Feature selection
    limma.dat<-as.data.frame(traindat.fold)
    desMat <- model.matrix(~ trainclass.fold, limma.dat) #design matrix
    trainFit <- lmFit(limma.dat, desMat)
    eBtrainFit <- eBayes(trainFit)
    
    #Have a look at top 50 limma genes
    top.fold <- topTable(eBtrainFit, coef = which(colnames(coef(trainFit)) != "(Intercept)"),
                         n = ngenes, sort.by="P")
    
    #Retaining the top-50 limma genes from the train and test sets
    traindat.fold <- traindat.fold[rownames(top.fold),]
    testdat.fold <-  testdat.fold[rownames(top.fold),]

    top.five.fold <- topTable(eBtrainFit, coef = which(colnames(coef(trainFit)) != "(Intercept)"),
                        p.value = 0.05, n = ngenes, sort.by="P")
    
    traindat.five.fold <- traindat.fold[rownames(top.five.fold),]
    testdat.five.fold <-  testdat.fold[rownames(top.five.fold),]
    
    yhat.knn <- knn(train=t(traindat.five.fold), test=t(testdat.five.fold), cl=trainclass.fold,
                    k = 10)
    pr.err[index,"NNPval"]<- mean(testclass.fold != yhat.knn)
    
    
    #lets select a classifier
    l <- 0
    
    #Knn classifiers
    for(kk in c(1,5,10,15)) {
      l <- l+1
      
      #Samples in rows for knn
      yhat.knn <- knn(train=t(traindat.fold), test=t(testdat.fold), cl=trainclass.fold,
                      k = kk)
      
      #Storing the prediction error for each kk within this fold
      pr.err[index,l]<- mean(testclass.fold != yhat.knn)
    }
    
    m.lda <- lda(x=t(traindat.fold), group=trainclass.fold, prior=c(.5, .5))
    yhat.lda <- predict(m.lda, newdata=t(testdat.fold))$class
    pr.err[index,"LDA"] <-mean(testclass.fold != yhat.lda)
    
    glm.dat <- data.frame(t(traindat.fold), group=trainclass.fold)
    
    m.log <- glmnet( t(traindat.fold) , trainclass.fold ,family="binomial") 
    
    pr.log <- predict(m.log,newdata=data.frame(t(testdat.fold)),type="response",newx=t(testdat.fold)) 
    
    pr.cl <- rep(0,length(testclass.fold))
    pr.cl[pr.log > 1/2] <- "pos"
    pr.cl[pr.log <= 1/2] <- "neg"
    
    pr.cl <- factor(pr.cl)
    pr.err[index,"Logit"] <- mean( pr.cl != testclass.fold )
    
    #SVM
    m.svm <- svm(x=t(traindat.fold), y=trainclass.fold, cost=1, type="C-classification", 
                 kernel="linear")
    pr.svm <- predict(m.svm,newdata=t(testdat.fold)) 
    
    pr.err[index,"SVM"] <- mean( pr.svm != testclass.fold )
  } 
}
```
Error Rates

```r
cv.err <- colMeans(pr.err)
ls <- cv.err - apply(pr.err, 2, sd)
us <- cv.err + apply(pr.err, 2, sd)

#plotting the results
plot(1:nmethod, cv.err, ylim=c(0, 1), xlim=c(1, (nmethod+.5)),type='n', 
     axes=FALSE, xlab='Classifier', ylab='Error rate',main="6-fold CV Error")

for(i in 1:nmethod)
  lines(c(i, i), c(ls[i], us[i]), lwd=2, col='gray')
points(1:nmethod, ls, pch=19, col='red')
points(1:nmethod, us, pch=19, col='green')
points(1:nmethod, cv.err, pch=19, cex=1.5, col='black')
axis(2, ylab='Error rate')
axis(1, 1:nmethod, colnames(pr.err))
box()
abline(h=0.4)
```

![](seminar_10_files/figure-html/unnamed-chunk-7-1.png) 

10NN and 1NN looks better than the others. 

**Exercise 2: Use AUC as a criteria to select a model based on the training data! Tip: extract the predicted probabilities from each method and use the roc function in ROCR.**

```r
m=matrix(which(dat$Set=="patient type: training set"), 1)
learningsets = new("learningsets", learnmatrix = m, method="seminar10", ntrain=96, iter=1)
top_genes = GeneSelection(X=t(exprs(dat)), y = as.factor(dat$LnStatus), learningsets = learningsets, method = "t.test")
```

```
## GeneSelection: iteration 1
```

```r
for(k in c(1,5,10,15)) {
  KNN <- classification(X=t(exprs(dat)), y = as.factor(dat$LnStatus), learningsets = learningsets, genesel = top_genes, nbgene = 100, classifier = pknnCMA, k = k)
  
  print(paste0("For k = ", k))
  roc(KNN[[1]])
}
```

```
## iteration 1 
## [1] "For k = 1"
```

![](seminar_10_files/figure-html/unnamed-chunk-8-1.png) 

```
## iteration 1 
## [1] "For k = 5"
```

![](seminar_10_files/figure-html/unnamed-chunk-8-2.png) 

```
## iteration 1 
## [1] "For k = 10"
```

![](seminar_10_files/figure-html/unnamed-chunk-8-3.png) 

```
## iteration 1 
## [1] "For k = 15"
```

![](seminar_10_files/figure-html/unnamed-chunk-8-4.png) 

```r
model <- classification(X=t(exprs(dat)), y = as.factor(dat$LnStatus), learningsets = learningsets, genesel = top_genes, nbgene = 100, classifier = ldaCMA)
```

```
## iteration 1
```

```r
print("Method Used: ldaCMA")
```

```
## [1] "Method Used: ldaCMA"
```

```r
roc(model[[1]])
```

![](seminar_10_files/figure-html/unnamed-chunk-8-5.png) 

```r
model <- classification(X=t(exprs(dat)), y = as.factor(dat$LnStatus), learningsets = learningsets, genesel = top_genes, nbgene = 100, classifier = dldaCMA)
```

```
## iteration 1
```

```r
print("Method Used: dldaCMA")
```

```
## [1] "Method Used: dldaCMA"
```

```r
roc(model[[1]])
```

![](seminar_10_files/figure-html/unnamed-chunk-8-6.png) 

No classifiers are better than 0.505 AUC. 10NN and 15NN look fine.

**Discussion Points**
Performance and cut-off relations could be depicted with the help of an MCC vs cutoff plot. 
As far as specificity is concerned, a very low specificity might give rise to a lot of predictions, thereby making experimental validation more difficult.
The incidence of lymph-node-positive breast cancer could be regarded as sensitivity. Considering the ROC curve above, 33% sensitivity corresponds to  specificity of around 25%, which might be difficult to validate.
