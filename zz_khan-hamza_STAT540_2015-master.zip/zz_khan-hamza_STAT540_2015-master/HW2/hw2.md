# Home work 2
hamzakhanvit  
Sunday, March 22, 2015  


###Q1) Microarray Analysis

**The six samples in this study, 3 replicates for each of the two conditions, were analysed on the Affymetrix Yeast Genome Array 2.0 platform. We have already downloaded the raw CEL files from GEO and normalised them. The normalized data is saved in the file [`GSE37599-data.tsv`](https://raw.githubusercontent.com/STAT540-UBC/STAT540-UBC.github.io/master/examples/yeastPlatforms/data/GSE37599-data.tsv)**


```r
options(warn=-1) #Avoiding the display of warnings
# Load required R packages:
suppressMessages(library(dplyr))
suppressMessages(library(pheatmap))
library(hexbin)
suppressMessages(library(gplots))
library(RColorBrewer)
library(limma)
library(pander)
library(testthat)
library(reshape2)
library(lattice)
library(tidyr)
suppressMessages(library(knitr))
suppressMessages(library(magrittr))
suppressMessages(library(yeast2.db))
library(edgeR)
suppressMessages(library(DESeq))
suppressMessages(library(VennDiagram))
suppressMessages(library(ggplot2))
```
####Q1a) Load Microarray Data

**Load the normalized data** 


```r
dat <- read.table("GSE37599-data.tsv.txt", row.names = 1, header = TRUE)
str(dat)
```

```
## 'data.frame':	10928 obs. of  6 variables:
##  $ b1: num  11.15 2.16 1.49 9.01 6.95 ...
##  $ b2: num  6.8 3.18 1.43 9.46 6.9 ...
##  $ b3: num  6.71 3.13 1.82 9.23 6.96 ...
##  $ c1: num  10.95 2.5 1.46 8.97 6.85 ...
##  $ c2: num  6.7 3.05 2.08 9.28 6.9 ...
##  $ c3: num  11.07 2.44 1.62 9 6.89 ...
```

**What are dimensions of the dataset? In addition to reporting number of rows and columns, make it clear what rows and columns represent and how you're interpreting column names.**

```r
ncol(dat)
```

```
## [1] 6
```

```r
nrow(dat)
```

```
## [1] 10928
```
There are 6 columns (each representing a sample) and 10928 rows(each representing a probe) of the dataset. 


```r
head(dat,1)
```

```
##                  b1       b2       b3       c1       c2       c3
## 1769308_at 11.14551 6.795593 6.708003 10.94588 6.698862 11.07073
```
The first letter in the column name refers to the condition ,i.e.,batch or  chemostat, and the following number refers to the replicate to which the sample belongs.

####Q1b) Identify Sample Swap

**The labels on two of the samples have been swapped, that is one of the batch samples has been labelled as chemostat and vice-versa. Produce the plots described below and explain how they allow you to identify the swapped samples.**
  
####i.(High volume) scatter plot matrix. 

```r
splom(dat, panel = panel.smoothScatter)
```

![](hw2_files/figure-html/unnamed-chunk-5-1.png) 

By closely observing the above scatter plot, one can infer that b1 is swapped with c2. b1 and c2 show better correlation (less scatter) with samples belonging to the opposite condition as compared to the samples of its labeled condition.

####ii. A heatmap of the first 100 genes.

```r
pheatmap(dat[1:100,],
         color = colorRampPalette(c("white", "red"))(n = 299),
         cluster_rows = FALSE, cluster_cols = FALSE,
         height = 10, width = 5 )
```

![](hw2_files/figure-html/unnamed-chunk-6-1.png) 

We can clearly see that b1,c1 and c3 hold a similar expression pattern, therefore advocating the fact that b1 and c2 are swapped. 

####iii. Compute the Pearson correlation of the samples and plot the results using a heatmap.

```r
#My color schemes
reds <- colorRampPalette(brewer.pal(n = 9, "Reds"))
greys <- colorRampPalette(brewer.pal(n = 9, "Greys"))


#My little heatmap function
myheatmap <- function(x, ...){
  heatmap.2(x, 
            Rowv = FALSE, dendrogram="none",
            symm=TRUE, trace="none", scale="none", 
            col = reds(256))
}
#Computing correlation
sampleCor <- cor(dat)
myheatmap(sampleCor)
```

![](hw2_files/figure-html/unnamed-chunk-7-1.png) 

As depicted by the heatmap legend, dark color means strong correlations between that set of pair and vice versa. It can be seen that b1 is more correlated with c1 and c3, whereas c2 is more correlated with b3 and b2. Therefore, one can infer that b1 and c2 are swapped.

####iv. Scatterplot the six data samples with respect to the first two principal components and label the samples.

```r
p <- prcomp(dat, center = F, scale = F)
pDat <- data.frame(p$rotation[, 1:2])
pDat$samples <- rownames(pDat)

#My tiny scatterplot function
myscatterplot = function(a){
ggplot(a, aes(x = PC1, y = PC2, colour = samples, label = samples)) + geom_point() + geom_text(hjust = 0.5, vjust = 2, size = 3)+ ggtitle("Scatterplot of the 6 data samples with respect to the first two P.C. ")
}
myscatterplot(pDat)
```

![](hw2_files/figure-html/unnamed-chunk-8-1.png) 

The scatterplots clearly depicts the swap.

#### Q1c) Microarray Differential Expression

**Fix the label swap identified in question 1b. We want to swap b1 <--> c2. Revisit one or more elements of question 1b to sanity check before proceeding.**

As of now, this is how our data looks like:

```r
head(dat)
```

```
##                   b1       b2       b3        c1       c2        c3
## 1769308_at 11.145506 6.795593 6.708003 10.945878 6.698862 11.070725
## 1769309_at  2.164329 3.177408 3.128950  2.498308 3.047169  2.444188
## 1769310_at  1.488300 1.427200 1.815698  1.462075 2.079007  1.623036
## 1769311_at  9.006138 9.461821 9.234618  8.972233 9.276710  9.004997
## 1769312_at  6.945715 6.895895 6.955463  6.851454 6.900187  6.892854
## 1769313_at  7.815192 6.600131 6.534413  7.770245 6.564123  7.851777
```
Lets swap b1 and c2:

```r
swap <- c("b1", "c2")
names(dat)[match(swap, names(dat))] <- rev(swap)
head(dat)
```

```
##                   c2       b2       b3        c1       b1        c3
## 1769308_at 11.145506 6.795593 6.708003 10.945878 6.698862 11.070725
## 1769309_at  2.164329 3.177408 3.128950  2.498308 3.047169  2.444188
## 1769310_at  1.488300 1.427200 1.815698  1.462075 2.079007  1.623036
## 1769311_at  9.006138 9.461821 9.234618  8.972233 9.276710  9.004997
## 1769312_at  6.945715 6.895895 6.955463  6.851454 6.900187  6.892854
## 1769313_at  7.815192 6.600131 6.534413  7.770245 6.564123  7.851777
```
Lets just reorder the data in ascending order:

```r
dat <- dat[, order(colnames(dat))]
head(dat)
```

```
##                  b1       b2       b3        c1        c2        c3
## 1769308_at 6.698862 6.795593 6.708003 10.945878 11.145506 11.070725
## 1769309_at 3.047169 3.177408 3.128950  2.498308  2.164329  2.444188
## 1769310_at 2.079007 1.427200 1.815698  1.462075  1.488300  1.623036
## 1769311_at 9.276710 9.461821 9.234618  8.972233  9.006138  9.004997
## 1769312_at 6.900187 6.895895 6.955463  6.851454  6.945715  6.892854
## 1769313_at 6.564123 6.600131 6.534413  7.770245  7.815192  7.851777
```
Okay! Lets now verify our changes visually - 

```r
splom(dat, panel = panel.smoothScatter)
```

![](hw2_files/figure-html/unnamed-chunk-12-1.png) 

Looks good. Now, b1,b2,b3 are more correlated. So are c1,c2,c3.
Lets see how the heapmaps look like - 

```r
sampleCor <- cor(dat)
myheatmap(sampleCor)
```

![](hw2_files/figure-html/unnamed-chunk-13-1.png) 

Now the scatterplot - 

```r
p <- prcomp(dat, center = F, scale = F)
pDat <- data.frame(p$rotation[, 1:2])
pDat$samples <- rownames(pDat)
myscatterplot(pDat)
```

![](hw2_files/figure-html/unnamed-chunk-14-1.png) 

Everything looks fixed now. 

**Now use this data to do a differential expression analysis with `limma`.**

```r
#My little function to make a design matrix
createDesign <- function(dat, chemoLabels){
  sampleLabels <- colnames(dat)
  conditions <- factor(rep("batch", length(sampleLabels)),
                       levels=c("batch", "chemostat"))
  conditions[sampleLabels %in% chemoLabels] <- "chemostat"
  des <- data.frame(condition=conditions)
  rownames(des) <- sampleLabels  
  return(des)
} 

sampleLabels <- colnames(dat)
chemoSmpls <- grep("c", sampleLabels, value=TRUE)

#Using the createDesign function to make a design matrix
design <- createDesign(dat, chemoLabels=chemoSmpls)
```
So, lets make our model matrix and fit our linear model

```r
desMat <- model.matrix(~condition, design)
mcEBFit <- eBayes(lmFit(dat, desMat))
dtm <- topTable(mcEBFit, number=Inf, adjust.method="BH",
                 coef = grep("condition", colnames(desMat)))
```
**Package these results in a data frame with six columns:**

**a) probe.id - The array probe id.**

**b) gene.id - The id of the gene which the probe overlaps (see below).**

**c) p.value - The raw p-value for the probe.**

**d) q.value - The BH corrected p-value, aka the q-value.**

**e) log.fc - The log fold change which is the column called "logFC" in the limma results table.**

**f) test.stat - The test statistics which for limma is the moderated t statistic. This is the column called "t" in the limma results table.**

**The gene id can be retrieved using the `yeast2.db` package from Bioconductor (i.e., you need to use `biocLite()` function to load it). In particular, the `yeast2ORF` object available after loading `yeast2.db` contains the mapping between probe IDs and yeast gene ids. Assuming you have a character vector of probes called `probe.ids`, the gene IDs can be retrieved using `gene.ids <- unlist(mget(probe.ids, yeast2ORF))`.**


```r
# gene names sorted by toptable result above
genes <- unlist(mget(rownames(dtm), yeast2ORF))
expect_equal(names(genes), rownames(dtm))

dtm <- dtm[, c("P.Value", "adj.P.Val", "logFC", "t")]
colnames(dtm) <- c("p.value", "q.value", "log.fc", "test.stat")
dtm <- cbind(probe.id=rownames(dtm), gene.id=genes, dtm)
```
**Remove any rows with probes which don't map to genes. You'll be able to find these because they will have `NA` as their gene id. Work with this data.frame to answer the questions below.**


```r
dtm <- dtm[!is.na(dtm$gene.id),]
```


**i. How many probes did we start with and how many remain after removing probes without gene ids?**

Before : 

```r
nrow(dat)
```

```
## [1] 10928
```

After : 

```r
nrow(dtm)
```

```
## [1] 5705
```
We initially started with 10928 probes and 5705 remained after removing probes without gene ids.



**ii. Illustrate the differential expression between the batch and the chemostat samples for the top hit (i.e., probe with the lowest p- or q-value).**


```r
#Testing whether rownames of design and column names of dat are equal or not
expect_equal(rownames(design), colnames(dat))
```
My little prepare data function

```r
prepareDataMC <- function(probeId){
  probeDat <- dat[rownames(dat)==probeId,]
  newDat <- cbind(design, t(probeDat))
  # If in case of multiple probes selected
  newDat <- melt(newDat, "condition", variable_name="probe.id")
  newDat <- rename(newDat, c("value"="expression"))  # rename column
  return(newDat)
}
```
Storing the top hits id and data

```r
topHitPid <- dtm[1,"probe.id"]
topHitDat <- prepareDataMC(topHitPid)
```

Lets plot it now - 

```r
p <- ggplot(topHitDat, aes(x=condition, y=expression, color=condition)) 
p <- p + geom_point()
p
```

![](hw2_files/figure-html/unnamed-chunk-24-1.png) 

One can notice that top hits show less difference within group(condition) and large difference between groups(conditions). 


**iii. How many probes are identified as differentially expressed at a false discovery rate (FDR) of 1e-5 (note: this is a FDR cutoff used in the original paper)?**


```r
(nHits <- sum(dtm$q.value <= 1e-5))
```

```
## [1] 725
```

725 probes are identified as differentially expressed at an FDR of 1e-5.

**iv. Save your results for later with `write.table()`. When using write.table to save the data, you need to pass the arguments `row.names = TRUE, col.names = NA` to make sure the headers are written correctly.**


```r
write.table(dtm, "condition.topTable.GSE37599.tsv",
            row.names = TRUE, col.names = NA, sep="\t")
```
### Q2) RNA-Seq Analysis

**We have aligned the RNA-Seq library using the [Stampy](http://www.well.ox.ac.uk/project-stampy) aligner and generated count data. This particular RNA-Seq dataset was sequenced to quite a high depth. The data file is available as [stampy.deep.counts.tsv](https://raw.githubusercontent.com/STAT540-UBC/STAT540-UBC.github.io/master/examples/yeastPlatforms/data/stampy.deep.counts.tsv). In this question you will use this data to do a differential expression analysis using different packages from Bioconductor.**

####a)Load RNA Count Data and Sanity Check


```r
rcDat <- read.table("stampy.deep.counts.tsv.txt", 
                    header=TRUE, row.names=1)
rcDat <- rcDat[, rownames(design)]  # Sanity checking that the sample (column) order matches the design
```

**i) What are dimensions of the dataset? In addition to reporting number of rows and columns, make it clear what rows and columns represent. What is the difference between the rows of this dataset versus rows of the array data in question 1a?**

```r
dim(rcDat)
```

```
## [1] 6542    6
```
This dataset has 6542 rows and 6 columns. Rows represent  genes and column represent a sample. Here we have genes for the rows instead of probes as in the case of microarray data. Instead of gene expression, RNA-seq count data has number of reads that are mapped to genes.


**ii) Do a sanity check to make sure there is no sample swap by plotting a heatmap of the sample correlations.**


```r
sampleCor <- cor(rcDat)
myheatmap(sampleCor)
```

![](hw2_files/figure-html/unnamed-chunk-29-1.png) 

Samples B1, B2 and B3 cluster together. Samples C1, C2 and C3 cluster together. Since samples are strongly correlated within same condition, and less correlated between different conditions, no swaps seems to have occured.

### b)voom Differential Expression Analysis

**Use `voom+limma` to identify differentially expressed genes between the batch medium vs. chemostat conditions.**

**i)  `voom` normalizes the counts before it converts counts to log2-cpm. Use `calcNormFactors` to normalize counts.**


```r
norm.factor <- calcNormFactors(rcDat)
lib.size <- colSums(rcDat)*norm.factor
```


**ii)  Use `voom' to convert count data into logged CPM data and then use 'limma' to identify differentially expressed genes between conditions.**

The gene-wise square-root residual standard deviations Vs average log-count plot by voom looks like - 

```r
dat.voomed <- voom(rcDat, desMat, plot=TRUE,lib.size=lib.size)
```

![](hw2_files/figure-html/unnamed-chunk-31-1.png) 

I believe that there is moderate level variation.Larger count sizes have lower variance.

```r
voom.fit <- eBayes(lmFit(dat.voomed, desMat))
voom.results <- topTable(voom.fit, number=Inf, adjust.method="BH",
                   coef = grep("condition", colnames(desMat)))
```

**Package these results in a data.frame called 'voom.limma.results' with five columns:**
**Save your results for later with `write.table()` in file called `stampy.limma.results.tsv`.**


```r
voom.results <- voom.results[, c("P.Value", "adj.P.Val", "logFC", "t")]
colnames(voom.results) <- c("p.value", "q.value", "log.fc", "test.stat")
voom.results <- cbind(gene.id=rownames(voom.results), voom.results)
```

**iii) How many genes are differentially expressed between conditions at a false discovery rate (FDR) of 1e-5?**


```r
fdr <- 1e-5
getHitsGeneId <- function(results, fdr=1e-5){
  isDiff <- (results$q.value <= fdr)
  return(results$gene.id[isDiff])
}

voomHitGenes <- getHitsGeneId(voom.results)
length(voomHitGenes)
```

```
## [1] 1794
```
Or

```r
sum(voom.results$q.value < 1e-5)
```

```
## [1] 1794
```

1794 genes are differentially expressed between conditions at a false discovery rate (FDR) of 10^{-5}.


**iv)Save your results for later with write.table() in file called stampy.deep.limma.results.tsv.**

Lets see how it looks before we save it.

```r
pandoc.table(head(voom.results), style="rmarkdown")
```

```
## 
## 
## |    &nbsp;     |  gene.id  |  p.value  |  q.value  |  log.fc  |
## |:-------------:|:---------:|:---------:|:---------:|:--------:|
## |  **YAL054C**  |  YAL054C  | 3.504e-18 | 2.292e-14 |  6.822   |
## |  **YDR384C**  |  YDR384C  | 2.665e-17 | 7.179e-14 |  4.509   |
## |  **YDR345C**  |  YDR345C  | 4.39e-17  | 7.179e-14 |  -3.991  |
## |  **YDR256C**  |  YDR256C  | 3.515e-17 | 7.179e-14 |  5.311   |
## |  **YKR009C**  |  YKR009C  | 8.939e-17 | 1.17e-13  |  5.264   |
## |  **YIL155C**  |  YIL155C  | 3.128e-16 | 2.926e-13 |  4.798   |
## 
## Table: Table continues below
## 
##  
## 
## |    &nbsp;     |  test.stat  |
## |:-------------:|:-----------:|
## |  **YAL054C**  |    67.85    |
## |  **YDR384C**  |    58.15    |
## |  **YDR345C**  |   -55.99    |
## |  **YDR256C**  |    56.94    |
## |  **YKR009C**  |    53.04    |
## |  **YIL155C**  |    48.22    |
```
Now, I can save it -

```r
write.table(voom.results, "stampy.deep.limma.results.tsv", 
            row.names=TRUE, col.names=NA, quote=FALSE, sep="\t")
```

### Q3) Compare DEA results between RNA-Seq and array

#### Q3a)Comparing volumes of DE genes 
**In this question, you will examine the difference between the q-values from both analyses (i.e., array and `voom+limma`) by overlaying density plots of the q-values from each analysis.**

####Following are the plots that include the densities of q-values of the genes analyzed by both platforms (i.e., genes shared by both data frames)


```r
arrVsVoom <- rbind(cbind(dtm[, c("gene.id","q.value")],
                          platform="Microarray+limma"),
                    cbind(voom.results[, c("gene.id","q.value")],
                          platform="RNA-seq+Voom"))

arrVoomBothGenes <- intersect(dtm$gene.id, voom.results$gene.id)


p <- ggplot(subset(arrVsVoom, gene.id %in% arrVoomBothGenes),
            aes(x=q.value, color=platform)) + geom_density()
p 
```

![](hw2_files/figure-html/unnamed-chunk-38-1.png) 

In order to have a closer look at the peaks of the density plot of q-value, let's square root transform the q-values for a better resolution.

```r
p <- ggplot(subset(arrVsVoom, gene.id %in% arrVoomBothGenes),
            aes(x=sqrt(q.value), color=platform)) + geom_density()
p
```

![](hw2_files/figure-html/unnamed-chunk-39-1.png) 


####Following are the plots that includes the densities of q-values of ALL genes analyzed by at least one of the platforms - 


```r
p <- ggplot(arrVsVoom, aes(x=q.value, color=platform)) + 
  geom_density()
p 
```

![](hw2_files/figure-html/unnamed-chunk-40-1.png) 

Again, I'll do the square root transformation of q-values for a better resolution of the peaks

```r
p <- ggplot(arrVsVoom, aes(x=sqrt(q.value), color=platform)) + 
  geom_density()
p 
```

![](hw2_files/figure-html/unnamed-chunk-41-1.png) 

**Make some observations about the strengths of these two platforms.**

Array gives more number of hits compared to RNA seq analyses, but they could also be false positives.
In all of these plots, RNA-Seq has its peak of q-value density plot shifted to the left. Besides, more area seems to be concentrated near zero in RNA-seq and thus a higher probablity is concentrated at lower q-values. This indicates that RNA-seq is a more powerful test for differential analysis.

#### Q3b) Plots
**Plot the gene expression (i.e., from array data) and the logged counts (i.e., from RNA-Seq data) of: two interesting genes identified as DE by both analyses; one DE gene identified as DE only in the array analysis; one DE gene only in the `voom+limma` analysis; one boring gene in both analyses (i.e., 5 genes total measured with 2 platforms)**

Lets separate the hits and misses in our gene list for each of the above mentioned methods- 


```r
dtm <- na.omit(dtm)
misses <- with(dtm, gene.id[q.value > 1e-5])
hits.voom <- with(voom.results, gene.id[q.value < 1e-5])
hits <- with(dtm, gene.id[q.value < 1e-5])
misses.voom <- with(voom.results, gene.id[q.value > 1e-5])
```

Now lets intersect and get our genes of interest into a dataframe.

```r
hhv <- intersect(hits, hits.voom)
mvhhv <- intersect(misses.voom, setdiff(hits, hits.voom))
mhvh <- intersect(misses, setdiff(hits.voom, hits))
mmv  <- intersect(misses, misses.voom)
genes <- c(hhv[1:2],
           mvhhv[1],
           mhvh[1],
           mmv[1])
```


```r
Property <- c("DE by both analyses", "DE by both analyses", "DE only in ARRAY  analyses", " DE only in voom+limma analyses", "Boring gene in both analyses")
display.table <- cbind(genes,Property)
kable(display.table, format = "markdown")
```



|genes   |Property                        |
|:-------|:-------------------------------|
|YIL057C |DE by both analyses             |
|YOR388C |DE by both analyses             |
|YJL037W |DE only in ARRAY  analyses      |
|YOR227W | DE only in voom+limma analyses |
|YGR036C |Boring gene in both analyses    |

Now, lets extract the gene values, make a dataframe and a plot.

```r
gene.dat <- list(
    array=dat[match(genes, unlist(mget(rownames(dtm), yeast2ORF))),],
    count=rcDat[match(genes, rownames(rcDat)),])

gene.property <- factor(c("Both", "Both", "Only.Array", "Only.Counts", "Boring"),
                   levels=c("Both", "Only.Array", "Only.Counts", "Boring"))
gene.dat <- lapply(gene.dat, cbind, gene=genes, gene.property=gene.property)
gene.dat <- mapply(cbind, gene.dat, data.type=names(gene.dat), SIMPLIFY=FALSE)
gene.dat <- lapply(gene.dat, melt, id.vars=c("gene", "gene.property", "data.type"), variable.name="sample")
gene.dat <- as.data.frame(do.call(rbind, gene.dat))
gene.dat$gene <- factor(gene.dat$gene, levels=genes)

gene.dat$cond <- factor(substr(gene.dat$sample, 1, 1), levels=c("b", "c"),
                              labels=c("batch", "chemostat"))

#Subsetting on the basis of array and count.
gene.dat.array <- subset(gene.dat, grepl("array", gene.dat$data.type))

gene.dat.count <- subset(gene.dat, grepl("count", gene.dat$data.type))
```
Now, I'll plot these 5 genes showing expression levels in one plot and log counts in the other. Mean values can be seen on the plots for a better comparison.

```r
ggplot(gene.dat.array, aes(x = cond, y = value, color=gene.property)) + geom_point() +
         facet_wrap(data.type~gene, scales = "free", ncol = 2) +
         stat_summary(aes(group=1), fun.y=mean, geom="line") +
         xlab("Treatment") + ylab("Gene expression")+stat_summary(aes(label=round(..y..,2)), fun.y=mean, geom="text", size = 3, hjust = 1.3) + labs(title ="Microarray gene expression for all the 5 genes as per the question")
```

![](hw2_files/figure-html/unnamed-chunk-46-1.png) 


```r
ggplot(gene.dat.count, aes(x = cond, y = value, color=gene.property)) + geom_point() +
         facet_wrap(data.type~gene, scales = "free", ncol = 2) +
         stat_summary(aes(group=1), fun.y=mean, geom="line") +
         xlab("Treatment") + ylab("Count")+stat_summary(aes(label=round(..y..,2)), fun.y=mean, geom="text", size = 3, hjust = 1.3)+ labs(title ="RNA seq-data Logged Counts for all the 5 genes as per the question")
```

![](hw2_files/figure-html/unnamed-chunk-47-1.png) 

  + As expected, the interesting genes, ie; YILO5C and YOR388C show contrasting differences in gene expression and logged counts for batch and chemostat conditions in both analyses.
  + YJL037W shows DE in only microarray analysis with contrasting differences in gene expression. It doesn't show much difference in logged counts.
  + YOR227W shows DE in only logged counts with contrasting differences in gene expression. 
  + YGR036C doesn't show much difference amongst gene expression and log counts in both the analyses.

### Q4: Deep vs low sequencing

**In this question you will analyze deep and low depth count data with two different methods, voom+limma and dgeR. The goal is to examine the effect of sequencing depth in DEA and to see if these methods are equally robust to this effect.**

#### Q4a) voom+limma DEA of low sequencing data

**In Q2b you analyzed deep count data using `voom+limma`. You will now repeat the analysis on the low sequencing data.**

i) Loading the low depth count data 

```r
low.counts.dat <- read.table("stampy.low.counts.tsv.txt", header = T, row.names = 1)
dim(low.counts.dat)
```

```
## [1] 7126    6
```
  + Dataset has 7126 rows and 6 columns.
  + Columns are samples of different conditions (batch or chemostat) with 3 replicates. 
  + Rows are gene names.

ii) Repeating Q2b-i and Q2b-ii for this new data.


```r
norm.low <- calcNormFactors(low.counts.dat)
lib.size = colSums(low.counts.dat)*norm.low
voom.low.counts.dat <- voom(low.counts.dat, desMat, plot=TRUE, lib.size) 
```

![](hw2_files/figure-html/unnamed-chunk-49-1.png) 

```r
voom.low.fit <- lmFit(voom.low.counts.dat, desMat)
voom.low.ebFit <- eBayes(voom.low.fit)
voom.low.topTable <- topTable(voom.low.ebFit, n = Inf)
```

```
## Removing intercept from test coefficients
```
Packaging these results in a data.frame called voom.limma.low.results with five columns as in Q2b.

```r
voom.limma.low.results <- data.frame(gene.id = rownames(voom.low.topTable),
                          p.value = voom.low.topTable$P.Value,
                          q.value = voom.low.topTable$adj.P.Val,
                          log.fc = voom.low.topTable$logFC,
                          test.stat = voom.low.topTable$t)
```
Lets see how does it looks like - 

```r
pandoc.table(head(voom.limma.low.results), style="rmarkdown")
```

```
## 
## 
## |  gene.id  |  p.value  |  q.value  |  log.fc  |  test.stat  |
## |:---------:|:---------:|:---------:|:--------:|:-----------:|
## |  YJR009C  | 2.411e-08 | 5.109e-05 |  -1.689  |   -20.22    |
## |  YAL054C  | 6.18e-09  | 4.404e-05 |  6.304   |    23.89    |
## |  YLR058C  | 4.886e-08 | 5.109e-05 |  -2.367  |   -18.54    |
## |  YLR249W  | 4.612e-08 | 5.109e-05 |  -1.12   |   -18.67    |
## |  YDR384C  | 3.467e-08 | 5.109e-05 |  4.658   |    19.34    |
## |  YFL014W  | 5.018e-08 | 5.109e-05 |  5.104   |    18.47    |
```
Lets see how many genes are differentially expressed between conditions at a false discovery rate (FDR) of 10^-5.

```r
sum(voom.limma.low.results$q.value < 1e-5)
```

```
## [1] 0
```

#### Q4b)edgeR DEA of deep sequencing data

**Now you will use edgeR to identify differentially expressed genes between the batch medium vs. chemostat conditions in the deep count datasets loaded in Q2a.**

**i)Recall that `edgeR` needs to estimate the dispersion parameter in the negative binomial model using an empirical Bayes method. Estimate the dispersion parameters using `estimateGLMCommonDisp`, `estimateGLMTrendedDisp` and `estimateGLMTagwiseDisp`.**

```r
dge.glm <- DGEList(counts=rcDat, group=design$condition)
desMat <- model.matrix(~condition, design)
dge.glm.com.disp <- estimateGLMCommonDisp(dge.glm, desMat, verbose=TRUE)
```

```
## Disp = 0.00551 , BCV = 0.0742
```

```r
dge.glm.trend.disp <- estimateGLMTrendedDisp(dge.glm.com.disp, desMat)
```

```
## Loading required package: splines
```

```r
dge.glm.tag.disp <- estimateGLMTagwiseDisp(dge.glm.trend.disp, desMat)
```

Lets plot the tagwise dispersion against log2-CPM (counts per million)

```r
plotBCV(dge.glm.tag.disp)
```

![](hw2_files/figure-html/unnamed-chunk-54-1.png) 


**ii)  Use the glm functionality of `edgeR`, i.e. use the `glmFit` function, to identify differentially expressed genes between conditions.
**

```r
edger.fit <- glmFit(dge.glm.tag.disp, desMat)
edger.lrt <- glmLRT(edger.fit, coef=grep("condition", colnames(desMat)))
edger.results <- topTags(edger.lrt, n=Inf, adjust.method="BH", sort.by="PValue")
```

**Package these results in a data.frame called 'edger.deep.results' with five columns.**


```r
edger.results <- data.frame(edger.results[,c("PValue", "FDR", "logFC", "LR")])
colnames(edger.results) <- c("p.value", "q.value", "log.fc", "test.stat")
edger.results <- cbind(gene.id=rownames(edger.results), edger.results)
```

I am saving my results in a file called stampy.edger.results.tsv.


```r
write.table(edger.results, "stampy.edger.results.txt",
            row.names=TRUE, col.names = NA, sep="\t")
pandoc.table(head(edger.results), style="rmarkdown")
```

```
## 
## 
## |    &nbsp;     |  gene.id  |  p.value  |  q.value  |  log.fc  |
## |:-------------:|:---------:|:---------:|:---------:|:--------:|
## |  **YIL057C**  |  YIL057C  |     0     |     0     |  10.08   |
## |  **YMR175W**  |  YMR175W  |     0     |     0     |  9.426   |
## |  **YJR095W**  |  YJR095W  |     0     |     0     |  9.419   |
## |  **YMR107W**  |  YMR107W  |     0     |     0     |  9.073   |
## |  **YKL217W**  |  YKL217W  |     0     |     0     |  8.573   |
## |  **YPL201C**  |  YPL201C  |     0     |     0     |  7.654   |
## 
## Table: Table continues below
## 
##  
## 
## |    &nbsp;     |  test.stat  |
## |:-------------:|:-----------:|
## |  **YIL057C**  |    2191     |
## |  **YMR175W**  |    1877     |
## |  **YJR095W**  |    2247     |
## |  **YMR107W**  |    2627     |
## |  **YKL217W**  |    1689     |
## |  **YPL201C**  |    1951     |
```

**iii) How many genes are differentially expressed between conditions at a false discovery rate (FDR) of 1e-5? Compare the results with those obtained in Q2b-iii.**


```r
fdr <- 1e-5
(edger.nHits <- sum(edger.results$q.value <= 1e-5))
```

```
## [1] 2669
```

2669 genes are differentially expressed between conditions at FDR of 10^{-5}. Those obtained in Q2b-iii were 1794 DE genes. Thus, 875 more hits were obtained for the same FDR for edgeR.


#### Q4c) edgeR DEA of low sequencing data

**Repeat Q4b-i and Q4b-ii for the low count data. Package these results in a data.frame called 'edger.low.results' with five columns as before.**


```r
dge.glm <- DGEList(counts=low.counts.dat, group=design$condition)
desMat <- model.matrix(~condition, design)
dge.glm.com.disp <- estimateGLMCommonDisp(dge.glm, desMat, verbose=TRUE)
```

```
## Disp = 0.0042 , BCV = 0.0648
```

```r
dge.glm.trend.disp <- estimateGLMTrendedDisp(dge.glm.com.disp, desMat)
dge.glm.tag.disp <- estimateGLMTagwiseDisp(dge.glm.trend.disp, desMat)
```

Lets plot the tagwise dispersion against log2-CPM (counts per million)

```r
plotBCV(dge.glm.tag.disp)
```

![](hw2_files/figure-html/unnamed-chunk-60-1.png) 

Identifying differentially expressed genes between conditions. 

```r
edger.fit <- glmFit(dge.glm.tag.disp, desMat)
edger.lrt <- glmLRT(edger.fit, coef=grep("condition", colnames(desMat)))
low.edger.results <- topTags(edger.lrt, n=Inf, adjust.method="BH", sort.by="PValue")
```

```r
low.edger.results <- data.frame(low.edger.results[,c("PValue", "FDR", "logFC", "LR")])
colnames(low.edger.results) <- c("p.value", "q.value", "log.fc", "test.stat")
low.edger.results <- cbind(gene.id=rownames(low.edger.results), low.edger.results)
```

I am saving my results in a file called stampy.edger.results.tsv.


```r
write.table(low.edger.results, "low.edger.results.txt",
            row.names=TRUE, col.names = NA, sep="\t")
pandoc.table(head(low.edger.results), style="rmarkdown")
```

```
## 
## 
## |    &nbsp;     |  gene.id  |  p.value   |  q.value   |  log.fc  |
## |:-------------:|:---------:|:----------:|:----------:|:--------:|
## |  **YOR374W**  |  YOR374W  |     0      |     0      |  6.564   |
## |  **YKL217W**  |  YKL217W  | 1.287e-291 | 4.586e-288 |  8.634   |
## |  **YAL054C**  |  YAL054C  | 2.204e-194 | 5.236e-191 |  6.486   |
## |  **YDR343C**  |  YDR343C  | 9.247e-158 | 1.647e-154 |  5.265   |
## |  **YFL014W**  |  YFL014W  | 4.234e-119 | 6.035e-116 |  5.135   |
## |  **YBR067C**  |  YBR067C  |  1.8e-115  | 2.138e-112 |  6.444   |
## 
## Table: Table continues below
## 
##  
## 
## |    &nbsp;     |  test.stat  |
## |:-------------:|:-----------:|
## |  **YOR374W**  |    2324     |
## |  **YKL217W**  |    1332     |
## |  **YAL054C**  |    884.6    |
## |  **YDR343C**  |    716.1    |
## |  **YFL014W**  |    538.4    |
## |  **YBR067C**  |    521.7    |
```
Lets see how many hits do we get this time -

```r
fdr <- 1e-5
(low.edger.nHits <- sum(low.edger.results$q.value <= 1e-5))
```

```
## [1] 486
```

486 genes are differentially expressed between conditions at FDR of 10^{-5}.


#### Q4d) Comparison of DEA
 
**Now that we have the results of the differential expression analysis performed by voom+limma and edgeR methods on both low and deep count data, we are going to compare and illustrate the results.**

**Create a Venn diagram showing all genes identified as differentially expressed (at FDR of 1e-5) in the four previous RNA-Seq analyses. If the comparison of 4 sets gets very confusing, you can also create different pairs of Venn diagrams of interest.**



```r
# Making list of genes as required
cutoff <- 1e-5
edger.deep.genes <- with(edger.results, gene.id[q.value < cutoff])
edger.low.genes <- with(low.edger.results, gene.id[q.value < cutoff])
voom.limma.deep.genes <- with(voom.results, gene.id[q.value < cutoff]) 
voom.limma.low.genes <- with(voom.limma.low.results, gene.id[q.value < cutoff])



# Making a combination of all the above sets
venn.genes <- list(voom_limma_deep = voom.limma.deep.genes,
    voom_limma_low = voom.limma.low.genes,
    edger_deep = edger.deep.genes,
    edger_low = edger.low.genes)

# Plotting the Venn Diagram
plot.new()
venn.plot <- venn.diagram(venn.genes, filename = NULL, fill = rainbow(4))
grid.draw(venn.plot)
```

![](hw2_files/figure-html/unnamed-chunk-65-1.png) 

**i) How many genes were identified by voom+limma in both low and deep count data?**

```r
length(intersect(voom.limma.deep.genes, voom.limma.low.genes))
```

```
## [1] 0
```
No genes were identified by voom+limma in both low and deep count data.

**ii) How many genes were identified by edgeR in both low and deep count data?**

```r
length(intersect(edger.deep.genes, edger.low.genes))
```

```
## [1] 485
```
485 genes were identified by edgeR in both low and deep count data.

**iii) How many genes were identified in all the analyses?**

```r
length(intersect(intersect(voom.limma.deep.genes, voom.limma.low.genes), intersect(edger.deep.genes, edger.low.genes)))
```

```
## [1] 0
```
No genes were identified by all the analyses.

**iv) Comment on the effect of sequencing depth on the DEA results. Is one of the methods more robust to this effect than the other. Make any additional observations about your results that you find interesting.**

EdgeR seems to be more robust for identifying differentially expressed genes in both low and deep count data. 
On reducing the sequencing depth, the number of DE genes identified by the voom+limma method reduced from 1794 to zero. On the other hand, DE genes identified by edgeR method reduced from 2669 to 486. Of these 486 hits, 478 genes were found to be differentially expressed with limma+voom in deep data. 

Other additional comments - 

In a study done by [Tarazona et. al.](http://www.ncbi.nlm.nih.gov/pmc/articles/PMC3227109/) it was found that most existing DEA methods suffer from a strong dependency on sequencing depth for their DE calls. It was concluded that as the number of reads grow, the number of false positives also increase.

In another recent study by [Zakharov et al.](http://biorxiv.org/content/early/2015/01/15/013854) published on January 1, 2015, it was found that model based normalization improves differential expression calling in low-depth RNA-seq. The study states that certain statistical features of the low sequencing data such as Gene count distribution are well preserved and can improve DEA at low sequencing depths. Its worth a read!
 
Array data appears to be less accurate and has more technical variability. This results in more variance, greater p-values, smaller test statsitics and less statistically significant genes in DEA. Besides, array data has a limited dynamic range. The signal is lost in the background noise at a low expression, whereas at high expression, the photosensor saturates resulting in an artifical maximum measurement. On the other hand, RNA-seq suffers less from such issues. Its background moise floor is represented by mismapped reads and the digital count data is not prone to saturation. 

Reference - [Wang et. al. Nature Biotechnology 32, 926-932 (2014)](http://www.nature.com/nbt/journal/v32/n9/full/nbt.3001.html)

