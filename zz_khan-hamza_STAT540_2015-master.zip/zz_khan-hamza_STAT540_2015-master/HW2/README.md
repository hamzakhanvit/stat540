HomeWork 2 - Hamza Khan

Please click on the following links:

- [RMD FILE](https://github.com/STAT540-UBC/zz_khan-hamza_STAT540_2015/blob/master/HW2/hw2.rmd)
- [MD FILE](https://github.com/STAT540-UBC/zz_khan-hamza_STAT540_2015/blob/master/HW2/hw2.md)
- [HTML FILE](https://github.com/STAT540-UBC/zz_khan-hamza_STAT540_2015/blob/master/HW2/hw2.html) - Please prepend http://htmlpreview.github.io/? in raw html file for github preview.
