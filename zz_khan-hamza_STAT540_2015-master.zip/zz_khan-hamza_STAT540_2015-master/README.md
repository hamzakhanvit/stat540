
#Hamza Khan

Welcome to my Repository!

I am a first year student in the Bioinformatics Graduate program at UBC.
![cihrlogo](Seminars/test_files/figure-html/cihr.jpg)

I am currently working on a rotation project under Dr.Fiona Brinkman at Simon Fraser University which involves updating [IslandViewer3](http://www.pathogenomics.sfu.ca/islandviewer/accession/NC_004631.1/) which is an integrated interface for computational identification and vizualization of genomic islands.


####Seminars
Please find the weekly seminars as under - 

- [seminar00b](https://github.com/STAT540-UBC/zz_khan-hamza_STAT540_2015/blob/master/Seminars/seminar00b.md)
- [seminar00c](https://github.com/STAT540-UBC/zz_khan-hamza_STAT540_2015/blob/master/Seminars/seminar00c.md)
- [seminar00d](https://github.com/STAT540-UBC/zz_khan-hamza_STAT540_2015/blob/master/Seminars/seminar00d.md)
- [seminar01b](https://github.com/STAT540-UBC/zz_khan-hamza_STAT540_2015/blob/master/Seminars/seminar01b.md)
- [seminar02b](https://github.com/STAT540-UBC/zz_khan-hamza_STAT540_2015/blob/master/Seminars/seminar02b.md)
- [seminar03](https://github.com/STAT540-UBC/zz_khan-hamza_STAT540_2015/blob/master/Seminars/seminar03.md)
- [seminar04a](https://github.com/STAT540-UBC/zz_khan-hamza_STAT540_2015/blob/master/Seminars/seminar04a.md)
- [seminar04b](https://github.com/STAT540-UBC/zz_khan-hamza_STAT540_2015/blob/master/Seminars/seminar04b.md)
- [seminar005](https://github.com/STAT540-UBC/zz_khan-hamza_STAT540_2015/blob/master/Seminars/seminar005.md)
- [seminar006](https://github.com/STAT540-UBC/zz_khan-hamza_STAT540_2015/blob/master/Seminars/seminar006.md)
- [seminar007a](https://github.com/STAT540-UBC/zz_khan-hamza_STAT540_2015/blob/master/Seminars/seminar007a.md)
- [seminar007b](https://github.com/STAT540-UBC/zz_khan-hamza_STAT540_2015/blob/master/Seminars/seminar007b.md)
- [seminar008](https://github.com/STAT540-UBC/zz_khan-hamza_STAT540_2015/blob/master/Seminars/seminar008.md)
- [seminar009](https://github.com/STAT540-UBC/zz_khan-hamza_STAT540_2015/blob/master/Seminars/seminar09.md)
- [seminar10](https://github.com/STAT540-UBC/zz_khan-hamza_STAT540_2015/blob/master/Seminars/seminar_10.md)


####Homeworks - 

These are the links to my homework directories -

[Home Work 1](https://github.com/STAT540-UBC/zz_khan-hamza_STAT540_2015/blob/master/HW1)
[Home Work 2](https://github.com/STAT540-UBC/zz_khan-hamza_STAT540_2015/blob/master/HW2)


####For visiting my Project Repository - [Click here](https://github.com/STAT540-UBC/yy_team02_asthma_STAT540_2015)

We have investigated differential expression patterns of genes in early and dual responders of allergic asthma. You can have a look at our poster [here.](https://github.com/STAT540-UBC/yy_team02_asthma_STAT540_2015/blob/master/Poster/ProjectPoster_STAT540.pdf)


####For viewing my Project report - [Click here](https://github.com/STAT540-UBC/zz_khan-hamza_STAT540_2015/tree/master/Project)