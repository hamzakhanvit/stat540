## Individual report for STAT-540 project

April 9, 2015

Hamza Khan

***

## 1. Concise summary of main role / contribution of each group member

| Member | Role/Contribution |
|:-:|---|
| Yolanda Yang| Proposal write-up. Ran differentially expression analysis to compare ER vs. DR at pre-challenge and (Post-Pre) of ER vs. (Post-Pre) of DR. |
| Max Alander | Explored Data Normalization methods and performed data analysis |
| Akiff Manji | Performed exploratory data analysis on the datasets. Assessed correlation between the different samples, PCA on the top 2 principal components to validate outlier samples, and looked at the overall expression profile of the samples across all the genes. |
| Basia Rogula | Ran the leukocyte analysis including exploratory graphs; Compared relative leukocyte subtype counts of different phenotypes. Compared ER vs.DR at pre-challenge and (Post-Pre) of ER vs. (Post-Pre) of DR. |
|Hamza Khan| Confirmed outliers. Used weighted correlation network analysis to find modules of highly correlated genes and thereafter related these modules to one another and to external sample traits. Created a module trait relationships plot. Carried out gene network analysis using GENEMANIA.
| Naman Paul| Performed consensus module analysis for the modules obtained from WGCNA analysis. He further visualized the gene network using a heatmap plot and drew an Eigengene adjacency heatmap. |

Everyone contributed in making the poster.

## 2. Detailed description and reflections on my specific role / contribution

**Main Contributions**
* I used Weighted correlation network analysis (WGCNA) to find clusters or modules of highly correlated genes and thereafter related these modules to one another and to external sample traits. [(Click here to go to my scripts folder)]( https://github.com/STAT540-UBC/yy_team02_asthma_STAT540_2015/tree/master/Scripts/Co-expression%20analysis)
* Started by depicting the outlier by creating a clustering dendrogram of samples based on their Euclidean distance. Thereafter, removed the outlier. [(Click here)]( https://github.com/STAT540-UBC/yy_team02_asthma_STAT540_2015/blob/master/Plots/co-expression%20analysis/outlier%20plot.jpeg)
* Visualized how the clinical traits relate to the sample dendrogram by constructing a Sample dendrogram and trait Heat map. [(Click here)]( https://github.com/STAT540-UBC/yy_team02_asthma_STAT540_2015/blob/master/Plots/co-expression%20analysis/Sample%20dendrogram%20and%20trait%20heatmap.jpeg)
* Analyzed network topology for various soft-thresholding powers and decided on the power to be used for module generation. [(Click here)]( https://github.com/STAT540-UBC/yy_team02_asthma_STAT540_2015/blob/master/Plots/co-expression%20analysis/Soft-threshold%20plot.jpeg)
* Visualized the clustering dendrogram of genes, with dissimilarity based on topological overlap, together with assigned module colors.[(Click here)]( https://github.com/STAT540-UBC/yy_team02_asthma_STAT540_2015/blob/master/Plots/co-expression%20analysis/Cluster%20dendogram%20(p%3D16).jpeg)
* Analysed the relationships of modules and clinical traits in the data with the help of a Module trait relationships plot.[(Click here)](https://github.com/STAT540-UBC/yy_team02_asthma_STAT540_2015/blob/master/Plots/co-expression%20analysis/Module%20trait%20relationship%20(p%3D16).jpeg)
* Wrote another script to retrieve all the genes for the different color modules and carried out gene network analysis for 450 random genes using [GENEMANIA.]( http://pages.genemania.org/)

**Other contributions**
* Reviewed the project proposal.
* Helped in making and reviewing the poster along with other team mates.

## 3.Scientific reflections.

**What Worked well?**

The outlier was easily detected and was validated by sample clustering.
The Weighted correlation network analysis worked very well. Though it was a new topic, but the tutorials were pretty decent and helpful.

[(Click here to view the plots and descriptions of my WGCNA analysis)](https://github.com/STAT540-UBC/yy_team02_asthma_STAT540_2015/tree/master/Plots/co-expression%20analysis)

Most of the genes were clustered in a total of 8 modules. The two major color modules as are under -

1) Turquoise module - As per GENEMANIA gene network analysis, 70.85% of the genes in this list are co-expressed and are involved in a variety of functions including water channel activity, water transmembrane transporter activity, K+ ion transmembrane transport, K+ channel activity,etc.
[(Click here to view its GENEMANIA co-expression network)]( https://github.com/STAT540-UBC/yy_team02_asthma_STAT540_2015/blob/master/Plots/co-expression%20analysis/genemania_co-expression_network_Turquoise_Module.png).
In a recent study by [Kokmalova et. al]( http://link.springer.com/chapter/10.1007%2F5584_2014_76) , it was found that K+ channels play a significant role in the airway smooth muscle cell and goblet cell function, and cytokine production. 


2) Blue module - As per GENEMANIA gene network analysis, 69.74% of the genes in this list are co-expressed and are involved in functions such as Inflammatory response, FC receptor pathways, Mitochondrial proton transporting ATP synthase complex, ATPase activity, etc.
[(Click here to view its GENEMANIA co-expression network)](https://github.com/STAT540-UBC/yy_team02_asthma_STAT540_2015/blob/master/Plots/co-expression%20analysis/genemania_co-expression_network_Blue_Module.png)

Thus, genes belonging to these modules are closely associated with allergic asthma and can be of great significance if evaluated further.

The relationships of consensus module eigengenes and clinical traits in the data were clearly depicted by the module trait relationship plots. Some clear patterns could be seen between different modules such as the brown and magenta modules. Besides, correlations between Late asthmatic response(LAR) and torquoise model was inferred.

**Difficulties?**

We lacked efficient computational resources as required by the WGCNA analyses for all the 21726 probesets. Even with 32 Gigabytes of Random access memory(RAM), our systems crashed. As a result, we carried out the computationally expensive steps for only 10,000 random probesets.

**What seems worth following?**

1887 genes were found to be differentially expressed between phenotypes and 692 genes to be differentially expressed in granulocytes of phenotypes.It would be nice if we could carry out WGCNA analyses only for these, rather than for all the probesets. This would help us analyse their co-expression patterns, clusters-trait correlations,etc.
We could also carry out an interfacing network analyses, if provided with functional annotation and gene ontology data for our probesets. This would facilitate a deeper biological interpretation, where we might know the gene ontologies of the genes in the
modules, whether they are significantly enriched in certain functional categories or not. Besides, the differential expression analyses results could be further worked upon.

**What looks like a dead end?**

Differential expression analysis of ER vs. DR at pre-challenge looks uninteresting.

**Final Comments -**

We all enjoyed working together. As we were all from different backgrounds including statistics, bioinformatics, experimental medicine, biomedical engineering, etc., it was a great learning experience. 