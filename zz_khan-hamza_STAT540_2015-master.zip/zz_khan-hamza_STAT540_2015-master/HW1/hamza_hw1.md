# Home Work Assignment 1
hamzakhanvit  
Saturday, February 14, 2015  

**Author:Hamza Khan**

**HomeWork Assignment on analyzing a publicly-available gene expression study of normal human bronchial epithelial (NHBE) cells, run on the Affymetrix GeneChip Human Genome U133 Plus 2.0 Array.**

Lets begin by loading some libraries

```r
library(reshape2)
library(limma)
library(pheatmap)
library(RColorBrewer)
library(car)
library(plyr)
library(dplyr)
```

```
## 
## Attaching package: 'dplyr'
## 
## The following objects are masked from 'package:plyr':
## 
##     arrange, count, desc, failwith, id, mutate, rename, summarise,
##     summarize
## 
## The following object is masked from 'package:stats':
## 
##     filter
## 
## The following objects are masked from 'package:base':
## 
##     intersect, setdiff, setequal, union
```

```r
library(knitr)
library(ggplot2)
library(lattice)
```
My little Stripplot function that I'll be using afterwards-

```r
mystripplot <- function (data4plot, x,grp) {
    data4plot <- melt(data4plot, id.vars=colnames(Des),
                      variable.name="genes", value.name="expression")
    ggplot(data4plot, aes_string(x=x, y="expression", color=grp, group = grp)) + 
        geom_point() +
        facet_wrap(~genes)
}
```
Reading the Data file.

```r
Dat <- read.table("data.txt", row.names = 1, header = TRUE)

# Let's have a little peep inside the data -
str(Dat, max.level = 0)
```

```
## 'data.frame':	22737 obs. of  23 variables:
```

```r
head(Dat,1)
```

```
##         GSE10718_Biomat_1 GSE10718_Biomat_10 GSE10718_Biomat_11
## 1294_at          7.900022           7.623666           8.224398
##         GSE10718_Biomat_12 GSE10718_Biomat_13 GSE10718_Biomat_14
## 1294_at            8.00971           7.607968           7.448574
##         GSE10718_Biomat_15 GSE10718_Biomat_16 GSE10718_Biomat_17
## 1294_at           7.414247           7.671862           7.892385
##         GSE10718_Biomat_19 GSE10718_Biomat_2 GSE10718_Biomat_20
## 1294_at           7.804841          7.721433           7.548707
##         GSE10718_Biomat_21 GSE10718_Biomat_22 GSE10718_Biomat_23
## 1294_at           6.343507           7.797584           7.951058
##         GSE10718_Biomat_24 GSE10718_Biomat_3 GSE10718_Biomat_4
## 1294_at           7.877641          7.510909          7.309565
##         GSE10718_Biomat_5 GSE10718_Biomat_6 GSE10718_Biomat_7
## 1294_at          8.004972          7.502813          7.500043
##         GSE10718_Biomat_8 GSE10718_Biomat_9
## 1294_at          7.509491          7.735819
```

```r
#Lets also look at the statistical summary for our data - 
summary(Dat)
```

```
##  GSE10718_Biomat_1  GSE10718_Biomat_10 GSE10718_Biomat_11
##  Min.   :-0.04013   Min.   : 0.1585    Min.   : 0.4686   
##  1st Qu.: 5.97436   1st Qu.: 5.9043    1st Qu.: 5.9427   
##  Median : 7.45861   Median : 7.4522    Median : 7.4438   
##  Mean   : 7.73672   Mean   : 7.6806    Mean   : 7.7065   
##  3rd Qu.: 9.48162   3rd Qu.: 9.4660    3rd Qu.: 9.4786   
##  Max.   :15.88279   Max.   :15.9347    Max.   :15.8828   
##  GSE10718_Biomat_12 GSE10718_Biomat_13 GSE10718_Biomat_14
##  Min.   : 0.09053   Min.   : 0.540     Min.   : 0.3388   
##  1st Qu.: 5.93665   1st Qu.: 5.982     1st Qu.: 6.0029   
##  Median : 7.45448   Median : 7.468     Median : 7.4760   
##  Mean   : 7.70129   Mean   : 7.745     Mean   : 7.7443   
##  3rd Qu.: 9.47476   3rd Qu.: 9.476     3rd Qu.: 9.4780   
##  Max.   :15.88279   Max.   :15.935     Max.   :15.9347   
##  GSE10718_Biomat_15 GSE10718_Biomat_16 GSE10718_Biomat_17
##  Min.   :-0.0288    Min.   : 0.4217    Min.   :-0.2396   
##  1st Qu.: 6.0159    1st Qu.: 5.9867    1st Qu.: 5.9865   
##  Median : 7.4695    Median : 7.4503    Median : 7.4677   
##  Mean   : 7.7612    Mean   : 7.7376    Mean   : 7.7439   
##  3rd Qu.: 9.4829    3rd Qu.: 9.4740    3rd Qu.: 9.4745   
##  Max.   :15.9347    Max.   :15.9347    Max.   :15.8828   
##  GSE10718_Biomat_19 GSE10718_Biomat_2 GSE10718_Biomat_20 
##  Min.   : 0.06547   Min.   : 0.3355   Min.   : 0.008505  
##  1st Qu.: 5.96689   1st Qu.: 5.9795   1st Qu.: 5.971269  
##  Median : 7.45692   Median : 7.4659   Median : 7.452516  
##  Mean   : 7.72946   Mean   : 7.7374   Mean   : 7.722488  
##  3rd Qu.: 9.47082   3rd Qu.: 9.4816   3rd Qu.: 9.472135  
##  Max.   :15.93470   Max.   :15.9347   Max.   :15.934698  
##  GSE10718_Biomat_21 GSE10718_Biomat_22 GSE10718_Biomat_23
##  Min.   : 0.3681    Min.   : 0.2821    Min.   : 0.5548   
##  1st Qu.: 5.9359    1st Qu.: 5.9521    1st Qu.: 5.9359   
##  Median : 7.4342    Median : 7.4489    Median : 7.4537   
##  Mean   : 7.7054    Mean   : 7.7158    Mean   : 7.7009   
##  3rd Qu.: 9.4660    3rd Qu.: 9.4702    3rd Qu.: 9.4722   
##  Max.   :15.9347    Max.   :15.9347    Max.   :15.8828   
##  GSE10718_Biomat_24 GSE10718_Biomat_3 GSE10718_Biomat_4 GSE10718_Biomat_5
##  Min.   :-0.05589   Min.   : 0.1825   Min.   :-0.3315   Min.   :-0.1469  
##  1st Qu.: 5.94739   1st Qu.: 5.9784   1st Qu.: 5.9655   1st Qu.: 5.9680  
##  Median : 7.45692   Median : 7.4614   Median : 7.4593   Median : 7.4572  
##  Mean   : 7.70980   Mean   : 7.7414   Mean   : 7.7229   Mean   : 7.7158  
##  3rd Qu.: 9.46708   3rd Qu.: 9.4733   3rd Qu.: 9.4874   3rd Qu.: 9.4810  
##  Max.   :15.88279   Max.   :15.9347   Max.   :15.9347   Max.   :15.9347  
##  GSE10718_Biomat_6 GSE10718_Biomat_7 GSE10718_Biomat_8 GSE10718_Biomat_9
##  Min.   : 0.1644   Min.   : 0.1874   Min.   :-0.9418   Min.   :-0.3315  
##  1st Qu.: 6.0087   1st Qu.: 5.9647   1st Qu.: 5.9785   1st Qu.: 5.9460  
##  Median : 7.4635   Median : 7.4533   Median : 7.4643   Median : 7.4526  
##  Mean   : 7.7554   Mean   : 7.7082   Mean   : 7.7277   Mean   : 7.7032  
##  3rd Qu.: 9.4851   3rd Qu.: 9.4776   3rd Qu.: 9.4802   3rd Qu.: 9.4721  
##  Max.   :15.9347   Max.   :15.9347   Max.   :15.8828   Max.   :15.8828
```
While merely eye-balling on this statistical summary, one can infer, that except for the minimum for each sample, all the other values look almost similar.


Loading the Metadata -

```r
Des <- read.table("design.txt", row.names = 1,header = TRUE)
str(Des)
```

```
## 'data.frame':	23 obs. of  3 variables:
##  $ ExternalID: Factor w/ 23 levels "GSM270872","GSM270873",..: 11 3 2 1 9 8 7 14 13 16 ...
##  $ Treatment : Factor w/ 2 levels "cigarette_smoke",..: 2 2 2 2 2 2 2 1 1 1 ...
##  $ time      : Factor w/ 4 levels "1_h","2_h","24_h",..: 3 1 1 1 4 4 4 1 1 2 ...
```

```r
#This is how it looks like - 
head(Des, 2)
```

```
##                    ExternalID Treatment time
## GSE10718_Biomat_1   GSM270883   control 24_h
## GSE10718_Biomat_10  GSM270874   control  1_h
```

```r
table(Des$Treatment, Des$time) #Seems fairly balanced except for 1_hr, cigarette_Smoke.
```

```
##                  
##                   1_h 2_h 24_h 4_h
##   cigarette_smoke   2   3    3   3
##   control           3   3    3   3
```

```r
#A glimpse of the number of observations and variables -
glimpse(Des)
```

```
## Observations: 23
## Variables:
## $ ExternalID (fctr) GSM270883, GSM270874, GSM270873, GSM270872, GSM270...
## $ Treatment  (fctr) control, control, control, control, control, contr...
## $ time       (fctr) 24_h, 1_h, 1_h, 1_h, 4_h, 4_h, 4_h, 1_h, 1_h, 2_h,...
```

```r
#Checking whether number of columns in Dat are same as the number of rows in Des.
identical(colnames(Dat), row.names(Des))
```

```
## [1] TRUE
```

```r
#Making factors for time in order
Des$time <- factor(Des$time, levels = c("1_h", "2_h", "4_h", "24_h"))
```

#### Q1. What are the basic characteristics of the data and meta-data?
The transcriptome data contains preprocessed expression value of genes on a log2 scale in the samples. The identifiers for the genes are present at the beginning of each row and those for the samples are at the beginning of each column.
The meta-data file contains columns of sample identifiers, External Ids, Treatment (Control Vs cigarette_smoke) and time (post-CS-exposure). 


#### Q1a: How many probes? How many samples (Bioassay)?

```r
dim(Dat)
```

```
## [1] 22737    23
```
There are a total of **22737** probes and **23** samples.

#### Q1b: What is the breakdown of samples (Bioassay) for agent, time?
The following table depicts the above mentioned breakdown :

```r
(table(Des$Treatment, Des$time))
```

```
##                  
##                   1_h 2_h 4_h 24_h
##   cigarette_smoke   2   3   3    3
##   control           3   3   3    3
```

#####How do you feel about the experimental design? 

```r
library(pander)
pandoc.table(head(Des[, 1:3]), style="rmarkdown")
```

```
## 
## 
## |          &nbsp;          |  ExternalID  |  Treatment  |  time  |
## |:------------------------:|:------------:|:-----------:|:------:|
## |  **GSE10718_Biomat_1**   |  GSM270883   |   control   |  24_h  |
## |  **GSE10718_Biomat_10**  |  GSM270874   |   control   |  1_h   |
## |  **GSE10718_Biomat_11**  |  GSM270873   |   control   |  1_h   |
## |  **GSE10718_Biomat_12**  |  GSM270872   |   control   |  1_h   |
## |  **GSE10718_Biomat_13**  |  GSM270881   |   control   |  4_h   |
## |  **GSE10718_Biomat_14**  |  GSM270880   |   control   |  4_h   |
```

```r
summary(Des)
```

```
##      ExternalID           Treatment    time  
##  GSM270872: 1   cigarette_smoke:11   1_h :5  
##  GSM270873: 1   control        :12   2_h :6  
##  GSM270874: 1                        4_h :6  
##  GSM270875: 1                        24_h:6  
##  GSM270876: 1                                
##  GSM270878: 1                                
##  (Other)  :17
```
**Answer** - Except for one case for one hour (1_h) post cigarette smoke exposure, which seems missing, the other cases and controls look fine with 3 samples per treatment per measurement time. I suppose the missing sample is the one with 'NA values on all probes' which was removed from both the data and the meta-data.


#### Q1c: Create a quantitative (numeric) variable that represents the time at which cells were measured. 


```r
Des$Numtime <- recode(Des$time, "'1_h'=1; '2_h'=2; '4_h'=4; '24_h'=24", as.factor.result = FALSE)
str(Des$Numtime)
```

```
##  num [1:23] 24 1 1 1 4 4 4 1 1 2 ...
```

#### Q1d: Create a plot showing the gene expression data for one probe and the averages for all possible combinations of agent and time.

```r
#So, my random probe is - 
set.seed(786)
(probe  <- sample(rownames(Dat),1))
```

```
## [1] "238759_at"
```

```r
gdata <- (t(Dat[probe, ]))
#gdata  <- head(gdata, -1)
gExp <- as.vector(gdata)
gene <- as.factor(rep(colnames(gdata), each = nrow(gdata)))
gDat <- (cbind(Des, gExp, gene))


stripplot(gExp ~ time , gDat, groups = Treatment, auto.key = TRUE, grid = TRUE, type = c('p', 'a'), horizontal = FALSE, tick.number = 1, main = ("The gene Expression of probe with respect to time in Hours") , xlab = "Time in hours", ylab = "Gene expression on log2 scale")
```

![](hamza_hw1_files/figure-html/unnamed-chunk-9-1.png) 

**The average expression of the selected probe for all possible combinations of agent and time as depicted in the graph above are as under -**

```r
tapply( X = as.numeric(gDat$gExp), 
        INDEX = list(gDat$time,gDat$Treatment), 
        FUN = mean )
```

```
##      cigarette_smoke  control
## 1_h         6.464685 5.890179
## 2_h         4.625334 5.992783
## 4_h         6.320100 7.303022
## 24_h        7.355647 7.611757
```
Looking at the average expression of the selected probe at various time points for the treatment conditions, it can be inferred that it is highly variable. Looks like, it is a so called "interesting"" gene.


### Q2 Assessing data quality

#### Q2a: Examine the sample-to-sample correlations in a heatmap.

I've made a little function for this -

```r
my_cor_heatmap <- function(x){
    corMat <- cor(Dat[, x])
    
    pheatmap(corMat,
    main = "Heatmap for sample-to-sample correlations",
    color = colorRampPalette(c("white", "red"))(n = 299),
                     cluster_rows = FALSE, cluster_cols = FALSE,
                     annotation = Des[x,c("Treatment", "time")],
                     annotation_legend = TRUE,
                     show_rownames = T, show_colnames = T,fontsize_row = 10     
        )
}
```
Lets just chop off the "GSE10718_Biomat_" from the rownames which was making my heatmap look ugly.

```r
rownames(Des) <- sub("GSE10718_Biomat_", "", rownames(Des))
colnames(Dat) <- sub("GSE10718_Biomat_", "", colnames(Dat))
```

**Using 'my_cor_heatmap' function to create a sample-sample correlation matrix ordered by *time* and then by *Treatment* and examining it in a heatmap-**

```r
my_cor_heatmap(order(Des$time, Des$Treatment))
```

![](hamza_hw1_files/figure-html/unnamed-chunk-13-1.png) 



**Using the function to create a correlation matrix heatmap ordered by *Treatment* and then by *time*.**


```r
my_cor_heatmap(order(Des$Treatment, Des$time))
```

![](hamza_hw1_files/figure-html/unnamed-chunk-14-1.png) 
 

####Interpret your results. What does the sample correlation matrix tell us about the overall impact of time and agent?
* Dark shades of red indicate higher level of correlation and vice versa.
* Stronger correlations can be seen in the treatment-ordered heatmap as compared to the time-sorted. As a result, it can be concluded that gene expression is more affected by treatment conditions as compared to the exposure time.

* Specific patterns of correlation can be seen. Some are as under - 
* Sample 10 (belonging to 'Control treatment' and '1 hour' post cigarette smoke exposure) stands out in both the heat maps with poor correlation as depicted by the almost white row and column belonging to it. It might be a potential outlier. 
* In the heat map, which was ordered by time and then by treatment, blocks expressing high levels of correlation can be seen between samples 13,14,15,16,17 and 1,2,3,6,7,8,16. 
* The second heat map, which was ordered by treatment and then by time, also  shows Sample 10 as a potential outlier. On the other hand, Sample 6 shows high level of correlation as compared to the other samples.
* Therefore, it can be concluded that both time and treatment play a crucial role in gene expression and should therefore be given importance in this study.

#### Q2b: Assess the presence of outlier samples.
####Q.Comment on the potential presence of outliers (if any) based on the sample correlation matrices created in Q2a.

The sample "GSE10718_Biomat_10" belonging to 'Control treatment' and '1 hour' post cigarette smoke exposure looks like a potential outlier.

I would start by calculating and visualising the distance metrics for these samples while taking into account the difference of sum of squares of gene expression and the sample means.


```r
sw_mean = apply((Dat[sapply(Dat, is.numeric)]), 1, mean)
d = apply((Dat[sapply(Dat, is.numeric)]), 2, function(x){sqrt(t(x-sw_mean) %*% (x-sw_mean))})
qplot(Des$Treatment, d,  geom=c("boxplot", "jitter"), fill=Des$Treatment, main="Sum of squared differences gExp Vs sample means", xlab = "Treatment (Control or Cigarrate smoke)", 
      ylab = "Distance")
```

![](hamza_hw1_files/figure-html/unnamed-chunk-15-1.png) 


As you can see from the above plot there are certain outliers which stick out from the others.

Looks convincing to me. Lets see after comparing correlations - 

```r
target <- apply(cor(Dat), 1, quantile, probs = 1:5/50)
targetpool <- data.frame(cor = as.vector(target), ID = factor(rep(rownames(Des), 
    each = 5), levels = rownames(Des)), qtile = 1:5/50)
dotplot(ID ~ cor, targetpool)
```

![](hamza_hw1_files/figure-html/unnamed-chunk-16-1.png) 

In order to make a quantitative statement about how the outlier stands out from the other samples, I have computed the mean correlation for each row and has displayed the distribution of the means with the help of a density plot.


```r
sampleCor  <- cor(Dat[sapply(Dat, is.numeric)])
meanCor <- rowMeans(sampleCor)
ggplot(data.frame(meanCor=meanCor),
       aes(x=meanCor)) +
  geom_bar(alpha=0.5)
```

```
## stat_bin: binwidth defaulted to range/30. Use 'binwidth = x' to adjust this.
```

![](hamza_hw1_files/figure-html/unnamed-chunk-17-1.png) 

This is the outlier with the minimum correlation - 

```r
outlierIdx <- which(meanCor==min(meanCor))
(outlierName <- names(outlierIdx))
```

```
## [1] "10"
```

####Q.If any sample does "stick out" from the previous step, examine it in the context of its experimental group (e.g., given a sample that is least similar to all other samples: does it correlate with samples treated with same agent better than other samples treated with a different agent?)

```r
group.def <- c("Treatment", "time")
thisGroup <- Des[outlierIdx, group.def]

# A tiny little function to look for other member in the same group:

isSameGroup <- function(x, y, group.def=TRUE){
  return(all(x[group.def] == y[group.def]))
}
members <- alply(Des, 1, isSameGroup,
                   y=Des[outlierIdx,], group.def=group.def)

members <- unlist(members)
colnames(Dat)[members]
```

```
## [1] "10" "11" "12"
```

```r
sampLabels <- Des$ExternalID
sampLabels <- mapvalues(sampLabels, from=sampLabels[outlierIdx], to="Outlier")
grpSamples <- Dat[, members]
colnames(grpSamples) <- sampLabels[members]
splom(grpSamples, panel = panel.smoothScatter)
```

```
## (loaded the KernSmooth namespace)
```

![](hamza_hw1_files/figure-html/unnamed-chunk-19-1.png) 

Gene expression scatter plot involving the outlier spreads further away from the diagonal than plots only involvong non-outlier genes. This explains the lower correlation coefficients.


#### Q2c: Assess the distribution of expression values, separated by agent.

####Q.The sample-sample correlation matrix does not capture differences between pairs of samples that are caused by systematic up- or down-regulation of all/most gene. Can you explain why?

The Pearson correlation as used by the function cor() in R is to measure the strength and direction of a linear relationship between two quantitative variables. (Referred from [Online Stat Book by David M.Lane](http://onlinestatbook.com/2/describing_bivariate_data/pearson.html)) Thus, it is referred to as a "bivariate correlation coefficient" or the "zero-order correlation coefficient" which is associated with the slope. Systematic up or down in gene expression levels changes the intercept but not the slope. That is the reason why sample-sample correlation matrix is not able to capture differences between pairs of samples that are caused by systematic up- or down-regulation of all/most gene.

####To determine if there is a "shift" in the distribution of expression levels, plot a histogram of expression values for each treatment condition (two histograms should be plotted).  Comment on the two histograms (e.g., similarity in range, mean, and median).

```r
Dat <- read.table("data.txt", row.names = 1, header = TRUE)
Data <- data.frame(gExp = as.vector(t(as.matrix(Dat))),
                     gene = factor(rep(rownames(Dat), each = ncol(Dat)),
                                   levels = rownames(Dat)))

Data <- suppressWarnings(data.frame(Des, Data))
histogram(~ gExp | Treatment, Data, col = 'grey', main = "Histograms of expression values for each treatment condition")
```

![](hamza_hw1_files/figure-html/unnamed-chunk-20-1.png) 

```r
#More analysis by comparing values:
control  <- subset(Data, Treatment == "control")
cigarette <- subset(Data, Treatment == "cigarette_smoke")

summary(control$gExp)
```

```
##    Min. 1st Qu.  Median    Mean 3rd Qu.    Max. 
## -0.9418  5.9690  7.4600  7.7240  9.4770 15.9300
```

```r
summary(cigarette$gExp)
```

```
##    Min. 1st Qu.  Median    Mean 3rd Qu.    Max. 
## -0.3315  5.9670  7.4550  7.7240  9.4740 15.9300
```
**For both the histograms, i.e; Control and cigarette_smoke , the medium, mean and maximum are almost similar. The only difference is the minimum value, which is around -0.3315 for cigarette_smoke and -0.9418 for Control.Thus, it can be concluded that the gene expression distributions are not much different for both the treatment conditions.**


### Q3. Assess differential expression with respect to treatment.
#### Q3a: Fit a linear model, modeling expression level of each probe using treatment as a single covariate.Write out in English and as an equation the model you are using to assess differential expression. In the context of that model, what statistical test are you performing?

The linear model can be stated as ![Linear model equation.](hamza_hw1_files/figure-html/equation.JPG).Here Y is the expression level of the gene(g), X is the design matrix with the treatments as 0s and 1s, alpha is the vector of coefficients, whereas Epsilon is the error which is usually assumed to come from a distribution with a mean of 0 and is therefore ignored.
In this case, we'll be considering a t-test. The null hypothesis would be that there isn't any change between the two treatments for a given gene.

In order to get stuff working, let's just start by contructing the required  matrices. I'll be using limma's lmfit() to fit a linear model with my response and  predictors. eBayes will be used for estimated variance moderation followed by topTable for visuals of interest.


```r
Des <- read.table("design.txt")
DesMat <- model.matrix(~Treatment, Des) #Creating a Design/model matrix
Fit_model <- lmFit(Dat, DesMat) #Fitting a linear model with lmfit()
EbFit <- eBayes(Fit_model) #Moderating the estimated variance with eBayes
```

#### Q3b: Count your hits, and explore them.

####How many hits (probes) are associated with treatment at unadjusted p-value 1e-3? How may are associated with treatment at FDR 0.05?

```r
count_unadj <- topTable(EbFit ,p.value = 1e-03,adjust.method = "none", n = Inf)
```

```
## Removing intercept from test coefficients
```

```r
(number1 <- nrow(count_unadj))
```

```
## [1] 805
```

```r
count_adj <- topTable(EbFit ,p.value = 0.05 ,adjust.method = "BH", n = Inf)
```

```
## Removing intercept from test coefficients
```

```r
(number2 <- nrow(count_adj))
```

```
## [1] 1238
```
**Answer-** 805 at unadjusted p-value 1e-3 and 1238 are associated with treatment at FDR 0.05.

####Q.Take the top 50 probes as  "hits" and create a heatmap of their expression levels.Sort the hits by p-values and the samples by treatment.


```r
#Sorting the hits by p-value
topHits <- topTable(EbFit, number=nrow(EbFit), adjust.method="fdr", sort.by="P")
```

```
## Removing intercept from test coefficients
```

```r
rownames(Des) <- sub("GSE10718_Biomat_", "", rownames(Des))
colnames(Dat) <- sub("GSE10718_Biomat_", "", colnames(Dat))

pheatmap(Dat[rownames(topHits)[1:50], order(Des$Treatment)], 
         color=colorRampPalette(rev(brewer.pal(n = 7, name = "RdYlBu")))(100),
         fontsize_row=6,fontsize_col = 8, cellwidth=8,
         cluster_rows=FALSE, cluster_cols=FALSE, cellheight = 6,
         annotation=Des[order(Des$Treatment), "Treatment", drop=FALSE], 
         annotation_legend = TRUE, show_rownames = T, show_colnames = T,
         main = "Heat Map for top 50 probes and their expression", width = 5,
         height = 10)
```

![](hamza_hw1_files/figure-html/unnamed-chunk-23-1.png) 

Probes [200779_at](http://xavierlab2.mgh.harvard.edu/EnrichmentProfiler/primary/Expression/200779_at.html) (unique to activating transcription factor 4(ATF4) in Humans) , [200912_s_at](http://xavierlab2.mgh.harvard.edu/EnrichmentProfiler/cancer/Expression/200912_s_at.html) (unique to Eukaryotic translation initiation factor EIF4A2), [225799_at](http://genecards.weizmann.ac.il/cgi-bin/geneannot/GA_search.pl?keyword_type=probe_set_id&array=HG-U133&target=genecards&keyword=225799_at) and [221580_s_at](http://xavierlab2.mgh.harvard.edu/EnrichmentProfiler/cancer/Expression/221580_s_at.html) show almost equally high expression for both control and treatment. Gene [203665_at](http://xavierlab2.mgh.harvard.edu/EnrichmentProfiler/primary/Expression/203665_at.html) has great expression levels for cigarette smoke for Samples 19-24. A similar pattern can be observed with gene [213305_s_at](http://xavierlab2.mgh.harvard.edu/EnrichmentProfiler/primary/Expression/213305_s_at.html).
Significant increase in gene expression from control to treatment can be observed in [220468_at](http://xavierlab2.mgh.harvard.edu/EnrichmentProfiler/primary/Expression/220468_at.html), [223710_at](http://genecards.weizmann.ac.il/cgi-bin/geneannot/GA_search.pl?keyword_type=probe_set_id&array=HG-U133_Plus_2&target=genecards&keyword=223710_at) and [213305_s_at](http://xavierlab2.mgh.harvard.edu/EnrichmentProfiler/primary/Expression/213305_s_at.html).
Overall, the expression of genes seems more convincing by treatment as compared to control.

####What is the (estimated) false discovery rate of this "hits" list? How many of these hits do we expect to be false discoveries?

```r
summary(topHits)
```

```
##      logFC              AveExpr             t              P.Value       
##  Min.   :-4.989478   Min.   : 3.585   Min.   :-8.5774   Min.   :0.00000  
##  1st Qu.:-0.193981   1st Qu.: 5.637   1st Qu.:-0.9211   1st Qu.:0.08354  
##  Median : 0.020166   Median : 7.358   Median : 0.1045   Median :0.31869  
##  Mean   : 0.000872   Mean   : 7.724   Mean   : 0.0443   Mean   :0.37950  
##  3rd Qu.: 0.222828   3rd Qu.: 9.462   3rd Qu.: 1.1057   3rd Qu.:0.64351  
##  Max.   : 2.049232   Max.   :15.908   Max.   : 6.3319   Max.   :0.99999  
##    adj.P.Val               B         
##  Min.   :0.0001751   Min.   :-6.309  
##  1st Qu.:0.3341152   1st Qu.:-6.198  
##  Median :0.6372562   Median :-5.796  
##  Mean   :0.5858484   Mean   :-5.115  
##  3rd Qu.:0.8579736   3rd Qu.:-4.767  
##  Max.   :0.9999869   Max.   : 9.623
```
Adjusted P-value for the hit list

```r
(adj_pVal <- mean(topHits$adj.P.Val[1:50]))
```

```
## [1] 0.0005095663
```
False discovery rate of the 50 hits - 

```r
(fd <- adj_pVal*50)
```

```
## [1] 0.02547832
```
It can be inferred from the results above that for all the 50 hits, the minimum adjusted P-value is 0.0005 and the false discovery rate is 0.025. Thus, there shouldn't be any false positives.

#### Q3c: Plot the expression levels for a few top (interesting) probes, and a few non-associated (boring) probes. 
####Make a scatter plot, plotting the expression levels for each sample on the y-axis and treatment indicator on the x-axis.  Display the mean of each group on the same plot.

Top Hits with mean expression values on the plot - 

```r
TopDat <- cbind(Des, t(Dat[head(rownames(topHits)),]))
mystripplot(TopDat, "Treatment", "Treatment")+ylab("Gene Expression")+ stat_summary(aes(group=1), fun.y=mean, geom="line")+stat_summary(aes(label=round(..y..,2)), fun.y=mean, geom="text", size = 3, hjust = -0.5)
```

![](hamza_hw1_files/figure-html/unnamed-chunk-27-1.png) 



Bottom hits with the mean expression values on the plot -

```r
BotDat <- cbind(Des, t(Dat[tail(rownames(topHits)),]))
mystripplot(BotDat, "Treatment", "Treatment") + ylab("Gene Expression")+ stat_summary(aes(group=1), fun.y=mean, geom="line")+stat_summary(aes(label=round(..y..,2)), fun.y=mean, geom="text", size = 3, hjust = -0.5, vjust = -0.3)
```

![](hamza_hw1_files/figure-html/unnamed-chunk-28-1.png) 

The mean expression for **interesting genes** varies for treatment and control, whereas it remains almost the same for the **boring genes**.

### Q4:Assess differential expression with respect to time.
**Note**: from now on, time is treated as a quantitative covariate (unit: hours).

#### Q4a: Fit a linear model, assessing the effect of time on gene expression

```r
Des$Numtime <- recode(Des$time, "'1_h'=1; '2_h'=2; '4_h'=4; '24_h'=24", as.factor.result = FALSE)
 
DesMat2 <- model.matrix(~Numtime, Des)
Fit_model2 <- lmFit(Dat, DesMat2)
EbFit2 <- eBayes(Fit_model2)
```

####Q.How many hits are associated with time at unadjusted p-value 1e-3? At FDR 0.05?

```r
topHits2 <- topTable(EbFit2, number=nrow(EbFit2), adjust.method="fdr", sort.by="P")
```

```
## Removing intercept from test coefficients
```

```r
summary(topHits2)
```

```
##      logFC               AveExpr             t            
##  Min.   :-0.1291140   Min.   : 3.585   Min.   :-11.55970  
##  1st Qu.:-0.0101644   1st Qu.: 5.637   1st Qu.: -0.92238  
##  Median : 0.0008980   Median : 7.358   Median :  0.08636  
##  Mean   : 0.0007429   Mean   : 7.724   Mean   :  0.04984  
##  3rd Qu.: 0.0117359   3rd Qu.: 9.462   3rd Qu.:  1.07299  
##  Max.   : 0.1049987   Max.   :15.908   Max.   :  9.76911  
##     P.Value          adj.P.Val               B         
##  Min.   :0.00000   Min.   :0.0000013   Min.   :-7.146  
##  1st Qu.:0.08638   1st Qu.:0.3454580   1st Qu.:-7.038  
##  Median :0.32806   Median :0.6560945   Median :-6.638  
##  Mean   :0.38402   Mean   :0.5932726   Mean   :-5.878  
##  3rd Qu.:0.65231   3rd Qu.:0.8696311   3rd Qu.:-5.587  
##  Max.   :1.00000   Max.   :0.9999977   Max.   :15.283
```

```r
head(topHits2)
```

```
##                   logFC   AveExpr          t      P.Value    adj.P.Val
## 202586_at   -0.04321190  9.045753 -11.559699 5.595299e-11 1.272203e-06
## 203201_at   -0.04242793 10.057592 -10.121063 7.109181e-10 6.663751e-06
## 227559_at   -0.05501598  8.182478  -9.958972 9.609875e-10 6.663751e-06
## 202769_at    0.04317888 12.095002   9.769107 1.373425e-09 6.663751e-06
## 226775_at   -0.03828553  8.647287  -9.734894 1.465398e-09 6.663751e-06
## 213113_s_at -0.04650788 10.391574  -9.412004 2.721027e-09 1.031133e-05
##                    B
## 202586_at   15.28331
## 203201_at   12.74567
## 227559_at   12.44384
## 202769_at   12.08602
## 226775_at   12.02105
## 213113_s_at 11.40035
```
Following are the number of hits that are associated with `time` at unadjusted p-value of 1e-3 :

```r
sum(topHits2$P.Value < 1e-03) 
```

```
## [1] 958
```
Following are the number of hits that are associated with `time` at an FDR of 0.05 :

```r
sum(topHits2$adj.P.Val < 0.05)
```

```
## [1] 1451
```
#### Q4b: Plot expression levels of a few top probes and a few boring ones:

Make a scatter plot, plotting the expression levels for each sample on the y-axis and `time` on the x-axis. Since you are fitting `time` as a quantitative variable, add the fitted regression line on the same plot. 


Following is a plot for the top six genes - 

```r
colnames(Des)[4] <- "Hours"
TopData <- cbind(Des, t(Dat[head(rownames(topHits2)),])) 
mystripplot(TopData, "Hours", "Treatment") +
  ylab("Gene Expression")+
  stat_smooth(aes(group=1), method="lm", se=FALSE) +
scale_x_continuous(breaks=seq(0,20,5))
```

![](hamza_hw1_files/figure-html/unnamed-chunk-33-1.png) 


Following is a plot for the bottom/boring six genes - 

```r
BottomData <- cbind(Des, t(Dat[tail(rownames(topHits2)),])) 
mystripplot(BottomData, "Hours","Treatment") +
  ylab("Gene Expression")+
  stat_smooth(aes(group=1), method="lm", se=FALSE) +
scale_x_continuous(breaks=seq(0,20,5))
```

![](hamza_hw1_files/figure-html/unnamed-chunk-34-1.png) 


####Q.This plot should look different from plots in Q1, why?
This plot looks different from the plots in Q1 because over here Time is being considered as a numberic entity as compared to Q1, where it was a categorial variable. Besides, limma estimated the slope of this line, whereas in Q1 we were drawing a line connecting the means.


### Q5.Perform differential expression analysis using a full model with both  treatment and time as covariates.

```r
DesMatCov <- model.matrix(~Treatment*Hours, Des)
str(DesMatCov)
```

```
##  num [1:23, 1:4] 1 1 1 1 1 1 1 1 1 1 ...
##  - attr(*, "dimnames")=List of 2
##   ..$ : chr [1:23] "1" "10" "11" "12" ...
##   ..$ : chr [1:4] "(Intercept)" "Treatmentcontrol" "Hours" "Treatmentcontrol:Hours"
##  - attr(*, "assign")= int [1:4] 0 1 2 3
##  - attr(*, "contrasts")=List of 1
##   ..$ Treatment: chr "contr.treatment"
```

```r
#colnames(DesMatCov)[2:4] <- c("cigarette", "Hours", "cigarette_hours")
ModelCov <- lmFit(Dat, DesMatCov)
CovFit <- eBayes(ModelCov)
topTable(CovFit)
```

```
## Removing intercept from test coefficients
```

```
##             Treatmentcontrol       Hours Treatmentcontrol.Hours  AveExpr
## 214290_s_at      -0.16551666  0.09410100            -0.07394082 12.36283
## 202870_s_at       0.22069666 -0.08934809             0.06287376 11.80425
## 208955_at        -0.17577142 -0.06812775             0.05748477 10.09237
## 203108_at         0.59479660  0.08038465            -0.11407096 12.71756
## 218542_at         0.09262906 -0.06617139             0.05928858 11.21883
## 212281_s_at      -0.13169137 -0.06795005             0.04787848 10.96036
## 202954_at        -0.06430425 -0.08021917             0.06099165 11.74982
## 225687_at        -0.01686898 -0.06742085             0.06235953 11.25114
## 202779_s_at       0.01796472 -0.06825002             0.04901065 12.15344
## 203764_at        -0.08054327 -0.08326001             0.08864904 10.82074
##                     F      P.Value    adj.P.Val
## 214290_s_at 156.55408 2.659658e-14 6.047264e-10
## 202870_s_at 133.84586 1.230797e-13 1.399232e-09
## 208955_at   123.82646 2.621916e-13 1.987150e-09
## 203108_at   101.30302 1.817024e-12 1.032842e-08
## 218542_at    90.07826 5.573399e-12 2.534448e-08
## 212281_s_at  86.82289 7.903859e-12 2.782995e-08
## 202954_at    86.08671 8.567956e-12 2.782995e-08
## 225687_at    84.17688 1.059449e-11 3.011088e-08
## 202779_s_at  74.95279 3.157967e-11 7.978077e-08
## 203764_at    73.08677 3.997812e-11 9.089826e-08
```

```r
TopCov <- topTable(CovFit, coef = "Treatmentcontrol", number = nrow(CovFit))
```
**Note**: as in previous question, time has been treated as a quantitative variable.

#### Q5a: Quantify the number of hits for treatment.

For how many probes is `treatment` a significant factor at the unadjusted p-value 1e-3, and at FDR 0.05 level?

Number of probes where treatment is a significant factor at the unadjusted p-value of 1e-03 is :

```r
nrow(TopCov %>%
  filter(P.Value <= 1e-03))
```

```
## [1] 621
```
Number of probes where treatment is a significant factor at FDR value of 0.05 is :

```r
nrow(TopCov %>%
  filter(adj.P.Val <= 0.05))
```

```
## [1] 768
```


####Is this number different from what you reported in Q3b? Why? Quantify the proportion of overlapping probes among your hits, when using the unadjusted p-value threshold of 1e-3.

Yes, the number is different from that in Q3b. 
In Q3b, the model accessed differential expression with repect to only treatment which resulted in 805 hits with threshold P-value < 1-03 and 1238 hits with an FDR<0.05. Over here, we are considering both time and treatment as covariates which results in fewer hits as given above. Therefore, the interaction between time and treatment in this model accounts for different numbers from what reported in Q3b.

**Overlapping genes among these hits and those in Q3b, when using the unadjusted p-value threshold of 1e-3 are as under - **

```r
a <- rownames(count_unadj)[count_unadj$P.Value < 1e-03]
b <- rownames(TopCov)[TopCov$P.Value < 1e-03]
length(intersect(a,b))
```

```
## [1] 328
```
**Ratio of overlapping probes -**

```r
 (ratio <-  (length(intersect(a,b)))/number1)
```

```
## [1] 0.4074534
```

```r
#NOTE: Here 'number1' is the number of genes at unadjusted p-value<=1e-3 from Q.3b.
```
Only 328 genes (Q3b; Only treatment model; unadjusted Pvalue < 1e-3) out of the 621 genes (full model, unadjusted Pvalue < 1e-3) are significant. The ratio of overlap between them accounts to around 0.41.


####Q.Plot the distributions of all the p-values for treatment when using both models, i.e., one from the model in Q3 and one from the full model in this question. Compare and comment on the similarity/differences in the shape of the distributions.

```r
model=rep(c("Only_Treatment", "Full_Model"), each=nrow(TopCov))
pval=c(topHits$P.Value, TopCov$P.Value)
pVals <- data.frame(model,pval)
ggplot(pVals, aes(x = pval, fill=factor(model)), main = "P-Value distribution for 'treatment' using model in Q3 and full model in Q5.") + geom_density(alpha=0.5)
```

![](hamza_hw1_files/figure-html/unnamed-chunk-40-1.png) 

The shape of the density plots for the two models is almost similar. The "Only-treatment" model has lower p-values as compared to the "full-model".

#### Q5b: Test the null hypothesis that there is no significant interaction between time and treatment.Explain in English what you are modeling with this interaction term (what does it  represent?). 

Here we are modelling gene expression as a function of time, treatment and the interaction between them.This interaction term represents the change in gene expression resulting from treatment over time.This results in an expression that is not observed when either variable is considered alone. 


```r
timetreatHits <- topTable(CovFit, coef = "Treatmentcontrol:Hours", number = nrow(CovFit))
```

For how many probes is the interaction effect significant at the unadjusted p-value 1e-3, and at FDR 0.05 level?

Number of probes where 'treatment' is a significant factor at the unadjusted p-value of 1e-03 is :

```r
nrow(timetreatHits %>%
  filter(P.Value <= 1e-03))
```

```
## [1] 573
```
Number of probes where 'treatment' is a significant factor at FDR value of 0.05 is :

```r
nrow(timetreatHits %>%
  filter(adj.P.Val <= 0.05))
```

```
## [1] 664
```

#### Q5c: Plot a few probes where the interaction does and does not matter 
####Plot the expression levels for each sample on the y-axis and time on the x-axis. Color the points based on treatment group. As in Q4b, include the fitted regression lines in your plots.

Following is a plot for the top six genes -

```r
PlotData <- cbind(Des, t(Dat[head(rownames(timetreatHits)),]))
mystripplot(PlotData, "Hours", "Treatment") + 
       geom_point() +
       stat_smooth(aes(group=Treatment), method="lm", se=FALSE) +
       scale_x_continuous(breaks=seq(0,20,5))
```

![](hamza_hw1_files/figure-html/unnamed-chunk-44-1.png) 

Following is a plot for the bottom/boring six genes -

```r
PlotData2 <- cbind(Des, t(Dat[tail(rownames(timetreatHits)),]))
mystripplot(PlotData2, "Hours", "Treatment") + 
       geom_point() +
       stat_smooth(aes(group=Treatment), method="lm", se=FALSE) +
       scale_x_continuous(breaks=seq(0,20,5))
```

![](hamza_hw1_files/figure-html/unnamed-chunk-45-1.png) 

The regression lines in the interesting probes plot have variable slopes as compared to the boring probes plot, which is somewhat parallel. The other point worth noticing is the steepness of the slopes in the interesting probes plot as compared to those in Q4 where only time was considered. 

**FINAL COMMENTS** - The top most hit [203108_at](http://xavierlab2.mgh.harvard.edu/EnrichmentProfiler/cancer/Expression/203108_at.html) is unique to [GPCR5A](http://www.ncbi.nlm.nih.gov/gene?Db=gene&Cmd=ShowDetailView&UID=9052)(G protein-coupled receptor, class C, group 5, member A ). 
It has been shown in this study([Click here for reference](http://www.ncbi.nlm.nih.gov/pubmed/20563252?dopt=Citation)) that GPCR5A acts as lung tumour suppressor and is frequently repressed in human non-small cell lung cancers (NSCLC) cells and lung tumor specimens. Knock out studies ([Click here for reference](http://www.molecular-cancer.com/content/11/1/4)) for GPCR5A have shown enhancement of lung tumourigenesis.
In another study ([Click here for reference](http://www.ncbi.nlm.nih.gov/pubmed/20686609?dopt=Citation)) the incidence and size of lung tumors was significantly increased after exposure of GPRC5A knockout mice to the tobacco specific carcinogen NNK.This gene has also been shown to be active in foetus and can trigger tumour if exposed to cigarrete smoke.
In short, smoking kills!


#### Bonus question: consider the limitations of the model you used in Q5, can you think of an assumption underlying the model that is not consistent with the specification of this data?
The unbalanced data, with one missing sample adds to its inconsistency. This would affect the model in Q5 as it considers both treatment and time as covariates. Besides, we could have opted for better models (Eg.polynomial) taking time as a quantitaive variable. It would have been nice if there were more metadata to fiddle with, such as age, demographics, etc. (Note:The top Hit genes in this study were also found to be active in foetus and could have been helpful in evaluating the effect of smoking during pregnancy)


