HomeWork 1 - Hamza Khan

Please click on the following links:

- [RMD FILE](https://github.com/STAT540-UBC/zz_khan-hamza_STAT540_2015/blob/master/HW1/hamza_hw1.rmd)
- [MD FILE](https://github.com/STAT540-UBC/zz_khan-hamza_STAT540_2015/blob/master/HW1/hamza_hw1.md)
- [HTML FILE](http://htmlpreview.github.io/?https://raw.githubusercontent.com/STAT540-UBC/zz_khan-hamza_STAT540_2015/master/HW1/hamza_hw1.html?token=AGP2oO6R6nM7AqQJQFQ087Bzg2LHlQUaks5U_SKMwA%3D%3D)
